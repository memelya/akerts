@echo off
cd /d "%~dp0"
set "GENUI_PY=python"
where py >nul 2>nul
if %errorlevel% equ 0 set "GENUI_PY=py -3"
if not exist "%~dp0.local-data\ai-config.json" (
 %GENUI_PY% "%~dp0configure_gigacode.py"
 if errorlevel 1 (
  pause
  exit /b 1
 )
)
%GENUI_PY% "%~dp0start_local.py" --port 8015
if errorlevel 1 pause
