@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
 py -3 "%~dp0start_local.py" --port 8015
) else (
 python "%~dp0start_local.py" --port 8015
)
if errorlevel 1 pause
