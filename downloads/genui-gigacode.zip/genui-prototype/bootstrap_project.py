"""Configure, validate one real CLI response, detach server and open this project."""
import argparse,hashlib,json,os,subprocess,sys,threading,time,webbrowser
from pathlib import Path
from urllib.request import urlopen
from app_version import BUILD

def active(root):
    try:
        saved=json.loads((root/'.local-data/server.json').read_text(encoding='utf-8'))
        port=int(saved['port'])
        if not 1024<=port<=65535:return None
        url='http://127.0.0.1:'+str(port)
        with urlopen(url+'/api/health',timeout=2) as response:health=json.load(response)
        root_id=hashlib.sha256(str(root.resolve()).casefold().encode()).hexdigest()
        if health.get('rootId')==root_id and health.get('instance')==saved.get('instance'):return url,health
    except (OSError,ValueError,KeyError,TypeError):pass
    return None

def setup(root,port=8015,open_browser=True):
    from diagnostics import inspect,print_report
    from gigachat_bridge import load_config
    from configure_gigacode import configure
    from model_client import call_json
    root=Path(root).resolve();folder=root/'.local-data';folder.mkdir(exist_ok=True)
    print('1/4 Проверка Python, CSV и хранилища...',flush=True)
    report=inspect(root,port,False);print_report(report)
    if not report['ok']:raise ValueError('Проверка проекта не пройдена. Исправьте перечисленные ошибки CSV/окружения. Файлы не изменены.')
    print('2/4 Настройка подключения к установленной GigaCode...',flush=True)
    if not (folder/'ai-config.json').exists():configure(root)
    config=load_config(root)
    print('3/4 Один реальный запрос к модели на синтетических данных...',flush=True)
    answer=call_json(root,'Верни ровно один JSON {"ok":true}. Без пояснений и других полей.',{'phase':'startup-check','synthetic':True},'startup-check','Проверка подключения при запуске',None,threading.Event(),timeout_seconds=config['planningTimeoutSeconds'])
    if answer!={'ok':True}:raise ValueError('CLI ответила, но контрольный JSON не совпал. Запустите python diagnose_project.py --probe-model. Сервер не запускался.')
    print('4/4 Запуск сервера...',flush=True)
    running=active(root)
    if running and running[1].get('build')!=BUILD:raise ValueError('В этой папке запущен сервер другой версии. Завершите его обычным способом и повторите запуск.')
    process=None
    if not running:
        with (folder/'server-output.log').open('a',encoding='utf-8') as output:
            options={'creationflags':subprocess.CREATE_NO_WINDOW|subprocess.DETACHED_PROCESS} if os.name=='nt' else {'start_new_session':True}
            process=subprocess.Popen([sys.executable,str(root/'launch_local.py'),'--port',str(port),'--no-browser'],cwd=root,stdin=subprocess.DEVNULL,stdout=output,stderr=output,env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONUTF8='1'),**options)
        for _ in range(200):
            running=active(root)
            if running:break
            if process.poll() is not None:break
            time.sleep(.1)
        if not running:raise ValueError('Сервер не подтвердил готовность. Подробности: .local-data/server-output.log. Другие процессы не останавливались.')
    url=running[0]+'/genui/'
    result={'build':BUILD,'url':url,'serverHealth':'passed','modelJsonCheck':'passed','generatedUi':'not_tested','reusedServer':process is None}
    (folder/'startup-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    if open_browser:
        try:result['browserOpened']=bool(webbrowser.open(url))
        except webbrowser.Error:result['browserOpened']=False
    print('Сайт: '+url,flush=True)
    print('Подключение CLI проверено. Генерация произвольного интерфейса этим тестом не подтверждена.',flush=True)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--port',type=int,default=8015);parser.add_argument('--no-browser',action='store_true');args=parser.parse_args()
    if not 1024<=args.port<=65526:parser.error('port: 1024–65526')
    try:setup(Path(__file__).resolve().parent,args.port,not args.no_browser)
    except (ValueError,OSError,subprocess.TimeoutExpired) as error:
        print('ЗАПУСК ОСТАНОВЛЕН: '+str(error),flush=True)
        print('Не меняйте код проекта для обхода проверки. При ошибке модели: python diagnose_project.py --probe-model',flush=True)
        raise SystemExit(1)
