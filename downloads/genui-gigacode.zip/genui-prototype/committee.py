"""Deterministic monitoring and versioned committee workflow for a local project."""
import datetime as dt
import hashlib
import json
import uuid
from collections import defaultdict

from analytics_db import encoded
from metric_registry import VERSION, POLICY, calculate, weighted_csi
from workflows import changes, now, text


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def observation(rows, channel):
    result = {key: calculate(rows, key) for key in ('events', 'sends', 'answers', 'csi', 'stop', 'contactPolicy')}
    result['csiSample'] = weighted_csi(rows)['denominator']
    events, sends = result['events'], result['sends']
    result['sendShare'] = sends / events * 100 if events and sends is not None else None
    counts = [result[key] for key in ('sends', 'stop', 'contactPolicy')]
    result['other'] = events - sum(counts) if channel == 'communication' and events is not None and all(value is not None for value in counts) else None
    for key in ('stop', 'contactPolicy', 'other'):
        result[key + 'Share'] = result[key] / events * 100 if events and result[key] is not None else None
    return result


def remaining_statuses(current, prior):
    buckets = []
    for rows in (current, prior):
        counts = defaultdict(int)
        for row in rows:
            if row['status'] not in (1002, *POLICY):
                counts[str(row['status'])] += row['events'] - row['sends']
        buckets.append(counts)
    a, b = buckets
    result = [{'status': code, 'current': a.get(code), 'baseline': b.get(code),
               'delta': a[code] - b[code] if code in a and code in b else None} for code in a.keys() | b.keys()]
    return sorted(result, key=lambda row: (-abs(row['delta'] or 0), row['status']))[:20]


def signals(records, end, channel):
    groups = defaultdict(list)
    for row in records:
        if row['grain'] == 'day' and row['channel'] == channel:
            groups[row['id'], row['date']].append(row)
    output = []
    for ident in sorted({key[0] for key in groups}):
        current, prior = [], []
        days = []
        for offset in range(6, -1, -1):
            date = end - dt.timedelta(days=offset)
            a, b = date.isoformat(), (date - dt.timedelta(days=7)).isoformat()
            if groups.get((ident, a)) and groups.get((ident, b)):
                current.extend(groups[ident, a]);prior.extend(groups[ident, b]);days.append(a)
        if len(days) < 5:
            continue
        a, b = observation(current, channel), observation(prior, channel)
        delta = {key: a[key] - b[key] if a[key] is not None and b[key] is not None else None for key in a}
        reasons = []
        if delta['sendShare'] is not None and delta['sendShare'] <= -5 and (b['events'] or 0) >= 100 and (a['events'] or 0) >= 100:
            reasons.append('Доля отправок снизилась минимум на 5 п.п.')
        if (b['answers'] or 0) >= 30 and a['answers'] is not None and a['answers'] <= .8 * b['answers']:
            reasons.append('Ответов стало меньше минимум на 20%')
        if min(a['csiSample'], b['csiSample']) >= 30 and delta['csi'] is not None and delta['csi'] <= -.3 + 1e-10:
            reasons.append('CSI снизился минимум на 0,3 балла')
        if reasons:
            output.append({'key': f'{channel}:{ident}:{end.isoformat()}', 'id': ident, 'channel': channel,
                           'through': end.isoformat(), 'pairedDays': days, 'current': a, 'baseline': b, 'delta': delta, 'reasons': reasons,
                           'remainingStatuses': remaining_statuses(current, prior) if channel == 'communication' else []})
    return sorted(output, key=lambda row: (-len(row['reasons']), row['delta']['sendShare'] or 0, row['id']))


class Committee:
    def __init__(self, engine):
        self.engine = engine
        self.db = engine.store.connect
        with self.db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS monitoring_tasks(id TEXT PRIMARY KEY, signal_key TEXT NOT NULL UNIQUE, document TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS committee_packs(id TEXT PRIMARY KEY, scenario TEXT NOT NULL, created TEXT NOT NULL, document TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS committee_packs_scenario ON committee_packs(scenario, created DESC);
            ''')

    def _load(self, db, table, ident):
        if table == 'monitoring_tasks':
            row = db.execute('SELECT document FROM monitoring_tasks WHERE id=?', (ident,)).fetchone()
        else:
            row = db.execute('SELECT document FROM committee_packs WHERE id=?', (ident,)).fetchone()
        if not row:
            raise ValueError('Запись не найдена.')
        return json.loads(row[0])

    def monitor(self, request):
        channel = request.get('channel', 'communication')
        ident = request.get('survey')
        if channel not in ('communication', 'success_screen') or ident is not None and (type(ident) is not int or not 1 <= ident <= 9999999):
            raise ValueError('Выберите канал и корректный номер опроса.')
        engine = self.engine
        with engine.lock:
            state, status = engine.refresh()
            revision = engine.document.get('revision')
            keys = [(channel, survey['event']['id']) for survey in state['surveys'] if survey['meta']['channel'] == channel and (ident is None or survey['event']['id'] == ident)]
            latest = engine.store.last_daily(revision, keys) if revision and keys else None
            if status.get('error'):
                raise ValueError(status['error'])
            if not latest:
                return {'signals': [], 'revision': revision, 'message': 'Нет дневных наблюдений по выбранному отбору.'}
            end = dt.date.fromisoformat(latest)
            if request.get('through'):
                chosen = dt.date.fromisoformat(text(request['through'], 'Дата', 10))
                if chosen > end:
                    raise ValueError('Дата позже последних доступных наблюдений.')
                end = chosen
            start = end - dt.timedelta(days=13)
            records = engine.store.records(revision, keys, start.isoformat(), end.isoformat(), limit=200001)
        if len(records) > 200000:
            raise ValueError('Выберите конкретный опрос. В двух окнах больше 200 000 строк.')
        names = {survey['event']['id']: survey['meta']['name'] for survey in state['surveys'] if survey['meta']['channel'] == channel}
        found = signals(records, end, channel)
        for row in found:
            row.update(revision=revision, name=names.get(row['id'], str(row['id'])))
        return {'signals': found[:100], 'total': len(found), 'revision': revision, 'through': end.isoformat()}

    def assign(self, request):
        scan = self.monitor(request)
        if scan['revision'] != request.get('revision'):
            raise ValueError('Данные обновились. Пересчитайте очередь перед назначением.')
        signal = next((item for item in scan['signals'] if item['key'] == request.get('key')), None)
        if not signal:
            raise ValueError('Сигнал больше не входит в текущий результат. Пересчитайте очередь.')
        actor = text(request.get('actor'), 'Кто назначил', 120)
        owner = text(request.get('owner'), 'Ответственный', 120)
        due = dt.date.fromisoformat(text(request.get('due'), 'Срок', 10)).isoformat()
        task = {'id': uuid.uuid4().hex, 'version': 1, 'signal': signal, 'owner': owner, 'due': due, 'status': 'open',
                'history': [{'at': now(), 'actor': actor, 'status': 'open', 'note': ''}]}
        with self.db() as db:
            cursor = db.execute('INSERT OR IGNORE INTO monitoring_tasks VALUES(?,?,?)', (task['id'], signal['key'], encoded(task)))
            if not cursor.rowcount:
                raise ValueError('На это отклонение уже заведена задача.')
        return task

    def update_task(self, request):
        actor = text(request.get('actor'), 'Кто меняет статус', 120)
        note = text(request.get('note', ''), 'Результат проверки', 2000, request.get('status') == 'resolved')
        status = request.get('status')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            task = self._load(db, 'monitoring_tasks', request.get('id'))
            if request.get('version') != task['version']:
                raise ValueError('Задача уже изменена. Обновите список.')
            transitions = {'open': {'in_progress', 'resolved'}, 'in_progress': {'resolved'}, 'resolved': {'in_progress'}}
            if status not in transitions[task['status']]:
                raise ValueError('Недопустимый переход статуса.')
            task.update(status=status, version=task['version'] + 1)
            task['history'].append({'at': now(), 'actor': actor, 'status': status, 'note': note})
            db.execute('UPDATE monitoring_tasks SET document=? WHERE id=?', (encoded(task), task['id']))
        return task

    def packs(self, scenario):
        with self.db() as db:
            rows = db.execute('SELECT document FROM committee_packs WHERE scenario=? ORDER BY created DESC LIMIT 40', (scenario,))
            return [{key: value for key, value in json.loads(row[0]).items() if key != 'snapshot'} for row in rows]

    def create_pack(self, request):
        scenario = request.get('scenario')
        author = text(request.get('actor'), 'Автор пакета', 120)
        with self.engine.lock:
            _, status = self.engine.refresh()
            data = self.engine.workflows.open(scenario)
            run = data.get('run')
            if status.get('error') or not run or data['lastError'] or run['revision'] != self.engine.document.get('revision'):
                raise ValueError('Для нового пакета нужен актуальный успешный запуск сценария.')
            if not any(value is not None for chart in run['charts'] for block in chart['blocks'] for value in block['values']):
                raise ValueError('В сценарии нет наблюдений для пакета. Уточните показатели или период.')
            source = {'name': data['definition']['name'], 'charts': run['charts'], 'revision': run['revision'], 'metricVersion': VERSION,
                      'scopeHash': digest([chart['spec'] for chart in data['definition']['charts']]),
                      'titles': [item['query'] for item in data['definition']['charts']]}
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            rows = db.execute('SELECT document FROM committee_packs WHERE scenario=? ORDER BY created DESC', (scenario,))
            previous = next((doc for row in rows if (doc := json.loads(row[0]))['status'] == 'approved'), None)
            source['scopeChanged'] = bool(previous and previous['snapshot'].get('scopeHash') != source['scopeHash'])
            source['comparison'] = changes(previous['snapshot']['charts'] if previous and not source['scopeChanged'] else [], source['charts'])
            source['previousApproved'] = {'id': previous['id'], 'revision': previous['snapshot']['revision']} if previous else None
            source['conclusion'] = text(request.get('conclusion', ''), 'Вывод автора', 600, False)
            timestamp = now()
            pack = {'id': uuid.uuid4().hex, 'scenario': scenario, 'created': timestamp, 'status': 'draft', 'version': 1,
                    'author': author, 'hash': digest(source), 'revision': source['revision'], 'snapshot': source,
                    'history': [{'at': timestamp, 'actor': author, 'status': 'draft', 'note': ''}]}
            db.execute('INSERT INTO committee_packs VALUES(?,?,?,?)', (pack['id'], scenario, timestamp, encoded(pack)))
        return pack

    def review(self, request):
        actor = text(request.get('actor'), 'Участник согласования', 120)
        status = request.get('status')
        note = text(request.get('note', ''), 'Комментарий', 1200, status == 'rejected')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            pack = self._load(db, 'committee_packs', request.get('id'))
            if request.get('version') != pack['version'] or pack['hash'] != digest(pack['snapshot']):
                raise ValueError('Версия пакета изменилась или повреждена. Откройте список заново.')
            same_actor=' '.join(actor.split()).casefold() == ' '.join(pack['author'].split()).casefold()
            if status == 'review' and pack['status'] == 'draft' and same_actor:
                pass
            elif status in ('approved', 'rejected') and pack['status'] == 'review' and not same_actor:
                pass
            else:
                raise ValueError('Автор отправляет черновик. Утверждает или возвращает другой участник.')
            pack.update(status=status, version=pack['version'] + 1)
            pack['history'].append({'at': now(), 'actor': actor, 'status': status, 'note': note})
            db.execute('UPDATE committee_packs SET document=? WHERE id=?', (encoded(pack), pack['id']))
        return pack

    def action(self, request):
        action = request.get('action')
        if action == 'monitor': return self.monitor(request)
        if action == 'assign': return self.assign(request)
        if action == 'task-update': return self.update_task(request)
        if action == 'tasks':
            with self.db() as db:
                return [json.loads(row[0]) for row in db.execute('SELECT document FROM monitoring_tasks ORDER BY rowid DESC')]
        if action == 'packs': return self.packs(request.get('scenario'))
        if action == 'pack-create': return self.create_pack(request)
        if action == 'pack-review': return self.review(request)
        if action in ('pack-open', 'pack-export'):
            with self.db() as db:
                pack = self._load(db, 'committee_packs', request.get('id'))
            if digest(pack['snapshot']) != pack['hash']:
                raise ValueError('Снимок пакета повреждён.')
            if action == 'pack-export' and pack['status'] != 'approved':
                raise ValueError('Экспорт доступен после утверждения пакета.')
            return pack
        if action == 'policy':
            from model_policy import profile, VERSION as policy_version
            return {'profile': profile(self.engine.root), 'version': policy_version}
        if action == 'evaluate':
            from release_eval import run
            return run()
        raise ValueError('Неизвестное действие рабочего контура.')
