"""Daily original-rating distribution. Monthly averages cannot reconstruct it."""
from collections import defaultdict

def october(engine,revision,choice='auto'):
    title='CSI по дням · 1007 · октябрь 2026'
    cache=getattr(engine,'_meeting_daily_csi',None)
    if cache is None or cache['revision']!=revision:
        rows=engine.store.records(revision,[('communication',1007),('success_screen',1007)],'2026-10-01','2026-10-31') if revision else []
        cache={'revision':revision,'rows':[r for r in rows if r['grain']=='day']};engine._meeting_daily_csi=cache
    rows=cache['rows'];channels=sorted({r['channel'] for r in rows})
    if choice=='auto' and len(channels)>1:return {'kind':'daily-csi','id':1007,'title':title,'status':'clarification','channels':channels,'message':'В октябре есть дневные строки в обоих каналах. Выберите канал для CSI.'}
    channel=channels[0] if choice=='auto' and channels else choice
    selected=[r for r in rows if r['channel']==channel]
    if not selected:return {'kind':'daily-csi','id':1007,'title':title,'status':'empty','message':'Нет дневных строк опроса 1007 за октябрь 2026 в выбранном канале. Для распределения нужны дневные строки с answer_csi (или answers_csi) и числом событий по оценке. Из месячного среднего доли восстановить нельзя.'}
    grouped=defaultdict(list)
    for r in selected:grouped[r['date']].append(r)
    days=[]
    for day in range(1,32):
        date=f'2026-10-{day:02d}';counts={i:0 for i in range(1,6)};zero=unknown=0
        for row in grouped[date]:
            rating=row.get('rating');weight=row['events']
            if rating in counts:counts[int(rating)]+=weight
            elif rating==0:zero+=weight
            else:unknown+=weight
        total=sum(counts.values());csi=sum(i*n for i,n in counts.items())/total if total else None
        days.append({'date':date,'csi':csi,'count':total,'hasRows':bool(grouped[date]),'zeroCount':zero,'unclassifiedCount':unknown,'ratings':[{'score':i,'count':counts[i],'percent':counts[i]/total*100 if total else None} for i in counts]})
    return {'kind':'daily-csi','status':'ok','id':1007,'title':title,'channel':channel,'data':{'days':days,'revision':revision,'channel':channel,'title':title,'method':'CSI дня = сумма (оценка × events) / сумма events по исходным оценкам 1–5. Доли оценок считаются от того же числа валидных оценок дня. Высота столбца — CSI; подписи внутри — состав оценок, не слагаемые высоты. Оценка 0, пустые и неклассифицируемые оценки в CSI и знаменатель долей не входят. Нет валидных оценок — нет столбца, а не CSI = 0.'}}
