"""Transactional CSV imports and canonical query plans for the local application."""
import copy,hashlib,json,secrets,threading,time
import datetime as dt
from pathlib import Path
from csv_data import DataError,parse_csv,merge_records
from products import parse_products
from dashboard_model import build_state
from data_trust import TrustStore,REFERENCE_KEYS,quality_report
from analytics_db import AnalyticsStore
from genui_extended import select_surveys
from query_contract import compile_query,Clarification
from genui_extended import execute_query

FILES=(('push-sms.csv','communication'),('success-screen.csv','success_screen'))

class Engine:
    def __init__(self,root):
        self.root=Path(root);self.directory=self.root/'.local-data';self.directory.mkdir(parents=True,exist_ok=True)
        baseline_file=self.directory/'baseline.json';text=baseline_file.read_text(encoding='utf-8-sig').strip() if baseline_file.exists() else ''
        self.baseline=json.loads(text) if text else {'version':1,'months':[],'surveys':[],'daily':[],'ranks':{},'statusDescriptions':{},'surveyTypes':{},'triggerGroups':{},'management':{'period':None,'issueIds':[],'rows':[]}}
        reference_file=self.directory/'reference.json'
        if reference_file.exists():
            reference=json.loads(reference_file.read_text(encoding='utf-8-sig'))
            if reference.get('version')!=1:raise DataError('Неизвестный формат справочника reference.json')
            self.baseline.update({key:reference.get(key,{}) for key in REFERENCE_KEYS})
        self.store=AnalyticsStore(self.directory);self.cache=self.store.cache;self.lock=threading.RLock();self.plans={};self.previews={};self.analyses={};self.cache_error=None
        try:self.document=self.store.load(False)
        except (ValueError,OSError,TypeError) as error:
            self.document={'version':1,'records':[],'products':{}};self.cache_error='Не удалось прочитать .local-data/updates.json: '+str(error)+'. Сохранённый файл не перезаписан.'
        self.signature=None;self.fingerprint=self.document.get('fingerprint');self.state=self._build(self.store.summary(),self.document.get('products',{}),self.document.get('reference'))
        self.status={'files':self.document.get('files',[]),'error':self.cache_error}

    @property
    def updates(self):return self.store.records()

    def full_state(self):
        return self._build(self.updates,self.document.get('products',{}),self.document.get('reference'))

    def _signature(self):
        values=[]
        for name in ('push-sms.csv','success-screen.csv','products.csv'):
            file=self.root/'date'/name;stat=file.stat() if file.exists() else None
            values.append((name,stat.st_size if stat else None,stat.st_mtime_ns if stat else None))
        return tuple(values)

    def _build(self,records,products,reference=None):
        base=copy.deepcopy(self.baseline)
        if reference:base.update(reference)
        state=build_state(base,records);state['rawRecords']=records;state['productNames']=sorted({p for values in products.values() for p in values})
        for survey in state['surveys']:survey['meta']['products']=products.get(str(survey['event']['id']),['без продукта'])
        return state

    def _read(self):
        digest=hashlib.sha256();documents=[];files=[]
        for name,channel in (*FILES,('products.csv','reference')):
            file=self.root/'date'/name;raw=file.read_bytes() if file.exists() else b'';stat=file.stat() if file.exists() else None
            digest.update(name.encode());digest.update(raw);digest.update(str(stat.st_mtime_ns if stat else '').encode())
            documents.append((name,channel,raw));files.append({'file':'date/'+name,'rows':0,'modified':dt.datetime.fromtimestamp(stat.st_mtime).strftime('%d.%m.%Y %H:%M:%S') if stat else 'файл не найден'})
        return documents,files,digest.hexdigest()

    def _candidate(self,mode):
        if mode not in ('merge','replace'):raise DataError('Режим загрузки: merge или replace.')
        if self.cache_error:raise DataError(self.cache_error)
        signature=self._signature();documents,files,fingerprint=self._read();incoming=[];products={}
        for index,(name,channel,raw) in enumerate(documents):
            if channel=='reference':
                products,count=parse_products(raw);files[index]['rows']=count
            else:
                rows,stats=parse_csv(raw,channel,'date/'+name);incoming.extend(rows);files[index].update(stats)
        previous=self.updates
        records=merge_records(previous if mode=='merge' else [],incoming)
        reference={key:self.baseline.get(key,{}) for key in REFERENCE_KEYS}
        report=quality_report(previous,records,self.document.get('products',{}),products,files,reference,incoming)
        if signature!=self._signature():raise DataError('CSV изменился во время чтения. Сохраните файл и повторите загрузку.')
        return {'records':records,'products':products,'reference':reference,'files':files,'fingerprint':fingerprint,'report':report,'mode':mode,'signature':signature}

    def _commit(self,candidate,reason='import',restored_from=None,hold=False):
        document=self.store.commit(**{k:candidate[k] for k in ('records','products','reference','files','mode','fingerprint','report')},reason=reason,restored_from=restored_from,hold=hold)
        self.document=document;self.state=self._build(self.store.summary(),candidate['products'],candidate['reference']);self.fingerprint=candidate['fingerprint'];self.signature=candidate.get('signature');self.cache_error=None
        self.status={'files':candidate['files'],'error':None};return document

    def refresh(self):
        with self.lock:
            try:
                signature=self._signature()
                if self.signature==signature:return self.state,self.status
                _,files,fingerprint=self._read()
                if self.fingerprint==fingerprint:self.signature=signature;return self.state,self.status
                candidate=self._candidate(self.document.get('mode','merge'))
                if candidate['mode']=='replace' and self.document.get('report',{}).get('recordCount') and not candidate['records']:raise DataError('Пустая полная замена требует просмотра в центре качества данных. Текущая версия сохранена.')
                if candidate['records'] or candidate['products'] or self.document.get('revision'):self._commit(candidate)
                else:
                    self.state=self._build([],candidate['products'],candidate['reference']);self.fingerprint=fingerprint;self.signature=signature;self.status={'files':candidate['files'],'error':None}
            except (ValueError,OSError,KeyError,TypeError) as error:
                self.status={'files':locals().get('files',[]),'error':str(error)}
                try:self.store.error(str(error),self.status['files'])
                except OSError:pass
                try:self.fingerprint=self._read()[2];self.signature=self._signature()
                except OSError:self.fingerprint=None
            return self.state,self.status

    def preview_import(self,mode):
        with self.lock:
            try:candidate=self._candidate(mode)
            except (ValueError,OSError) as error:
                try:self.store.error(str(error),[])
                except OSError:pass
                raise
            token=secrets.token_urlsafe(24)
            self.previews={token:{'fingerprint':candidate['fingerprint'],'revision':self.document.get('revision'),'mode':mode,'time':time.monotonic()}}
            return {'token':token,'mode':mode,'report':candidate['report'],'files':candidate['files'],'message':'Предварительный расчёт. Данные ещё не изменены.'}

    def apply_import(self,token):
        with self.lock:
            preview=self.previews.get(token)
            if not preview or time.monotonic()-preview['time']>300:raise DataError('Предпросмотр устарел. Выполните проверку ещё раз.')
            candidate=self._candidate(preview['mode'])
            if candidate['fingerprint']!=preview['fingerprint'] or self.document.get('revision')!=preview['revision']:raise DataError('CSV или версия данных изменились. Повторите предпросмотр.')
            self._commit(candidate,reason='manual');self.previews.clear();return self.store.status()

    def restore(self,revision):
        with self.lock:
            doc=self.store.snapshot(revision);_,_,fingerprint=self._read();reference=doc.get('reference') or {k:self.baseline.get(k,{}) for k in REFERENCE_KEYS};products=doc.get('products',{})
            report=quality_report(self.updates,doc['records'],self.document.get('products',{}),products,doc.get('files',[]),reference)
            report['issues'].insert(0,'Восстановлена версия '+revision+'. CSV на диске не изменены. Они будут импортированы после изменения файлов или явного применения предпросмотра.')
            candidate={'records':doc['records'],'products':products,'reference':reference,'files':doc.get('files',[]),'mode':doc.get('mode','merge'),'fingerprint':fingerprint,'report':report}
            self._commit(candidate,reason='restore',restored_from=revision,hold=True);return self.store.status()

    def prepare(self,request):
        if request.get('source','local')!='local':raise DataError('Доступны только CSV из папки date.')
        with self.lock:
            state,status=self.refresh()
            revision=self.document.get('revision')
        if status.get('error'):raise DataError(status['error'])
        if not state['surveys']:raise DataError('Данные ещё не загружены. Добавьте выгрузки в date/push-sms.csv и date/success-screen.csv.')
        contract=compile_query(self.root,request.get('query'),request.get('previous'),state,request.get('provider','local'))
        token=secrets.token_urlsafe(24)
        with self.lock:
            self.plans={k:v for k,v in self.plans.items() if time.monotonic()-v['time']<300}
            if len(self.plans)>=40:self.plans.pop(next(iter(self.plans)))
            self.plans[token]={'contract':contract,'revision':revision,'time':time.monotonic()}
        return dict(contract,planId=token,dataRevision=revision)

    def run(self,request):
        plan_id=request.get('planId')
        if not plan_id:plan_id=self.prepare(request)['planId']
        with self.lock:
            plan=self.plans.get(plan_id)
            if not plan or time.monotonic()-plan['time']>300:raise DataError('План запроса устарел. Повторите запрос.')
            state,status=self.refresh()
            if status.get('error'):raise DataError(status['error'])
            if self.document.get('revision')!=plan['revision']:raise DataError('Данные изменились после понимания запроса. Повторите запрос для новой версии.')
            contract=plan['contract'];state=self.query_state(contract['spec'],plan['revision'])
            result=execute_query(state,contract['spec'],'Ваши CSV · date/push-sms.csv и date/success-screen.csv')
            result['provider']=contract['provider'];result['contract']=dict(contract,resolvedPeriod=result['periodLabel'],dataRevision=plan['revision'])
            analysis_id=secrets.token_urlsafe(24);self.analyses[analysis_id]={'revision':plan['revision'],'spec':contract['spec'],'blocks':[{k:b.get(k) for k in ('id','metric','values')} for b in result['blocks']],'months':result['months']}
            if len(self.analyses)>40:self.analyses.pop(next(iter(self.analyses)))
            result['analysisId']=analysis_id;return result

    def query_state(self,spec,revision):
        from datetime import date,timedelta
        selected=select_surveys(self.state,spec);keys=[(s['meta']['channel'],s['event']['id']) for s in selected]
        last=max((m for s in selected for m in s['meta']['availableMonths']),default=None)
        if spec.get('grain')=='day':
            anchor=self.store.last_daily(revision,keys)
            if spec.get('daysCount') and anchor:
                end=anchor;start=(date.fromisoformat(end)-timedelta(days=spec['daysCount']-1)).isoformat()
            else:start=(spec.get('startMonth') or (anchor or last or '')[:7]);end=spec.get('endMonth') or start;end+='-31'
        else:
            end=spec.get('endMonth') or last
            if not end:return dict(self.state,rawRecords=[])
            y,m=map(int,end.split('-'));n=y*12+m-spec['monthsCount']
            start=spec.get('startMonth') or f'{n//12:04d}-{n%12+1:02d}';end+='-31'
        records=self.store.records(revision,keys,start,end)
        return dict(self.state,rawRecords=records)

    def evidence(self,analysis_id,series,period):
        from metric_evidence import evidence
        with self.lock:
            analysis=self.analyses.get(analysis_id)
            if not analysis:raise DataError('Объяснение этого графика недоступно после перезапуска. Повторите запрос.')
            document=self.store.snapshot(analysis['revision'],include_records=False) if analysis['revision'] else self.document
            state=self._build(self.store.summary(analysis['revision']),document.get('products',{}),document.get('reference'))
            keys=[(s['meta']['channel'],s['event']['id']) for s in select_surveys(state,analysis['spec'])]
            state['rawRecords']=self.store.records(analysis['revision'],keys,period,period if len(period)==10 else period+'-31')
            return evidence(analysis,state,series,period,document)
