"""Comparable feedback collection metrics for the executive start page."""
import datetime as dt
from collections import defaultdict
from itertools import permutations
from math import prod

from metric_registry import POLICY

CHANNELS = {'communication': 'Пуш + СМС', 'success_screen': 'Экраны успеха'}
FACTORS = ('events', 'sendShare', 'responseRate')
WEEK = dt.timedelta(days=7)


def windows(end):
    end = dt.date.fromisoformat(end)
    return {
        'previous': {'start': (end-dt.timedelta(days=13)).isoformat(), 'end': (end-WEEK).isoformat()},
        'current': {'start': (end-dt.timedelta(days=6)).isoformat(), 'end': end.isoformat()},
    }


def divide(a, b):
    return a / b if b else None


def summarize(rows):
    if not rows:
        return dict.fromkeys(('events', 'sends', 'answers', 'csi', 'csiSample', 'sendShare', 'responseRate'))
    totals = {key: sum(row[key] for row in rows) for key in ('events', 'sends', 'answers', 'csiSample')}
    csi = divide(sum(row['csiWeight'] for row in rows), totals['csiSample'])
    return dict(totals, csi=csi, sendShare=divide(totals['sends'], totals['events']),
                responseRate=divide(totals['answers'], totals['sends']))


def explain(previous, current):
    a, b = [[period[key] for key in FACTORS] for period in (previous, current)]
    if any(value is None for value in a+b):
        return None
    # Average across the six orders in which the three factors can change.
    contributions = dict.fromkeys(FACTORS, 0.0)
    for order in permutations(range(3)):
        values = a.copy()
        for index in order:
            before = prod(values)
            values[index] = b[index]
            contributions[FACTORS[index]] += (prod(values)-before)/6
    return contributions


def cutoffs(before, after):
    if not before or not after:
        return []
    results = []
    for status in ('stop', 'contactPolicy'):
        counts = [sum(row[status] is not None for row in rows) for rows in (before, after)]
        totals = [sum(row[status] or 0 for row in rows) if n else None for rows,n in zip((before,after),counts)]
        events = [sum(row['events'] for row in rows) for rows in (before,after)]
        shares = [divide(value, base) if value is not None else None for value,base in zip(totals,events)]
        complete = counts == [len(before),len(after)]
        results.append({'metric': status, 'counts': totals, 'observed': counts, 'expected': len(before),
                        'shares': shares if complete else None})
    return results


def build(store, revision, surveys):
    channels = [(channel, [(channel,s['event']['id']) for s in surveys if s['meta']['channel']==channel]) for channel in CHANNELS]
    latest = {channel: store.last_daily(revision, keys) if keys and revision else None for channel,keys in channels}
    end = max(filter(None,latest.values()), default=None)
    if end is None:
        return {'revision':revision,'latest':latest,'overview':None,'channels':[],'signals':[]}
    span=windows(end)
    rows = store.feedback_days(revision, span['previous']['start'], end, POLICY)
    day_index = defaultdict(dict)
    for row in rows:
        day_index[row['channel'],row['survey_id']][row['date']] = row
    dates = [dt.date.fromisoformat(end)-dt.timedelta(days=i) for i in range(6,-1,-1)]
    members = {('bank','all'): set(day_index)}
    for channel in CHANNELS:
        members['channel',channel] = {key for key in day_index if key[0]==channel}
    for survey in surveys:
        key = survey['meta']['channel'], survey['event']['id']
        if key in day_index:
            for product in set(survey['meta'].get('products') or ['без продукта']):
                members.setdefault(('product',product),set()).add(key)
    dates = [(day.isoformat(),(day-WEEK).isoformat()) for day in dates]
    cohorts = {}
    for key, daily in day_index.items():
        pairs = [(daily[prior],daily[now]) for now,prior in dates if now in daily and prior in daily]
        cohorts[key] = pairs if len(pairs)>=5 else []
    scopes = {}
    for (kind,name), keys in members.items():
        pairs = [pair for key in sorted(keys) for pair in cohorts[key]]
        before,after = [list(part) for part in zip(*pairs)] if pairs else ([],[])
        baseline,current = summarize(before),summarize(after)
        actual=summarize([row for key in sorted(keys) for date,row in day_index[key].items() if date>=span['current']['start']])
        loss = max(0,baseline['answers']-current['answers']) if pairs else None
        communication = [(a,b) for a,b in pairs if a['channel']=='communication']
        stop_before,stop_after = [list(part) for part in zip(*communication)] if communication else ([],[])
        scope_id=kind+':'+name
        title='По банку' if kind=='bank' else CHANNELS[name] if kind=='channel' else name
        scopes[scope_id]={'key':scope_id,'kind':kind,'name':title,
                          'through':end,'windows':span,'revision':revision,'baseline':baseline,'current':current,'actual':actual,
                          'pairCount':len(pairs),'observedSurveyDays':sum(len(day_index[key]) for key in keys),
                          'surveyCount':len(keys),'comparedSurveys':sum(bool(cohorts[key]) for key in keys),
                          'pairedDays':sorted({row['date'] for row in after}),'loss':loss,
                          'factors':explain(baseline,current),'cutoffs':cutoffs(stop_before,stop_after)}
    overview = scopes['bank:all']
    # Bank and channel KPIs remain visible above the ranked list.
    ranked = sorted((scope for scope in scopes.values() if scope['kind']!='bank' and (scope['loss'] or 0)>0),
                    key=lambda scope:(-scope['loss'],scope['kind']!='channel',scope['name'].casefold()))
    selected, seen = [], set()
    for scope in ranked:
        kind,name=scope['key'].split(':',1)
        signature=frozenset(key for key in members[kind,name] if cohorts[key])
        if signature not in seen:
            selected.append(scope)
            seen.add(signature)
        if len(selected)==3:
            break
    return {'revision':revision,'latest':latest,'overview':overview,'channels':[scopes['channel:'+key] for key in CHANNELS],
            'signals':selected}
