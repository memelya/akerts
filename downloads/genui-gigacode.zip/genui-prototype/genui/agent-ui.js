(()=>{'use strict';
const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const labels={sends:'Отправки',answers:'Ответы',events:'События',csi:'CSI',stop:'Стоп-листы',contactPolicy:'Политика контактов',replyRatio:'Ответы / отправки периода',planExpected:'План ответов окна',signals:'Кандидаты на проверку'};
const priorities={critical:'P0 · Проверить немедленно',high:'P1 · Проверить сегодня',medium:'P2 · Уточнить данные',low:'P3 · Наблюдать'};
const flags={answers_drop:'Снижение ответов',send_change:'Изменение отправок',send_answer_mismatch:'Отправки растут, ответы падают',csi_drop:'Снижение CSI',stop_increase:'Рост отсечений стоп-листа',contactPolicy_increase:'Рост отсечений политики контактов',plan_gap:'Отставание от плана',no_observations:'Нет наблюдений в окне',incomplete_window:'Неполное окно',limited_csi_sample:'Малая выборка CSI',missing_baseline:'Нет сопоставимой базы',mixed_grain:'Смешанная детализация'};
const format=v=>Number.isFinite(v)?v.toLocaleString('ru-RU',{maximumFractionDigits:2}):'нет данных';
const post=(body)=>window.TrustUI.post('/api/ai',body);
function fact(data,ref){const f=data.facts[ref],box=el('article','ai-fact');if(!f)return box;
 const m=data.members[f.key];box.append(el('b','',(labels[f.metric]||f.metric)+(m?' · #'+m.id:'')),el('strong','',format(f.actual)+' '+f.unit));
 if(f.baseline!==null&&f.baseline!==undefined)box.append(el('small','','Сопоставимо: '+format(f.current)+' ← '+format(f.baseline)+(f.delta!==null&&f.delta!==undefined?' · Δ '+format(f.delta)+(f.metric==='csi'?' балла':f.percent!==null&&f.percent!==undefined?' ('+format(f.percent)+'%)':''):'')));
 if(f.sample!==undefined&&f.sample!==null)box.append(el('small','','Выборка: '+format(f.sample)+' / база '+format(f.baselineSample)));
 if(f.coverage!==null&&f.coverage!==undefined)box.append(el('small','','Дни / периоды с наблюдениями: '+format(f.coverage*100)+'%'));
 if(f.note)box.append(el('small','',f.note));const details=el('details');details.append(el('summary','','Основание '+ref));details.append(el('p','','Источник: '+data.dataRevision+' · '+data.periodLabel));
 if(f.proof)details.append(el('p','','CSI = '+format(f.proof.current.numerator)+' / '+format(f.proof.current.denominator)+'; база '+format(f.proof.baseline.numerator)+' / '+format(f.proof.baseline.denominator)+'. Нулевые оценки исключены.'));
 details.append(el('p','','Отсутствующие даты не считаются нулями. Для изменения сравниваются только даты с наблюдениями в обоих окнах.'));box.append(details);return box;
}
function facts(host,data,refs){const grid=el('div','ai-facts');for(const ref of refs)grid.append(fact(data,ref));host.append(grid);}
window.AgentUI={async wait(jobId,host,notice){const status=el('p','ai-progress','Модель планирует анализ…'),cancel=el('button','quiet','Остановить анализ');cancel.type='button';host.replaceChildren(status,cancel);let cancelled=false;cancel.onclick=async()=>{cancel.disabled=true;cancelled=true;try{await post({jobId,action:'cancel'});}catch(e){status.textContent=e.message;}};
 while(true){const job=await post({jobId});status.textContent=(cancelled?'Останавливаю…':job.stage)+' · вызовов модели: '+job.calls;notice(status.textContent);
  if(job.status==='done')return {...job.result,stale:job.stale};
  if(job.status==='clarification'){const e=new Error(job.clarification.question);e.clarification={options:(job.clarification.options||[]).map(label=>({label,query:label}))};throw e;}
  if(['error','cancelled'].includes(job.status))throw new Error(job.error||'Анализ остановлен. Предыдущий экран сохранён.');
  await new Promise(resolve=>setTimeout(resolve,650));
 }
},render(host,data,{onChart,onRerun,renderChart}){
 host.classList.add('ai-workspace');host.append(el('p','message-label','GigaCode · модельный анализ · '+data.modelCalls+' вызова'),el('h2','answer-title',data.view.title),el('p','ai-source','Загруженные наблюдения: '+data.periodLabel+' · версия '+data.dataRevision+' · определения '+data.metricVersion),el('p','',data.view.summary));
 if(data.stale)host.append(el('p','error','CSV обновились во время анализа. На экране зафиксированная предыдущая версия. Повторите запрос для новых данных.'));
 host.append(el('p','ai-caveat','Это очередь проверок, а не подтверждённые инциденты. Период привязан к последней дате CSV. Причины требуют проверки; пропуски не равны нулю.'));
 for(const component of data.view.components){const section=el('section','ai-section');section.append(el('h3','',component.title));
  if(component.type==='priority_queue'){
   if(!component.items.length)section.append(el('p','','По предложенным критериям подтверждённых кандидатов нет. Это не гарантирует отсутствие проблем.'));
   for(const item of component.items){const m=data.members[item.key],card=el('article','ai-priority');card.dataset.priority=item.priority;card.append(el('b','ai-priority-label',priorities[item.priority]),el('h4','','#'+m.id+' · '+m.name),el('small','',m.channel==='communication'?'Пуш + СМС':'Экран успеха'),el('p','',item.reason));facts(card,data,item.factRefs);
    const checks=el('ol');item.checks.forEach(t=>checks.append(el('li','',t)));card.append(el('b','','Что проверить'),checks);
    for(const h of item.hypotheses||[]){card.append(el('p','ai-hypothesis','Гипотеза: '+h.text));facts(card,data,h.factRefs);for(const ref of h.eventRefs||[])card.append(el('small','','Контекст календаря: '+data.events[ref].title));}
    const drill=el('button','quiet','Открыть динамику опроса');drill.type='button';drill.onclick=async()=>{drill.disabled=true;try{onChart(await post({jobId:data.jobId,action:'chart',keys:[item.key],metrics:[...new Set(item.factRefs.map(r=>data.facts[r].metric).filter(m=>['sends','answers','csi','stop','events','contactPolicy'].includes(m)))].slice(0,6)}),'Детализация #'+m.id);}catch(e){card.append(el('p','error',e.message));}finally{drill.disabled=false;}};card.append(drill);section.append(card);
   }
  }else if(['kpis','comparison'].includes(component.type))facts(section,data,component.refs);
  else if(component.type==='trend'){const chart=el('article','chat-message answer');section.append(chart);renderChart(chart,component.chartData);}
  else if(component.type==='context'){if(!component.eventRefs.length)section.append(el('p','','В календаре нет подходящих записей.'));for(const ref of component.eventRefs){const e=data.events[ref];section.append(el('p','',e.from+' · '+e.title+' · '+(e.note||'')));}}
  else if(component.type==='next_steps'){for(const item of component.items){section.append(el('p','',item.text));facts(section,data,item.factRefs);}}
  host.append(section);
  if(component.type==='priority_queue'){const proof=el('details','ai-section');proof.append(el('summary','','Основания общего вывода'));facts(proof,data,data.view.summaryRefs);host.append(proof);}
 }
 const coverage=el('details','ai-section');coverage.append(el('summary','','Охват анализа: '+Object.keys(data.members).length+' опросов · '+data.eligible.length+' кандидатов'));
 coverage.append(el('p','','Проверены все опросы отбора. Первичный индекс помогает выбрать кандидатов для модели; финальный приоритет назначает модель с ограничениями по надёжности. Все кандидаты доступны ниже.'));
 const list=el('div');let shown=0;const more=el('button','quiet','Показать следующие');more.type='button';const chosen=new Set(data.view.components[0].items.map(i=>i.key));const ordered=[...data.candidates].sort((a,b)=>b.score-a.score);
 const append=()=>{for(const c of ordered.slice(shown,shown+30)){const row=el('p','', '#'+c.id+' · '+c.name+' · '+(chosen.has(c.key)?'в очереди модели':'вне очереди модели')+' · '+(c.flags.map(f=>flags[f.code]||f.code).join('; ')||'сигналов нет')+' · сопоставимость '+format(c.comparisonCoverage*100)+'%');list.append(row);}shown+=30;more.hidden=shown>=ordered.length;};append();more.onclick=append;coverage.append(list,more);host.append(coverage);
 const thresholds=el('details','ai-section');thresholds.append(el('summary','','Критерии и пороги анализа'),el('p','',data.agentPlan.criteriaReason));
 const names={minAnswers:'Минимум ответов',answerDropPct:'Снижение ответов, %',sendChangePct:'Изменение отправок, %',csiDrop:'Падение CSI, балла',minCsiSample:'Минимальная выборка CSI',cutoffGrowthPct:'Рост отсечений, %',minCutoffDelta:'Минимальный прирост отсечений',minCoverage:'Доля сопоставимых периодов (0–1)',planGapPct:'Отставание от плана, %'};const fields={};
 for(const [k,v] of Object.entries(data.criteria)){const label=el('label','ai-threshold',names[k]);const input=el('input');input.type='number';input.step='any';input.value=v;fields[k]=input;label.append(input);thresholds.append(label);}
 const rerun=el('button','quiet','Пересмотреть анализ с этими порогами');rerun.type='button';rerun.onclick=()=>onRerun(Object.fromEntries(Object.entries(fields).map(([k,input])=>[k,Number(input.value)])));thresholds.append(rerun);host.append(thresholds);
 const technical=el('details','ai-section');technical.append(el('summary','','Как работал агент'),el('p','','Модель выбрала отбор, критерии, приоритеты и блоки. Расчёты выполнены локально. В CLI переданы агрегаты, названия опросов и контекст календаря; исходные строки CSV не передавались.'),el('p','','Инструменты: '+(data.tools.map(t=>t.tool+' '+t.keys.join(', ')).join('; ')||'первичный расчёт без дополнительной инспекции')));host.append(technical);
}};
})();
