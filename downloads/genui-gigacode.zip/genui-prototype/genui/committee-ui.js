(()=>{
'use strict';
const el=(tag,text,cls)=>{const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(cls)node.className=cls;return node;};
const post=body=>window.TrustUI.post('/api/committee',body);
const num=new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2});
const fmt=value=>Number.isFinite(value)?num.format(value):'—';
const taskStatus={open:'Назначена',in_progress:'В работе',resolved:'Закрыта'};
const packStatus={draft:'Черновик',review:'На согласовании',approved:'Утверждён',rejected:'Возвращён'};
function button(title,run){const control=el('button',title);control.type='button';control.onclick=()=>run(control);return control;}
function field(host,title,type='text',max=120){
 const label=el('label',title),input=el(type==='textarea'?'textarea':'input');
 if(type!=='textarea')input.type=type;
 if(type==='text'||type==='textarea')input.maxLength=max;
 input.setAttribute('aria-label',title);label.append(input);host.append(label);return input;
}
async function busy(control,output,work){
 control.disabled=true;output.textContent='Выполняю…';
 try{await work();}catch(error){output.textContent=error.message;}finally{control.disabled=false;}
}
function history(host,items,statuses){
 const details=el('details');details.append(el('summary','История'));
 for(const item of items)details.append(el('p',new Date(item.at).toLocaleString('ru-RU')+' · '+item.actor+' · '+statuses[item.status]+(item.note?' · '+item.note:'')));
 host.append(details);
}

function signalFacts(host,signal){
 const rows=[['События','events'],['Доля отправок','sendShare',true],['Ответы','answers'],['CSI','csi'],['Доля стоп-листов','stopShare',true],['Доля политики контактов','contactPolicyShare',true],['Доля остатка / перекрытия','otherShare',true]];
 const wrap=el('div',undefined,'table-wrap'),table=el('table'),head=el('thead'),tr=el('tr'),body=el('tbody');
 for(const name of ['Показатель','Предыдущая неделя','Текущая неделя','Изменение'])tr.append(el('th',name));head.append(tr);
 for(const [label,key,share] of rows){
  const row=el('tr');row.append(el('th',label));
  for(const [values,suffix] of [[signal.baseline,'%'],[signal.current,'%'],[signal.delta,' п.п.']])row.append(el('td',fmt(values[key])+(share&&Number.isFinite(values[key])?suffix:'')));
  body.append(row);
 }
 table.append(head,body);wrap.append(table);host.append(wrap,el('p','Сравниваются '+signal.pairedDays.length+' пар одинаковых дней недели. Остаток равен событиям минус отправки и известные отсечения. Отрицательное значение показывает перекрытие.', 'overview-source'));
 if(signal.remainingStatuses?.length){
  const details=el('details');details.append(el('summary','Остальные статусы · события минус отправки'));
  for(const row of signal.remainingStatuses)details.append(el('p',row.status+' · '+fmt(row.baseline)+' → '+fmt(row.current)+' · изменение '+fmt(row.delta)));
  host.append(details);
 }
}

function create(main){
 const page=el('section',undefined,'trust-page');page.hidden=true;main.append(page);
 const link=el('a','Утренний мониторинг','nav-item');link.href='#morning-monitor';document.querySelector('.rail').insertBefore(link,document.querySelector('.history'));
 function show(){
  page.replaceChildren(el('h1','Утренний мониторинг'),el('p','Проверка двух недель по парам одинаковых дней. Сигналы и задачи рассчитаны локально.'));
  const filters=el('div',undefined,'workflow-controls'),survey=field(filters,'Опрос','number'),through=field(filters,'Последний день окна','date'),channel=el('select');
  survey.min='1';survey.max='9999999';survey.placeholder='Все опросы';channel.setAttribute('aria-label','Канал мониторинга');
  channel.add(new Option('Пуш + СМС','communication'));channel.add(new Option('Экран успеха','success_screen'));filters.append(channel);
  const status=el('p'),queue=el('div'),tasks=el('div');status.setAttribute('role','status');
  const scan=button('Рассчитать сигналы',control=>busy(control,status,async()=>{
   const query={survey:survey.value?Number(survey.value):null,through:through.value,channel:channel.value};
   const data=await post({action:'monitor',...query});queue.replaceChildren(el('h2','Сигналы'));
   status.textContent=data.message||'Найдено '+data.total+' · по '+data.through+' · версия '+data.revision+(data.total>100?' · показаны первые 100':'');
   if(!data.signals.length)queue.append(el('p','За выбранное окно сигналы не найдены. Для сравнения нужно не менее пяти пар дневных наблюдений.'));
   for(const signal of data.signals){
    const item=el('article',undefined,'trust-card'),assign=el('details'),controls=el('div',undefined,'workflow-controls'),message=el('p');
    const origin={...query,through:data.through,key:signal.key,revision:data.revision};
    item.append(el('h3','#'+signal.id+' · '+signal.name),el('p',signal.reasons.join(' · ')));signalFacts(item,signal);
    assign.append(el('summary','Назначить проверку'));
    const owner=field(controls,'Ответственный'),actor=field(controls,'Кто назначил'),due=field(controls,'Срок','date');
    const check=field(controls,'Что проверить','textarea',500),review=el('div'),reviewStatus=el('p'),reviewControls=el('div',undefined,'workflow-controls'),model=el('input');
    model.type='checkbox';const label=el('label','Упорядочить проверки через GigaCode');label.prepend(model);
    reviewControls.append(label,button('Разобрать сигнал',control=>busy(control,reviewStatus,async()=>{
     const result=await post({action:'signal-review',...origin,useModel:model.checked});review.replaceChildren();
     const facts=new Map(result.facts.map(f=>[f.ref,f]));
     review.append(el('p','Возможные проверки. Совпадение по времени требует подтверждения.'));
     for(const option of result.checks){
      const row=el('div',undefined,'ai-section');row.append(el('p',option.label));
      for(const ref of option.refs){
       const fact=facts.get(ref);
       row.append(el('small',fact.label+' · '+fmt(fact.baseline)+' → '+fmt(fact.current)+' · изменение '+fmt(fact.delta)+' '+fact.unit));
      }
      row.append(button('Назначить эту проверку',()=>{check.value=option.label;assign.open=true;owner.focus();}));review.append(row);
     }
     if(result.calendar.length)review.append(el('p','Совпало с календарём: '+result.calendar.map(event=>event.from+' · '+event.title).join(' / ')));
     reviewStatus.textContent=result.warning|| (result.origin==='gigacode'?'Порядок проверок предложила GigaCode.':'Проверки подобраны по локальным правилам.');
    })));
    item.append(reviewControls,reviewStatus,review);
    controls.append(button('Создать задачу',save=>busy(save,message,async()=>{
     await post({action:'assign',...origin,actor:actor.value,owner:owner.value,due:due.value,check:check.value});
     assign.open=false;await refreshTasks();status.textContent='Задача назначена '+owner.value+'.';
    })));
    assign.append(controls,message);item.append(assign);queue.append(item);
   }
  }));
  filters.append(scan);page.append(filters,status,queue,tasks);
  async function refreshTasks(){
   const items=await post({action:'tasks'});tasks.replaceChildren(el('h2','Задачи'));
   if(!items.length)tasks.append(el('p','Назначенные проверки появятся здесь.'));
   for(const item of items){
    const card=el('article',undefined,'trust-card');
    card.append(el('h3','#'+item.signal.id+' · '+taskStatus[item.status]),el('p',item.owner+' · срок '+item.due+' · данные '+item.signal.through));
    if(item.check)card.append(el('p',item.check));
    const evidence=el('details');evidence.append(el('summary','Отклонение на момент назначения'));signalFacts(evidence,item.signal);card.append(evidence);history(card,item.history,taskStatus);
    const controls=el('div',undefined,'workflow-controls'),actor=field(controls,'Кто меняет статус'),note=field(controls,'Результат проверки','textarea',2000),message=el('p');
    actor.value=item.owner;
    function change(label,next){return button(label,control=>busy(control,message,async()=>{await post({action:'task-update',id:item.id,version:item.version,status:next,actor:actor.value,note:note.value});await refreshTasks();}));}
    if(item.status!=='in_progress')controls.append(change(item.status==='resolved'?'Возобновить':'Взять в работу','in_progress'));
    if(item.status!=='resolved')controls.append(change('Закрыть с результатом','resolved'));
    card.append(controls,message);tasks.append(card);
   }
  }
  refreshTasks().catch(error=>{status.textContent=error.message;});
  scan.click();
 }
 return {page,show};
}

function summaryLines(pack){
 const source=pack.snapshot;
 if(source.scopeChanged)return ['Настройки сценария изменились. Для этого пакета создана новая база сравнения.'];
 return source.comparison.flatMap((item,i)=>{
  if(item.firstRun)return [];
  const prefix=(source.titles[i]||'График '+(i+1)).slice(0,120);
  const changed=item.totals.filter(total=>total.delta!==null&&total.delta!==0);
  return [prefix+(item.periodChanged?' · период изменился':''),...changed.slice(0,6).map(total=>total.label+': '+fmt(total.previous)+' → '+fmt(total.current))];
 });
}

function compositionOf(data){
 const events=data.blocks.find(block=>block.metric==='events');
 const keys=['sends','stop','contactPolicy'];
 if(!events||!keys.every(key=>data.blocks.some(block=>block.metric===key&&block.id===events.id)))return null;
 const blocks=structuredClone([events,...keys.map(key=>data.blocks.find(block=>block.metric===key&&block.id===events.id))]);
 for(const block of blocks){
  const baseValues=[...events.values];
  block.ratio={baseMetric:'events',baseValues,values:block.values.map((value,i)=>Number.isFinite(value)&&baseValues[i]>0?value/baseValues[i]*100:null)};
 }
 return {...data,blocks,breakdownLineMetric:'events',breakdownParts:keys};
}

async function downloadPack(pack){
 const source=pack.snapshot,pages=[];
 const base={layout:'grid',template:'timeline',theme:'light',subtitle:'',footer:'',notes:[],kpis:[]};
 let compositionAdded=false;const omissions=[];
 for(const [index,data] of source.charts.entries()){
  const title=source.titles[index]||'График '+(index+1);
  const entry={revision:source.revision,presentationTitle:title,chart:{status:'ok',kind:'monthly',title,channel:data.spec.filters?.channel,data}};
  const original=window.PresentationRender.newCard(entry,'committee:'+pack.id);
  const series=original.graph.series.filter(item=>item.values.some(Number.isFinite)).map(item=>item.key);
  if(series.length!==original.selected.length)omissions.push(title+' · ряды без наблюдений: '+original.graph.series.filter(item=>!series.includes(item.key)).map(item=>item.label).join(', '));
  for(let start=0;index!==source.compositionIndex&&start<series.length;start+=6){
   const selected=series.slice(start,start+6),card={...original,selected,headline:selected[0]};
   const heading=pages.length===0?source.name:title+(series.length>6?' · часть '+(start/6+1):'');
   const overview=pages.length===0;
   const kpis=overview?source.comparison[index].totals.filter(total=>Number.isFinite(total.current)).slice(0,3).map(total=>({
    label:total.label+(total.id?' · #'+total.id:''),value:total.previous===null?fmt(total.current):fmt(total.previous)+' → '+fmt(total.current),
    detail:total.previous===null?'Текущий период':source.comparison[index].periodChanged?'Интервалы различаются':'Предыдущий утверждённый пакет и текущий'
   })):[];
   const conclusion=source.conclusion||'';
   pages.push({...base,template:overview?'comparison':'timeline',kpis,title:heading.slice(0,180),subtitle:overview?(conclusion.length>210?conclusion.slice(0,205)+'…':conclusion):data.periodLabel,
    footer:'Версия данных '+source.revision+' · согласовал '+pack.history.at(-1).actor,cards:[card]});
  }
  const composition=compositionAdded?null:compositionOf(data);
  if(composition){
   const chart=window.PresentationRender.newCard({...entry,presentationTitle:'Объём и состав событий',chart:{...entry.chart,kind:'events-breakdown',data:composition}},'committee:'+pack.id+':composition');
   pages.push({...base,template:'composition',title:'Состав событий',subtitle:data.periodLabel,cards:[chart]});
   compositionAdded=true;
  }
 }
 await document.fonts.ready;
 const lines=summaryLines(pack);
 const pptx=await window.PresentationOffice.powerPoint(pages,(page,index)=>window.PresentationRender.render(page,{editable:true,pageNumber:index+1,pageCount:pages.length}),{
  notes:()=>['Версия данных '+source.revision,'Снимок '+pack.hash,'Предыдущий утверждённый пакет '+(source.previousApproved?.id||'—'),source.conclusion,...lines,...omissions].filter(Boolean).join('\n')
 });
 const comparison=[['График','Показатель','Опрос','Предыдущий пакет','Текущий пакет','Изменение','Сравнение']];
 source.comparison.forEach((item,i)=>item.totals.forEach(total=>comparison.push([source.titles[i],total.label,total.id,total.previous,total.current,total.delta,source.scopeChanged?'Настройки изменились':item.firstRun?'Первая версия':item.periodChanged?'Интервалы различаются':'Сопоставимый период'])));
 const workbook=await window.PresentationOffice.workbook(pages,{comparison});
 const manifest={id:pack.id,scenario:source.name,hash:pack.hash,revision:source.revision,metricVersion:source.metricVersion,history:pack.history,previousApproved:source.previousApproved,scopeChanged:source.scopeChanged,comparison:source.comparison};
 const zip=new window.JSZip();
 zip.file('committee.pptx',await pptx.arrayBuffer());zip.file('committee.xlsx',await workbook.arrayBuffer());zip.file('manifest.json',JSON.stringify(manifest,null,2));
 window.MeetingExports.saveBlob(await zip.generateAsync({type:'blob',compression:'DEFLATE'}),'committee-'+pack.id.slice(0,10)+'.zip');
}

function attachPacks(host,source,{model=false,archive=false}={}){
 const target=typeof source==='string'?{scenario:source}:source||{};
 const panel=el('details',undefined,'method');panel.append(el('summary',archive?'Пакеты из диалога':'Пакет на комитет'));
 const controls=el('div',undefined,'workflow-controls'),author=field(controls,'Автор пакета'),conclusion=field(controls,'Вывод для комитета','textarea',600),status=el('p'),list=el('div');
 let sourceHash='';
 if(model&&!archive)controls.append(button('Подготовить вывод через GigaCode',control=>busy(control,status,async()=>{
  const draft=await post({action:'pack-draft',...target});conclusion.value=draft.conclusion;sourceHash=draft.sourceHash;
  status.textContent='Вывод собран по рассчитанным точкам. Проверьте текст перед сохранением.';
 })));
 controls.append(button('Собрать черновик',control=>busy(control,status,async()=>{
  await post({action:'pack-create',...target,actor:author.value,conclusion:conclusion.value,sourceHash});await load();status.textContent='Черновик собран по зафиксированным данным.';
 })));
 panel.append(el('p','В согласовании используются имена, указанные участниками в локальном проекте.'));if(!archive)panel.append(controls);panel.append(status,list);host.append(panel);
 panel.ontoggle=()=>{if(panel.open)load().catch(error=>{status.textContent=error.message;});};
 async function load(){
  const packs=await post({action:archive?'packs-model':'packs',...target});list.replaceChildren();
  if(!packs.length)list.append(el('p','Здесь появятся сохранённые пакеты.'));
  for(const pack of packs){
   const card=el('article',undefined,'trust-card'),message=el('p');
   card.append(el('h3',packStatus[pack.status]+' · '+new Date(pack.created).toLocaleString('ru-RU')),el('p','Версия '+pack.revision+' · '+pack.author));history(card,pack.history,packStatus);
   card.append(button('Проверить содержание',control=>busy(control,message,async()=>{
    const full=await post({action:'pack-open',id:pack.id});const detail=el('div');detail.append(el('p',full.snapshot.conclusion||'Вывод не добавлен.'));
    for(const chart of full.snapshot.charts){detail.append(el('p',chart.periodLabel+' · '+chart.totals.map(total=>total.label+' '+fmt(total.value)).join(' · ')));}
    const lines=summaryLines(full);for(const line of lines)detail.append(el('p',line));message.replaceChildren(detail);
   })));
   if(['draft','review'].includes(pack.status)){
    const row=el('div',undefined,'workflow-controls'),actor=field(row,'Участник согласования'),note=field(row,'Комментарий согласования','textarea',1200);
    if(pack.status==='draft')actor.value=pack.author;
    function step(label,next){return button(label,control=>busy(control,message,async()=>{await post({action:'pack-review',id:pack.id,version:pack.version,status:next,actor:actor.value,note:note.value});await load();}));}
    if(pack.status==='draft')row.append(step('На согласование','review'));
    else row.append(step('Утвердить','approved'),step('Вернуть с комментарием','rejected'));
    card.append(row);
   }
   if(pack.status==='approved')card.append(button('Скачать PPTX и Excel',control=>busy(control,message,async()=>{await downloadPack(await post({action:'pack-export',id:pack.id}));message.textContent='Пакет подготовлен.';})));
   card.append(message);list.append(card);
  }
 }
}

function attachQuality(host){
 const details=el('details',undefined,'method'),policy=el('p'),results=el('div'),message=el('p');
 details.append(el('summary','Контур ИИ и эталонные проверки'),policy,el('p','Эталонные проверки используют синтетические данные. Для проверки настроенной модели запустите python release_eval.py --model.'));
 details.append(button('Запустить эталонные проверки',control=>busy(control,message,async()=>{
  const report=await post({action:'evaluate'});message.textContent=report.ok?'Все локальные проверки пройдены.':'Есть отклонения от эталона.';
  results.replaceChildren(...report.cases.map(test=>el('p',(test.ok?'Пройдено · ':'Ошибка · ')+test.name+(test.detail?' · '+test.detail:''))));
 })),message,results);
 details.ontoggle=()=>{if(details.open)post({action:'policy'}).then(result=>{policy.textContent=result.profile==='protected'?'Защищённый режим · разрешённые агрегаты и CLI в режиме plan.':'Режим разработки · экспериментальная генерация разрешена.';}).catch(error=>{policy.textContent=error.message;});};
 host.append(details);
}
window.CommitteeUI={create,attachPacks,attachQuality};
})();
