(()=>{
const $=id=>document.getElementById(id),form=$('queryForm'),input=$('query'),source=$('source'),provider=$('provider'),feed=$('conversation');
const clone=value=>JSON.parse(JSON.stringify(value));
const node=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const fmt=(value,metric)=>value===null?'Нет данных':new Intl.NumberFormat('ru-RU',{maximumFractionDigits:metric==='csi'?2:0}).format(value);
const month=value=>new Intl.DateTimeFormat('ru-RU',{month:'short',year:'numeric',timeZone:'UTC'}).format(new Date(value+'-01T12:00:00Z'));
const palette=['#197b54','#4264b5','#895ba6','#b07835','#13798b','#b34c64','#4f7e24','#815935','#5d62a3','#b05a29','#33748d','#8c466e','#657b2b','#a34738','#4e6578','#796843'];
let turns=[],activeTurn=null,busy=false,serial=0;
const scrollTo=element=>element.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});
function destroyCharts(parent){parent.querySelectorAll('.v2-chart').forEach(chart=>chart.destroy?.());}
function setContext(turn,update=false){activeTurn=turn;$('updateExisting').checked=update;syncContext();}
function syncContext(){
 $('contextBar').hidden=!activeTurn;
 $('contextLabel').textContent=activeTurn?'График №'+activeTurn.number+' · опросы '+activeTurn.data.spec.ids.join(', '):'';
 input.placeholder=activeTurn?'Продолжите: «Добавь ответы» или задайте новый вопрос':'Покажи опрос 193 за 3 месяца';
 $('submitLabel').textContent=$('updateExisting').checked&&activeTurn?'Обновить график':'Отправить';
}
function addMessage(kind,text){const article=node('article','chat-message message-'+kind),head=node('div','message-label',kind==='user'?'Вы':provider.value==='gigacode'?'GigaCode':'GEN UI · локальный разбор');article.append(head);if(text!==undefined)article.append(node('p','message-text',text));feed.append(article);return article;}
function updateHistory(){
 $('history').replaceChildren();for(const turn of [...turns].reverse()){const button=node('button','','№'+turn.number+' · '+turn.query);button.type='button';button.onclick=()=>scrollTo(turn.element);$('history').append(button);}
 if(!turns.length)$('history').append(node('p','muted','Результаты появятся здесь'));
}
function download(data){const quote=v=>'"'+String(v??'').replaceAll('"','""')+'"',rows=[['Опрос','Месяц','Показатель','Значение'],...data.table.map(r=>[r.id,r.month,r.metric,r.value])];const url=URL.createObjectURL(new Blob(['\uFEFF'+rows.map(r=>r.map(quote).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'})),a=node('a');a.href=url;a.download='genui-monitoring.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function renderTurn(turn){
 const data=turn.data,host=turn.element;destroyCharts(host);host.replaceChildren();host.id='answer-'+turn.number;host.dataset.turnId=turn.number;
 const header=node('div','assistant-heading');header.append(node('span','message-label',(data.provider==='gigacode'?'GigaCode':'GEN UI · локальный разбор')+' · график №'+turn.number));
 const downloadButton=node('button','quiet','CSV ↓');downloadButton.type='button';downloadButton.onclick=()=>download(data);header.append(downloadButton);host.append(header);
 const title=data.spec.ids.length>1?'Сравнение опросов '+data.spec.ids.join(' и '):data.blocks[0].name;
 host.append(node('h2','answer-title',title),node('p','interpretation','Опросы: '+data.spec.ids.join(', ')+' · '+[...new Set(data.blocks.map(b=>b.label))].join(', ')+' · '+data.periodLabel));
 host.append(node('p','source-receipt',data.source+'. Последние '+data.months.length+' календарных месяцев относительно данных по '+data.anchor+'.'));
 if(turn.revision)host.append(node('p','revision-note','Обновлено по сообщению: «'+turn.revision+'»'));
 const kpis=node('div','kpis');for(const total of data.totals){const card=node('article','kpi');card.append(node('span','',total.label+' · #'+total.id),node('strong','',fmt(total.value,total.metric)),node('small','',total.note));kpis.append(card);}host.append(kpis);
 const charts=node('div','charts'),tableWrap=node('div','table-wrap');tableWrap.hidden=true;
 const controls=node('div','view-controls'),buttons=node('div');
 const chartButton=node('button','','Графики'),tableButton=node('button','','Таблица'),combineButton=node('button','','На одном графике');
 for(const button of [chartButton,tableButton,combineButton])button.type='button';
 chartButton.dataset.action='charts';tableButton.dataset.action='table';combineButton.dataset.action='combine';
 chartButton.setAttribute('aria-pressed','true');tableButton.setAttribute('aria-pressed','false');combineButton.setAttribute('aria-pressed',String(data.spec.layout==='combined'));
 chartButton.onclick=()=>{charts.hidden=false;tableWrap.hidden=true;chartButton.setAttribute('aria-pressed','true');tableButton.setAttribute('aria-pressed','false');};
 tableButton.onclick=()=>{charts.hidden=true;tableWrap.hidden=false;chartButton.setAttribute('aria-pressed','false');tableButton.setAttribute('aria-pressed','true');};
 combineButton.onclick=()=>{if(busy)return;data.spec.layout=data.spec.layout==='combined'?'separate':'combined';renderTurn(turn);if(activeTurn===turn)syncContext();};
 buttons.append(chartButton,tableButton,combineButton);controls.append(buttons,node('span','','Количество слева · CSI 1–5 справа'));host.append(controls,charts);
 const combined=data.spec.layout==='combined',groups=combined?[data.blocks]:data.spec.metrics.map(metric=>data.blocks.filter(b=>b.metric===metric));
 for(const blocks of groups){const key=b=>b.metric+':'+b.id,rows=data.months.map((m,i)=>({key:m,label:month(m),short:month(m),...Object.fromEntries(blocks.map(b=>[key(b),b.values[i]]))}));
 window.V2Chart(charts,{title:combined?[...new Set(blocks.map(b=>b.label))].join(' · '):blocks[0].label,badge:combined?'Совмещённый график':'Динамика',context:data.periodLabel,help:'Линии можно отключать в легенде. Последний месяц может быть неполным.',modes:[{key:'month',label:'По месяцам',rows}],series:blocks.map((b,i)=>({key:key(b),label:b.label+' · #'+b.id+' · '+b.name,color:palette[i%palette.length],dash:b.metric==='csi'?'6 4':b.metric==='answers'?'3 3':null,total:b.values.at(-1)})),receipt:[['Источник',data.source],['Расчёт','Количество суммируется по записям месяца. CSI — средняя оценка месяца; месячные CSI не суммируются.'],['Шкалы','Количество — левая шкала. CSI — правая, от 1 до 5; когда остаётся только CSI, его шкала переносится влево.'],['Полнота',data.warnings.join(' ')]]});}
 const table=node('table'),thead=node('thead'),tr=node('tr');for(const h of ['Опрос','Месяц','Показатель','Значение']){const th=node('th','',h);th.scope='col';tr.append(th);}thead.append(tr);table.append(thead);const tbody=node('tbody');for(const row of data.table){const tr=node('tr');for(const value of ['#'+row.id,month(row.month),row.metric,fmt(row.value,row.metric==='CSI'?'csi':'count')])tr.append(node('td','',value));tbody.append(tr);}table.append(tbody);tableWrap.append(table);host.append(tableWrap);
 const method=node('details','method');method.append(node('summary','','Источники и полнота данных'));for(const warning of data.warnings)method.append(node('p','',warning));method.append(node('p','','Ответ фиксирует данные на момент запроса. Новый запрос перечитывает CSV. Пропуски не заменяются нулями.'));host.append(method);
 const chips=node('div','followups');chips.append(node('span','','Продолжить от этого графика'));
 for(const [label,query] of [['＋ Ответы','Добавь ответы'],['＋ CSI','Добавь CSI и объедини на одном графике'],['Сравнить с 1007','Сравни с опросом 1007'],['За 6 месяцев','Теперь за последние 6 месяцев']]){const button=node('button','suggestion',label);button.type='button';button.dataset.followup=query;button.onclick=()=>send(query,{turn,update:false,source:turn.source,provider:provider.value});chips.append(button);}
 const edit=node('button','edit-chart','Изменить этот график');edit.type='button';edit.dataset.action='edit';edit.onclick=()=>{if(busy)return;source.value=turn.source;updateSource();setContext(turn,true);input.focus();scrollTo($('composer'));};chips.append(edit);host.append(chips);
}
function setBusy(value){busy=value;for(const control of [$('submit'),source,provider,$('newSession'),$('updateExisting'),$('clearContext')])control.disabled=value;feed.querySelectorAll('.suggestion,.edit-chart,[data-action="combine"]').forEach(b=>b.disabled=value);}
async function send(query,options){
 if(busy)return;query=query.trim();if(!query){$('error').textContent='Напишите сообщение или выберите подсказку.';$('error').hidden=false;input.focus();return;}
 const context=options||{turn:activeTurn,update:$('updateExisting').checked,source:source.value,provider:provider.value};
 source.value=context.source;updateSource();provider.value=context.provider;provider.onchange();
 const request={query,source:context.source,provider:context.provider,previous:context.turn?clone(context.turn.data.spec):null};
 const target=context.update?context.turn:null;
 $('error').hidden=true;$('intro').hidden=true;$('examples').hidden=true;document.body.classList.add('chat-started');
 const user=addMessage('user',query);user.append(node('small','message-context',request.source==='demo'?'Архивный пример':'Мои CSV'));
 if(context.turn)user.append(node('small','message-context',(target?'Изменение':'Продолжение')+' графика №'+context.turn.number));
 const responseElement=addMessage('assistant');const loading=node('div','skeleton',request.provider==='gigacode'?'GigaCode обрабатывает запрос…':'Читаем данные и собираем график…');loading.setAttribute('role','status');responseElement.append(loading);
 input.value='';setBusy(true);scrollTo(user);
 try{const response=await fetch('/api/genui',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(request)});const data=await response.json();if(!response.ok)throw new Error(data.error||'Не удалось обработать сообщение.');
 if(target){target.data=clone(data);target.revision=query;renderTurn(target);responseElement.replaceChildren(node('div','message-label','GEN UI'),node('p','message-text','График №'+target.number+' обновлён. Остальные результаты сохранены.'));const link=node('a','jump-answer','Перейти к обновлённому графику ↑');link.href='#'+target.element.id;responseElement.append(link);setContext(target,false);}
 else{const turn={number:++serial,query,data:clone(data),source:request.source,element:responseElement};turn.element.classList.add('answer');turns.push(turn);renderTurn(turn);setContext(turn,false);}
 updateHistory();scrollTo(responseElement);
 }catch(e){responseElement.replaceChildren(node('div','message-label','Не удалось построить график'));const failure=node('p','error',e.message);failure.setAttribute('role','alert');responseElement.append(failure);const retry=node('button','quiet','Повторить запрос');retry.type='button';retry.onclick=()=>send(query,context);responseElement.append(retry);scrollTo(responseElement);
 }finally{setBusy(false);input.focus({preventScroll:true});}
}
form.addEventListener('submit',e=>{e.preventDefault();send(input.value);});input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
document.querySelectorAll('[data-query]').forEach(b=>b.onclick=()=>send(b.dataset.query,{turn:null,update:false,source:source.value,provider:provider.value}));
function updateSource(){$('sourceBadge').textContent=source.value==='demo'?'Архивный пример':'Мои CSV';$('sourceHint').textContent=source.value==='demo'?'Архивный пример из предыдущей версии. Ваши CSV не изменяются.':'date/push-sms.csv и date/success-screen.csv перечитываются при каждом запросе.';}
source.onchange=()=>{setContext(null,false);updateSource();};
provider.onchange=()=>{$('providerBadge').textContent=provider.value==='gigacode'?'GigaCode CLI':'Локальный разбор';};
$('clearContext').onclick=()=>setContext(null,false);$('updateExisting').onchange=syncContext;
$('newSession').onclick=()=>{if(busy)return;destroyCharts(feed);feed.replaceChildren();turns=[];serial=0;setContext(null,false);updateHistory();$('intro').hidden=false;$('examples').hidden=false;$('error').hidden=true;document.body.classList.remove('chat-started');input.value='';input.focus();window.scrollTo({top:0,behavior:'instant'});};
fetch('/api/genui/status').then(r=>r.json()).then(status=>{$('cliStatus').textContent=status.configured?'CLI настроена; авторизация проверяется при запросе.':'CLI не настроена. Можно использовать локальный разбор.';if(status.configured&&!busy&&!turns.length){provider.value='gigacode';provider.onchange();}}).catch(()=>{$('cliStatus').textContent='Не удалось проверить CLI. Обновите страницу.';});
updateSource();syncContext();
})();
