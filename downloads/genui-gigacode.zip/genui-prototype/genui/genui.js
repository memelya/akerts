(()=>{
const $=id=>document.getElementById(id),form=$('queryForm'),input=$('query'),source=$('source'),provider=$('provider'),feed=$('conversation');
const clone=value=>JSON.parse(JSON.stringify(value));
const node=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const fmt=(value,metric)=>value===null?'Нет данных':new Intl.NumberFormat('ru-RU',{maximumFractionDigits:metric==='csi'?2:0}).format(value);
const surveyLabel=id=>id===null?'Все выбранные опросы':'#'+id;
const month=value=>new Intl.DateTimeFormat('ru-RU',{day:value.length===10?'numeric':undefined,month:'short',year:'numeric',timeZone:'UTC'}).format(new Date(value+(value.length===7?'-01':'')+'T12:00:00Z'));
const palette=['#ff8a35','#c3c8d0','#8da9c4','#d5b278','#b59cbd','#79aa95','#c4837a','#9b9fa8','#b1ba8d','#8cadd0','#c7a397','#8db8b3','#cfb57d','#ad96b8','#94a1ac','#b2aa92'];
let turns=[],activeTurn=null,busy=false,serial=0,creativeBaseOverride=null;
const focusUI=window.FocusWorkspace.create({main:$('main'),feed,composer:$('composer'),onSelect:number=>{if(busy)return;const turn=turns.find(t=>t.number===number);if(turn){setContext(turn,true);focusUI.show(turn,turns);}},onNew:()=>{setContext(null,false);focusUI.chat();input.focus({preventScroll:true});focusUI.notice('Новый график · предыдущий останется в истории');},onUndo:turn=>{if(busy||!turn?.versions?.length)return;const before=clone(turn.data),saved=turn.versions.pop();turn.data=saved.data;turn.revision=saved.revision;turn.step=(turn.step||1)+1;turn.deltaTitle='Возвращён предыдущий шаг';turn.delta=window.FocusWorkspace.delta(before,turn.data);renderTurn(turn);setContext(turn,true);focusUI.show(turn,turns);}});
const favoritesKey='genui-favorites-v1';
let favorites=[];try{favorites=JSON.parse(localStorage.getItem(favoritesKey)||'[]');if(!Array.isArray(favorites))favorites=[];}catch{}
const favoritesPage=node('section','conversation');favoritesPage.hidden=true;$('main').append(favoritesPage);
const favoriteNav=node('a','nav-item','Избранное');favoriteNav.href='#favorites';document.querySelector('.rail').insertBefore(favoriteNav,document.querySelector('.history'));
function saveFavorites(){try{localStorage.setItem(favoritesKey,JSON.stringify(favorites));return true;}catch{alert('Не удалось сохранить избранное: хранилище браузера недоступно или заполнено.');return false;}}
function showFavorites(){const showing=location.hash==='#favorites';for(const child of $('main').children)child.hidden=showing;favoritesPage.hidden=!showing;if(!showing){refreshStatus();syncContext();return;}destroyCharts(favoritesPage);favoritesPage.replaceChildren(node('h1','','Избранное'),node('p','','Сохранённые снимки графиков. Хранятся в этом браузере на текущем адресе и сохраняются после F5.'));
 if(!favorites.length)favoritesPage.append(node('p','','Выберите «В избранное» под нужными графиками в диалоге.'));
 for(const item of favorites){const host=node('article','chat-message answer');favoritesPage.append(host);renderTurn({...clone(item),element:host,favorite:true});}
}
const logPage=node('section','conversation');logPage.hidden=true;$('main').append(logPage);
const logNav=node('a','nav-item','Лог GigaCode');logNav.href='#agent-log';document.querySelector('.rail').insertBefore(logNav,document.querySelector('.history'));
const trustUI=window.TrustUI.create({main:$('main'),onChange:()=>refreshStatus()});
const creativeNav=node('button','nav-item','Библиотека визуализаций');creativeNav.type='button';creativeNav.onclick=()=>!busy&&window.CreativeUI.library((data,refinement)=>{openSavedChart(data,data.query||data.bundle.title);if(refinement){creativeBaseOverride=data.savedId||data.jobId;$('creativeMode').checked=true;$('creativeMode').onchange();focusUI.chat();input.value=refinement;input.focus({preventScroll:true});}});document.querySelector('.rail').insertBefore(creativeNav,document.querySelector('.history'));const creativeShortcut=node('button','','Библиотека визуализаций');creativeShortcut.type='button';creativeShortcut.onclick=creativeNav.onclick;document.querySelector('.data-actions').append(creativeShortcut);
const workflowsUI=window.WorkflowsUI.create({main:$('main'),getTurns:()=>turns.filter(t=>!['ai-workspace','generated-ui'].includes(t.data.kind)),onOpen:openSavedChart});
for(const [label,hash] of [['\u0420\u0430\u0431\u043e\u0447\u0438\u0435 \u0441\u0446\u0435\u043d\u0430\u0440\u0438\u0438','#scenarios'],['\u041a\u0430\u043b\u0435\u043d\u0434\u0430\u0440\u044c \u0437\u0430\u043f\u0443\u0441\u043a\u043e\u0432','#calendar']]){const link=node('a','nav-item',label);link.href=hash;document.querySelector('.rail').insertBefore(link,document.querySelector('.history'));const shortcut=node('a','',label);shortcut.href=hash;document.querySelector('.data-actions').append(shortcut);}
for(const [label,hash] of [['Диагностика','#diagnostics'],['Качество данных','#trust'],['Словарь показателей','#metrics']]){const link=node('a','nav-item',label);link.href=hash;document.querySelector('.rail').insertBefore(link,document.querySelector('.history'));const shortcut=node('a','',label);shortcut.href=hash;document.querySelector('.data-actions').append(shortcut);}
async function showAgentLog(){
 const showing=location.hash==='#agent-log';logPage.hidden=!showing;if(!showing)return;
 for(const child of $('main').children)child.hidden=child!==logPage;
 logPage.replaceChildren(node('h1','','Лог GigaCode'),node('p','','Последние 200 записей вызовов и этапов запроса. Ответ CLI и готовность результата показываются отдельно. История хранится локально.'));
 const refresh=node('button','suggestion','Обновить лог');refresh.onclick=showAgentLog;logPage.append(refresh);
 try{const response=await fetch('/api/genui/log');if(!response.ok)throw new Error('Не удалось загрузить лог');const rows=await response.json();if(location.hash!=='#agent-log')return;
 if(!rows.length)logPage.append(node('p','','Обращений пока нет. Выберите GigaCode и отправьте запрос в диалоге.'));
 for(const entry of rows.slice().reverse()){
 const stages={'creative-plan':'Выбор данных моделью','creative-plan-repair':'Исправление параметров моделью','creative-plan-validation':'Проверка параметров платформой','creative-data':'Подготовка полного набора','creative-plan-confirmation':'Подтверждение состава расчёта','creative-code':'Генерация кода моделью','creative-generation':'Ожидание кода от модели','creative-generation-retry':'Повтор генерации по подтверждённым данным','creative-target-plan':'Дневной план из запроса · локальный разбор','creative-calculated-view':'Стандартный просмотр расчёта','creative-metadata-repair':'Исправление пояснений · код сохранён','creative-code-validation':'Проверка кода и ссылок','creative-preview':'Проверка предпросмотра','creative-apply':'Применение пользователем'};
 const pipeline=entry.mode==='pipeline',outcome=entry.status==='waiting'?'Ожидает решения':entry.status==='clarification'?'Нужно уточнение':entry.status==='cancelled'?'Остановлено':entry.status==='ok'?(pipeline?'Этап пройден':entry.mode==='local-rule'?'Разобрано правилами':'Ответ CLI получен · параметры проверяются отдельно'):(pipeline?'Этап не пройден':'Ошибка CLI');
 const card=node('article','chat-message answer');card.append(node('div','message-label',new Date(entry.time).toLocaleString('ru-RU')+' · '+entry.durationMs+' мс · '+(pipeline?'Платформа':entry.mode==='local-rule'?'Встроенный обработчик':'GigaCode CLI')+' · '+(stages[entry.stage]||entry.stage||'план графика')+' · '+outcome));
 card.append(node('h3','','Пользователь'),node('p','message-text',entry.query));
 card.append(node('h3','','Ответ агента'));const reply=node('pre','',entry.response||entry.error||entry.detail||(entry.mode==='local-rule'?'Запрос разобран встроенным обработчиком, CLI не вызывалась.':''));reply.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere';card.append(reply);
 for(const [label,value] of [['Проверенные параметры этапа',entry.details],['Параметры графика',entry.spec],['Контекст предыдущего графика',entry.previous],['Полный запрос к агенту',entry.prompt]])if(value){const details=node('details','');details.append(node('summary','',label));const pre=node('pre','',typeof value==='string'?value:JSON.stringify(value,null,2));pre.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere';details.append(pre);card.append(details);}
 if(entry.error&&entry.response)card.append(node('p','message-text',entry.error));logPage.append(card);
 }
 }catch(error){logPage.append(node('p','',error.message));}
}
function showPage(){
 document.body.classList.toggle('focus-browse',['#favorites','#agent-log','#trust','#metrics','#diagnostics','#scenarios','#calendar'].includes(location.hash));
 if(['#scenarios','#calendar'].includes(location.hash)){const selected=location.hash==='#scenarios'?workflowsUI.scenarios:workflowsUI.calendar;for(const child of $('main').children)child.hidden=child!==selected;if(location.hash==='#scenarios')workflowsUI.showScenarios();else workflowsUI.showCalendar();return;}
 if(['#trust','#metrics','#diagnostics'].includes(location.hash)){const selected=location.hash==='#trust'?trustUI.page:location.hash==='#diagnostics'?trustUI.diagnostics:location.hash==='#scenarios'?workflowsUI.scenarios:location.hash==='#calendar'?workflowsUI.calendar:trustUI.metrics;for(const child of $('main').children)child.hidden=child!==selected;if(location.hash==='#trust')trustUI.show();else if(location.hash==='#diagnostics')trustUI.showDiagnostics();else trustUI.showMetrics();return;}
 showFavorites();trustUI.page.hidden=trustUI.metrics.hidden=trustUI.diagnostics.hidden=workflowsUI.scenarios.hidden=workflowsUI.calendar.hidden=true;focusUI.root.hidden=!document.body.classList.contains('focus-active')||document.body.classList.contains('focus-browse');logPage.hidden=location.hash!=='#agent-log';showAgentLog();
}
function openSavedChart(data,query){
 if(busy)return;location.hash='#';focusUI.start();$('intro').hidden=$('examples').hidden=true;document.body.classList.add('chat-started');
 const element=node('article','chat-message answer');feed.append(element);const turn={number:++serial,query,messages:data.scenarioQueries||[query],data:clone(data),source:'local',element,step:1,delta:['\u041e\u0442\u043a\u0440\u044b\u0442 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u044b\u0439 \u0440\u0430\u0441\u0447\u0451\u0442.']};turns.push(turn);renderTurn(turn);setContext(turn,true);updateHistory();focusUI.show(turn,turns);
}

window.addEventListener('hashchange',showPage);
async function exportPng(data){
 const canvas=document.createElement('canvas');canvas.width=1600;canvas.height=900;const c=canvas.getContext('2d');c.fillStyle='#181818';c.fillRect(0,0,1600,900);c.fillStyle='#f0f0f0';c.font='bold 28px sans-serif';c.fillText('GEN UI · '+data.periodLabel,70,50);c.font='18px sans-serif';
 const colors=data.visual?.theme==='presentation'?['#ffad66','#7eb8cc','#d3c6a5','#b0a5d7','#84b5a0','#e4a7a0']:palette;const blocks=data.blocks,left=90,right=1490,top=Math.max(220,130+Math.ceil(data.blocks.length/3)*25),bottom=780;
 blocks.forEach((b,i)=>{c.fillStyle=colors[i%colors.length];c.fillText(b.label+' · '+surveyLabel(b.id),70+(i%3)*500,90+Math.floor(i/3)*25);});
 const quantities=blocks.filter(b=>b.metric!=='csi').flatMap(b=>b.values).filter(v=>v!==null),max=Math.max(1,...quantities);
 c.strokeStyle='#313131';c.fillStyle='#b5b5b5';for(let i=0;i<=5;i++){let y=bottom-(bottom-top)*i/5;c.beginPath();c.moveTo(left,y);c.lineTo(right,y);c.stroke();c.fillText(Math.round(max*i/5).toLocaleString('ru-RU'),5,y);}
 if(blocks.some(b=>b.metric==='csi'))for(let i=1;i<=5;i++)c.fillText('CSI '+i,right+12,bottom-(bottom-top)*(i-1)/4);
 const x=i=>left+(right-left)*i/Math.max(1,data.months.length-1);
 blocks.forEach((b,j)=>{c.strokeStyle=colors[j%colors.length];c.fillStyle=c.strokeStyle;c.lineWidth=3;c.beginPath();let open=false;b.values.forEach((v,i)=>{if(v===null){open=false;return;}const y=bottom-(bottom-top)*(b.metric==='csi'?(v-1)/4:v/max);if(data.visual?.type==='bars'&&b.metric!=='csi'){const bw=Math.min(40,(right-left)/Math.max(1,data.months.length)/Math.max(1,blocks.length));c.fillRect(x(i)+(j-(blocks.length-1)/2)*bw-bw/2,y,bw*.85,bottom-y);open=false;return;}if(open)c.lineTo(x(i),y);else c.moveTo(x(i),y);open=true;});c.stroke();b.values.forEach((v,i)=>{if(v===null)return;const y=bottom-(bottom-top)*(b.metric==='csi'?(v-1)/4:v/max);c.beginPath();c.arc(x(i),y,4,0,Math.PI*2);c.fill();});});
 c.fillStyle='#b5b5b5';c.font='16px sans-serif';data.months.forEach((m,i)=>{if(i%Math.max(1,Math.ceil(data.months.length/12))===0){c.save();c.translate(x(i),bottom+25);c.rotate(-0.35);c.fillText(m,0,0);c.restore();}});c.fillText('Источник: '+data.source+' · Пропуски не заменяются нулями',70,880);
 canvas.toBlob(blob=>{if(!blob){alert('Не удалось создать PNG');return;}const url=URL.createObjectURL(blob),a=node('a');a.href=url;a.download='genui-chart.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);},'image/png');
}

const scrollTo=element=>element.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});
function destroyCharts(parent){parent.querySelectorAll('.v2-chart').forEach(chart=>chart.destroy?.());parent.querySelectorAll('[data-creative-host]').forEach(host=>host._creativeDispose?.());}
function setContext(turn,update=false){activeTurn=turn;if(turn?.data.kind==='generated-ui'){$('creativeMode').checked=true;$('creativeMode').onchange();}$('updateExisting').checked=update;syncContext();}
function syncContext(){
 $('contextBar').hidden=!activeTurn;
 $('contextLabel').textContent=activeTurn?.data.kind==='generated-ui'?'Новый интерфейс №'+activeTurn.number+' · '+activeTurn.data.bundle.title:activeTurn?'График №'+activeTurn.number+' · '+(activeTurn.data.spec.ids.length?'опросы '+activeTurn.data.spec.ids.join(', '):'Все опросы'):'';
 input.placeholder=activeTurn?.data.kind==='generated-ui'?'Опишите, как изменить интерфейс':activeTurn?'Продолжите: «Добавь ответы» или задайте новый вопрос':'Покажи опрос 193 за 3 месяца';
 $('submitLabel').textContent=$('updateExisting').checked&&activeTurn?(activeTurn.data.kind==='generated-ui'?'Обновить интерфейс':'Обновить график'):'Отправить';
}
function addMessage(kind,text){const message=focusUI.message(kind,text||'');if(kind!=='user'&&provider.value==='gigacode')message.querySelector('.message-label').textContent='GigaCode';return message;}
function updateHistory(){
 $('history').replaceChildren();for(const turn of [...turns].reverse()){const button=node('button','',window.FocusWorkspace.label(turn));button.type='button';button.onclick=()=>{if(busy)return;setContext(turn,true);focusUI.show(turn,turns);};$('history').append(button);}
 if(!turns.length)$('history').append(node('p','muted','Результаты появятся здесь'));
}
function updateView(turn,change,description){
 if(busy)return;
 const saved=clone(turn.data),position=focusUI.stage.scrollTop;
 change();
 if(!turn.favorite&&!turn.drilldown){turn.versions=turn.versions||[];turn.versions.push({data:saved,revision:turn.revision});turn.versions=turn.versions.slice(-8);turn.step=(turn.step||1)+1;turn.delta=[description,'Данные, период и фильтры сохранены.'];turn.deltaTitle='Изменение визуализации';}
 renderTurn(turn);
 if(!turn.favorite&&!turn.drilldown){focusUI.show(turn,turns,false);focusUI.stage.scrollTop=position;}
}
function download(data){const quote=v=>'"'+String(v??'').replaceAll('"','""')+'"',rows=[['Опрос','Месяц','Показатель','Значение'],...data.table.map(r=>[r.id,r.month,r.metric,r.value])];const url=URL.createObjectURL(new Blob(['\uFEFF'+rows.map(r=>r.map(quote).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'})),a=node('a');a.href=url;a.download='genui-monitoring.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
async function exportVisualPng(host,data){
 const svgs=[...host.querySelectorAll('.charts svg')].filter(s=>s.closest('.chat-message')===host&&!s.closest('[hidden]')&&s.getBoundingClientRect().width>0);if(!svgs.length)return exportPng(data);
 const canvas=document.createElement('canvas');canvas.width=1600;canvas.height=140+svgs.length*650;const c=canvas.getContext('2d');c.fillStyle='#181818';c.fillRect(0,0,canvas.width,canvas.height);c.fillStyle='#f0f0f0';c.font='bold 26px sans-serif';c.fillText('GEN UI · '+data.periodLabel,48,48);
 for(let i=0;i<svgs.length;i++){const original=svgs[i],copy=original.cloneNode(true),sources=[original,...original.querySelectorAll('*')],targets=[copy,...copy.querySelectorAll('*')];sources.forEach((element,j)=>{const style=getComputedStyle(element);for(const key of ['fill','stroke','stroke-width','opacity','font-family','font-size','font-weight','paint-order'])targets[j].style.setProperty(key,style.getPropertyValue(key));});copy.setAttribute('xmlns','http://www.w3.org/2000/svg');const box=original.viewBox.baseVal;copy.setAttribute('width',box.width);copy.setAttribute('height',box.height);const url=URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(copy)],{type:'image/svg+xml;charset=utf-8'}));try{const img=new Image();await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=url;});const card=original.closest('.v2-chart')||original.parentElement.parentElement;c.fillStyle='#f0f0f0';c.font='bold 20px sans-serif';c.fillText(card.querySelector('h3').textContent,48,100+i*650);c.font='14px sans-serif';const labels=[...card.querySelectorAll('.v2-chart-series b')].map(n=>n.textContent);labels.forEach((label,j)=>c.fillText(label,48,130+i*650+j*22));const scale=Math.min(1500/box.width,450/box.height);c.drawImage(img,48,180+i*650,box.width*scale,box.height*scale);}finally{URL.revokeObjectURL(url);}}
 canvas.toBlob(blob=>{if(!blob)return;const url=URL.createObjectURL(blob),a=node('a');a.href=url;a.download='genui-chart.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);},'image/png');
}
function renderTurn(turn){
 const data=turn.data,host=turn.element;const visual=data.visual||{type:'line',theme:'default'};const colors=visual.theme==='presentation'?['#ffad66','#7eb8cc','#d3c6a5','#b0a5d7','#84b5a0','#e4a7a0']:palette;destroyCharts(host);host.replaceChildren();host.id='answer-'+turn.number;host.dataset.turnId=turn.number;
 if(data.kind==='generated-ui'){
  host.classList.add('creative-result');window.CreativeUI.render(host,data,{notice:text=>focusUI.notice(text),onRefine:base=>{if(busy)return;creativeBaseOverride=base.savedId||base.jobId;$('creativeMode').checked=true;$('creativeMode').onchange();setContext(turn,true);focusUI.chat();input.placeholder='Что изменить в новой визуализации?';input.focus({preventScroll:true});},onDetail:async key=>{if(busy)return;try{const metric=Object.keys(data.dataset.labels).find(m=>['sends','answers','csi','events','stop','contactPolicy'].includes(m))||'answers',chart=await window.TrustUI.post('/api/ai',{action:'chart',jobId:data.jobId,keys:[key],metrics:[metric]});openSavedChart(chart,'Детализация '+key);}catch(e){focusUI.notice(e.message);}}});return;
 }
 host.classList.remove('creative-result');
 if(data.kind==='ai-workspace'){
  window.AgentUI.render(host,data,{onChart:openSavedChart,onRerun:criteria=>send(turn.revision||turn.query,{turn,update:true,source:'local',provider:'gigacode',criteria}),renderChart:(element,chartData)=>renderTurn({number:turn.number+'-ai-'+Math.random().toString(36).slice(2,7),data:chartData,element,drilldown:true,source:'local'})});return;
 }
 const header=node('div','assistant-heading');header.append(node('span','message-label',(data.contract?.planner==='rules'?'GEN UI · проверенные правила':data.provider==='gigacode'?'GigaCode':'GEN UI · локальный разбор')+' · график №'+turn.number));
 const downloadButton=node('button','quiet','CSV ↓');downloadButton.type='button';downloadButton.onclick=()=>download(data);header.append(downloadButton);
 const png=node('button','quiet','PNG ↓');png.type='button';png.onclick=()=>exportVisualPng(host,data).catch(()=>alert('Не удалось сохранить PNG. Повторите попытку.'));header.append(png);
 const star=node('button','quiet',turn.favorite?'Удалить из избранного':'В избранное');star.type='button';star.onclick=()=>{
 const old=clone(favorites);
 if(turn.favorite){favorites=favorites.filter(f=>f.savedId!==turn.savedId);if(!saveFavorites())favorites=old;showFavorites();}
 else{favorites.push({savedId:Date.now()+'-'+Math.random(),number:turn.number,query:turn.query,data:clone(data),source:turn.source});if(saveFavorites()){star.textContent='Сохранено ✓';star.disabled=true;}else favorites=old;}
 };if(!turn.drilldown)header.append(star);if(!turn.favorite&&!turn.drilldown)workflowsUI.saveButton(turn,header);host.append(header);
 const title=data.spec.ids.length>1?'Сравнение опросов '+data.spec.ids.join(' и '):data.blocks[0].name;
 host.append(node('h2','answer-title',title),node('p','interpretation',(data.spec.ids.length?'Опросы: '+data.spec.ids.join(', '):'Все загруженные опросы')+' · '+[...new Set(data.blocks.map(b=>b.label))].join(', ')+' · '+data.periodLabel));
 host.append(node('p','source-receipt',data.source+' · период '+data.periodLabel+' · последние загруженные наблюдения: '+data.anchor+'.'));
 if(data.contract)host.append(node('p','query-contract','Запрос понят: '+data.contract.interpretation+' · расчёт: '+data.contract.resolvedPeriod+' · версия данных: '+(data.contract.dataRevision||'архивная база')));
 if(turn.revision)host.append(node('p','revision-note','Обновлено по сообщению: «'+turn.revision+'»'));
 const kpis=node('div','kpis');for(const total of data.totals){const card=node('article','kpi');card.append(node('span','',total.label+' · '+surveyLabel(total.id)),node('strong','',fmt(total.value,total.metric)),node('small','',total.note));kpis.append(card);}host.append(kpis);
 let explorer=null,investigation=null;
 const charts=node('div','charts'),tableWrap=node('div','table-wrap');tableWrap.hidden=true;
 const controls=node('div','view-controls'),buttons=node('div');
 const chartButton=node('button','','Графики'),tableButton=node('button','','Таблица'),combineButton=node('button','','На одном графике');
 for(const button of [chartButton,tableButton,combineButton])button.type='button';
 chartButton.dataset.action='charts';tableButton.dataset.action='table';combineButton.dataset.action='combine';
 chartButton.setAttribute('aria-pressed','true');tableButton.setAttribute('aria-pressed','false');combineButton.setAttribute('aria-pressed',String(data.spec.layout==='combined'));
 chartButton.onclick=()=>{charts.hidden=false;tableWrap.hidden=true;chartButton.setAttribute('aria-pressed','true');tableButton.setAttribute('aria-pressed','false');};
 tableButton.onclick=()=>{charts.hidden=true;tableWrap.hidden=false;chartButton.setAttribute('aria-pressed','false');tableButton.setAttribute('aria-pressed','true');};
 combineButton.onclick=()=>{updateView(turn,()=>{data.spec.layout=data.spec.layout==='combined'?'separate':'combined';},data.spec.layout==='combined'?'Показатели разнесены по панелям.':'Показатели объединены на одном графике.');if(activeTurn===turn)syncContext();};
 buttons.append(chartButton,tableButton,combineButton);controls.append(buttons,node('span','','Количество слева · CSI 1–5 справа'));host.append(controls,charts);
 const combined=data.spec.layout==='combined',groups=combined?[data.blocks]:data.spec.metrics.map(metric=>data.blocks.filter(b=>b.metric===metric));
 for(const blocks of groups){const key=b=>b.metric+':'+b.id,rows=data.months.map((m,i)=>({key:m,label:month(m),short:m.length===10?m.slice(8)+'.'+m.slice(5,7):month(m),...Object.fromEntries(blocks.map(b=>[key(b),b.values[i]]))}));
 window.V2Chart(charts,{onSelect:r=>{explorer?.select(r.key);investigation?.select(r.key);},chartType:visual.type,title:combined?[...new Set(blocks.map(b=>b.label))].join(' · '):blocks[0].label,badge:combined?'Совмещённый график':'Динамика',context:data.periodLabel,help:'Линии можно отключать в легенде. Последний месяц может быть неполным.',modes:[{key:'month',label:data.spec.grain==='day'?'По дням':'По месяцам',rows}],series:blocks.map((b,i)=>({key:key(b),label:b.label+' · '+(b.id===null?'Все выбранные опросы':'#'+b.id+' · '+b.name),color:colors[i%colors.length],dash:b.metric==='csi'?'6 4':b.metric==='answers'?'3 3':null,total:b.values.at(-1)})),receipt:[['Источник',data.source],['Расчёт',(data.methods||['Количество суммируется по записям месяца. CSI не суммируется.']).join(' ')],['Шкалы','Количество — левая шкала. CSI — правая, от 1 до 5; когда остаётся только CSI, его шкала переносится влево.'],['Полнота',data.warnings.join(' ')]]});}
 const table=node('table'),thead=node('thead'),tr=node('tr');for(const h of ['Опрос','Месяц','Показатель','Значение']){const th=node('th','',h);th.scope='col';tr.append(th);}thead.append(tr);table.append(thead);const tbody=node('tbody');for(const row of data.table){const tr=node('tr');for(const value of [surveyLabel(row.id),month(row.month),row.metric,fmt(row.value,row.metric==='CSI'?'csi':'count')])tr.append(node('td','',value));tbody.append(tr);}table.append(tbody);tableWrap.append(table);host.append(tableWrap);
 const method=node('details','method');method.append(node('summary','','Источники и полнота данных'));for(const warning of [...(data.methods||[]),...data.warnings])method.append(node('p','',warning));method.append(node('p','','Ответ фиксирует данные на момент запроса. Новый запрос перечитывает CSV. Пропуски не заменяются нулями.'));host.append(method);
 if(data.analysisId)window.TrustUI.attachEvidence(host,data);if(!turn.favorite&&!turn.drilldown)investigation=turn.investigator=workflowsUI.attachInvestigation(turn,host);
 if(data.members){const members=node('details','method');members.append(node('summary','','Какие опросы входят в расчёт · '+data.members.length));for(const member of data.members)members.append(node('p','',`#${member.id} · ${member.name} · ${member.channel==='success_screen'?'Экран успеха':'Пуш+СМС'} · ${member.products.join(', ')}`));host.append(members);}
 if(data.details?.length){const detail=node('details','method');detail.append(node('summary','','Показать графики по каждому опросу'));let ready=false;turn.openDetail=index=>{detail.open=true;requestAnimationFrame(()=>document.getElementById('answer-'+turn.number+'-detail-'+index)?.scrollIntoView({block:'start',behavior:'smooth'}));};detail.ontoggle=()=>{if(!detail.open||ready)return;ready=true;data.details.forEach((data,index)=>{const element=node('article','chat-message answer');detail.append(element);renderTurn({number:turn.number+'-detail-'+index,data,element,drilldown:true});});};host.append(detail);}
 if(turn.drilldown)return;
 explorer=window.ProductExplorer?.attach({data,charts,colors,onOpen:index=>turn.openDetail?.(index)});
 const design=node('section','visual-design');design.append(node('h3','','Попробуйте другой взгляд на данные'),node('p','','Выберите вариант — график преобразится сразу. Значения и период сохраняются.'));
 const variants={bars:['Сравнить столбцами','Удобно сопоставить периоды; CSI остаётся линией.'],area:['Подчеркнуть динамику','Заливка выделит изменение первого количественного показателя.'],presentation:['Палитра для презентации','Контрастные фиолетовые, бирюзовые и янтарные акценты.'],panels:['Разнести по панелям','Отдельная шкала для каждого показателя раскроет небольшие изменения.']};
 const proposed=[...new Set(data.spec.visualSuggestions||[data.months.length>16?'area':'bars','presentation',data.blocks.length>1?'panels':'area'])].slice(0,3);
 const choices=node('div','visual-choices');
 for(const key of proposed){const button=node('button','visual-option');button.type='button';button.dataset.visual=key;button.append(node('strong','',variants[key][0]),node('span','',variants[key][1]));button.onclick=()=>updateView(turn,()=>{if(!data.originalLayout)data.originalLayout=data.spec.layout;data.visual={...visual};if(key==='presentation')data.visual.theme=visual.theme==='presentation'?'default':'presentation';else if(key==='panels')data.spec.layout='separate';else data.visual.type=key;},variants[key][0]+'.');choices.append(button);}
 const reset=node('button','quiet','Исходный вид');reset.type='button';reset.onclick=()=>updateView(turn,()=>{delete data.visual;if(data.originalLayout)data.spec.layout=data.originalLayout;},'\u0412\u043e\u0437\u0432\u0440\u0430\u0449\u0451\u043d \u0438\u0441\u0445\u043e\u0434\u043d\u044b\u0439 \u0432\u0438\u0434 \u0433\u0440\u0430\u0444\u0438\u043a\u0430.');design.append(choices,reset);host.append(design);
 if(turn.favorite)return;
 const chips=node('div','followups');chips.append(node('span','','Продолжить от этого графика'));
 for(const option of data.optionalSeries||[]){const button=node('button','suggestion','＋ '+option.label);button.type='button';button.onclick=()=>send(option.query,{turn,update:true,source:turn.source,provider:provider.value});chips.append(button);}
 for(const [label,query] of (data.spec.metrics.includes('unique_surveys')?[['За 2026 год','Покажи количество уникальных опросов за 2026 год'],['За 6 месяцев','Теперь за последние 6 месяцев']]:[['＋ Ответы','Добавь ответы'],['＋ CSI','Добавь CSI и объедини на одном графике'],['＋ Стоп-листы','Добавь отсечения по стоп-листам'],['＋ Политика контактов','Добавь отсечения по политике контактов'],['За 6 месяцев','Теперь за последние 6 месяцев']])){const button=node('button','suggestion',label);button.type='button';button.dataset.followup=query;button.onclick=()=>send(query,{turn,update:true,source:turn.source,provider:provider.value});chips.append(button);}
 const edit=node('button','edit-chart','Изменить этот график');edit.type='button';edit.dataset.action='edit';edit.onclick=()=>{if(busy)return;source.value=turn.source;updateSource();setContext(turn,true);focusUI.show(turn,turns,false);focusUI.chat();input.focus({preventScroll:true});};chips.append(edit);host.append(chips);
}
function setBusy(value){busy=value;for(const control of [$('submit'),source,provider,$('creativeMode'),$('newSession'),$('updateExisting'),$('clearContext')])control.disabled=value;feed.querySelectorAll('.suggestion,.edit-chart,[data-action="combine"]').forEach(b=>b.disabled=value);}
async function send(query,options){
 if(busy)return;query=query.trim();if(!query){$('error').textContent='Напишите сообщение или выберите подсказку.';$('error').hidden=false;input.focus();return;}
 const context=options||{turn:activeTurn,update:$('updateExisting').checked,source:source.value,provider:provider.value};
 source.value=context.source;updateSource();provider.value=context.provider;provider.onchange();
 const request={query,source:context.source,provider:context.provider,previous:context.turn&&!['ai-workspace','generated-ui'].includes(context.turn.data.kind)?clone(context.turn.data.spec):null,previousAgent:context.turn?.data.agentPlan||null,criteria:context.criteria,mode:$('creativeMode').checked?'creative':'standard',creativeBase:creativeBaseOverride||(context.turn?.data.kind==='generated-ui'?(context.turn.data.savedId||context.turn.data.jobId):null)};
 const target=context.update?context.turn:null;
 focusUI.start();focusUI.loading(true,target);
 $('error').hidden=true;$('intro').hidden=true;$('examples').hidden=true;document.body.classList.add('chat-started');
 const user=addMessage('user',query);user.append(node('small','message-context','Мои CSV'));
 if(context.turn)user.append(node('small','message-context',(target?'Изменение':'Продолжение')+' графика №'+context.turn.number));
 const responseElement=addMessage('assistant');const loading=node('div','skeleton',request.provider==='gigacode'?'GigaCode обрабатывает запрос…':'Читаем данные и собираем график…');loading.setAttribute('role','status');responseElement.append(loading);
 let failed=false;input.value='';setBusy(true);focusUI.messageDone();
 try{
 if(request.mode!=='creative'&&request.provider==='local'&&/почему|что\s+повлияло|разбери.*отклон|расследуй/iu.test(query)&&context.turn?.investigator){
  loading.textContent='Сопоставляем наблюдения и календарь запусков…';const result=await context.turn.investigator.ask(query);context.turn.messages=[...(context.turn.messages||[context.turn.query]),query].slice(-12);const main=result.metrics.find(m=>m.metric===result.metric),lead=result.contributors.find(r=>r.contribution!==null);
  responseElement.replaceChildren(node('div','message-label','Расследование · '+result.period),node('p','message-text',main.label+': сопоставимое изменение '+(main.delta===null?'не определено':fmt(main.delta,main.metric))+(lead?' · наибольший вклад #'+lead.id+': '+fmt(lead.contribution,main.metric):'')+'. Совпавших событий календаря: '+result.events.length+'. Подробности открыты под выбранным графиком.'));focusUI.notice('Разбор периода '+result.period+' · исходный график сохранён');focusUI.messageDone();return;
 }
 const plan=context.resumeJobId?(await window.TrustUI.post('/api/creative',{action:'retry-generation',jobId:context.resumeJobId,codeTimeoutSeconds:context.codeTimeoutSeconds}),{kind:'agent-job',jobId:context.resumeJobId,mode:'creative'}):await window.TrustUI.post('/api/genui/plan',request);if(plan.mode==='creative')request.mode='creative';let data;
 if(plan.kind==='agent-job'){
  try{data=await window.AgentUI.wait(plan.jobId,responseElement,text=>focusUI.notice(text));}
  catch(e){if(e.clarification)e.clarification.options=e.clarification.options.map(o=>({...o,query:query+'. Уточнение: '+o.query}));throw e;}
 }else{focusUI.notice('Запрос понят: '+plan.interpretation);loading.textContent='Выполняем проверенный план: '+plan.interpretation;focusUI.messageDone();data=await window.TrustUI.post('/api/genui',{planId:plan.planId});}

 if(data.kind==='generated-ui')data=await window.CreativeUI.review(data,{notice:text=>focusUI.notice(text)});
 creativeBaseOverride=null;
 let completed;
 if(target){const before=clone(target.data);target.versions=target.versions||[];target.versions.push({data:before,revision:target.revision});target.versions=target.versions.slice(-8);target.data=clone(data);target.messages=[...(target.messages||[target.query]),query].slice(-12);target.revision=query;target.step=(target.step||1)+1;target.delta=window.FocusWorkspace.delta(before,target.data);target.deltaTitle='Изменения по запросу';renderTurn(target);completed=target;}
 else{const element=node('article','chat-message answer');feed.append(element);const turn={number:++serial,query,messages:[query],data:clone(data),source:request.source,element,step:1,delta:window.FocusWorkspace.delta(context.turn?.data,data)};turns.push(turn);renderTurn(turn);completed=turn;}
 responseElement.replaceChildren(node('div','message-label','Шаг '+completed.step+' · график №'+completed.number),node('p','message-text',completed.delta.join('\n')));const jump=node('button','quiet','Показать график №'+completed.number);jump.type='button';jump.onclick=()=>{setContext(completed,true);focusUI.show(completed,turns);};responseElement.append(jump);setContext(completed,true);updateHistory();focusUI.show(completed,turns);focusUI.messageDone();
 }catch(e){if(e.discarded||e.refinement||e.planEdit){responseElement.replaceChildren(node('p','message-text',e.message));if(e.planEdit){input.value=e.query;focusUI.chat();input.focus({preventScroll:true});}if(e.refinement){creativeBaseOverride=e.draft.savedId||e.draft.jobId;$('creativeMode').checked=true;$('creativeMode').onchange();input.value=e.refinement;focusUI.chat();input.focus({preventScroll:true});}focusUI.notice('Текущий экран сохранён.');return;}failed=true;focusUI.chat();responseElement.replaceChildren(node('div','message-label',request.mode==='creative'?'Не удалось завершить этап новой визуализации':'Не удалось построить график'));const failure=node('p','error',e.message==='Failed to fetch'?'Соединение с локальным сервером прервано. Проверьте, что окно запуска проекта открыто, затем повторите запрос.':e.message);failure.setAttribute('role','alert');responseElement.append(failure);for(const option of e.clarification?.options||[]){const choice=node('button','quiet recovery-option',option.label);choice.type='button';choice.onclick=()=>send(option.query,context);responseElement.append(choice);}if(e.recovery){for(const option of e.recovery.options||[]){const action=node('button','quiet recovery-option',option.label);action.type='button';action.onclick=()=>{if(option.edit){input.value=query;focusUI.chat();input.focus({preventScroll:true});}else if(option.action==='show-calculated'){window.CreativeUI.calculated(option.jobId).catch(error=>responseElement.append(node('p','error',error.message)));}else if(option.action==='retry-generation'){send(query,{...context,resumeJobId:option.jobId,codeTimeoutSeconds:option.timeout});}else send(query+option.suffix,{...context,resumeJobId:null});};responseElement.append(action);}}else{const retry=node('button','quiet','Повторить запрос');retry.type='button';retry.onclick=()=>send(query,{...context,resumeJobId:null});responseElement.append(retry);}focusUI.messageDone();
 }finally{setBusy(false);focusUI.loading(false);if(failed)focusUI.notice('\u0417\u0430\u043f\u0440\u043e\u0441 \u043d\u0435 \u0432\u044b\u043f\u043e\u043b\u043d\u0435\u043d. \u0422\u0435\u043a\u0443\u0449\u0438\u0439 \u0433\u0440\u0430\u0444\u0438\u043a \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d.');focusUI.messageDone();refreshStatus();}
}
form.addEventListener('submit',e=>{e.preventDefault();send(input.value);});input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
document.querySelectorAll('[data-query]').forEach(b=>b.onclick=()=>send(b.dataset.query,{turn:null,update:false,source:source.value,provider:provider.value}));
function updateSource(){$('sourceBadge').textContent='Мои CSV';$('sourceHint').textContent='date/push-sms.csv и date/success-screen.csv перечитываются при каждом запросе.';}
$('creativeMode').onchange=()=>{$('creativeHint').hidden=!$('creativeMode').checked;if($('creativeMode').checked&&provider.value==='local'){provider.value='auto';provider.onchange();}};
source.onchange=()=>{setContext(null,false);updateSource();};
provider.onchange=()=>{$('providerBadge').textContent=provider.value==='auto'?'Авто · правила + модель':provider.value==='gigacode'?'GigaCode CLI':'Локальный разбор';};
$('clearContext').onclick=()=>setContext(null,false);$('updateExisting').onchange=syncContext;
$('newSession').onclick=()=>{if(busy)return;focusUI.reset();destroyCharts(feed);feed.replaceChildren();turns=[];serial=0;creativeBaseOverride=null;$('creativeMode').checked=false;$('creativeMode').onchange();setContext(null,false);updateHistory();$('intro').hidden=false;$('examples').hidden=false;$('error').hidden=true;document.body.classList.remove('chat-started');input.value='';input.focus();window.scrollTo({top:0,behavior:'instant'});};
let statusBusy=false,providerInitialized=false;
async function refreshStatus(){
 if(statusBusy)return;statusBusy=true;$('refreshData').disabled=true;
 try{const response=await fetch('/api/genui/status');if(!response.ok)throw new Error('status');const status=await response.json();
 $('cliStatus').textContent=status.configured?'CLI настроена; авторизация проверяется при запросе.':'CLI не настроена. Можно использовать локальный разбор.';
 $('cliStatus').textContent+=' · Версия проекта: '+(status.build||'старая сборка — перезапустите сервер из нового архива');
 if(!providerInitialized){providerInitialized=true;provider.onchange();}
 const data=status.data;if(!data)throw new Error('data');const hasData=data.surveys>0;
 $('dataHeading').textContent=data.error?'Проверьте CSV':hasData?'Данные подключены':'Добавьте свои выгрузки';
 const currentRows=data.files.filter(file=>!file.file.endsWith('products.csv')).reduce((sum,file)=>sum+(file.rows||0),0);
 $('dataSummary').textContent=data.error?'CSV не применены: '+data.error:hasData?'Опросов: '+data.surveys+' · месяцев с данными: '+data.months.length+'. '+(currentRows?'Можно задавать вопросы в диалоге.':'В текущих CSV нет строк. Показана ранее принятая локальная история.'):'Показателей пока нет. Справочники сохранены; опросы появятся после первой загрузки CSV.';
 $('intro').hidden=!hasData||feed.children.length>0;$('examples').hidden=!hasData||feed.children.length>0;
 $('dataInstructions').hidden=hasData&&!data.error;$('dataOnboarding').classList.toggle('has-data',hasData&&!data.error);
 $('dataFileList').replaceChildren();for(const file of data.files){const line=node('div','data-file');line.append(node('b','',file.file),node('span','',(file.rows||0)+' строк · '+file.modified));$('dataFileList').append(line);}
 document.querySelectorAll('[data-query]').forEach(b=>b.disabled=!hasData||Boolean(data.error));
 }catch{$('dataHeading').textContent='Не удалось проверить данные';$('dataSummary').textContent='Убедитесь, что локальный сервер запущен, и нажмите «Проверить данные».';}
 finally{statusBusy=false;$('refreshData').disabled=false;if(['#favorites','#agent-log','#trust','#metrics','#diagnostics','#scenarios','#calendar'].includes(location.hash)){const page=location.hash==='#favorites'?favoritesPage:location.hash==='#agent-log'?logPage:location.hash==='#trust'?trustUI.page:location.hash==='#diagnostics'?trustUI.diagnostics:location.hash==='#scenarios'?workflowsUI.scenarios:location.hash==='#calendar'?workflowsUI.calendar:trustUI.metrics;for(const child of $('main').children)child.hidden=child!==page;}}
}
$('refreshData').onclick=refreshStatus;if(!['#trust','#metrics','#diagnostics','#scenarios','#calendar'].includes(location.hash))refreshStatus();
updateSource();syncContext();showPage();
})();
