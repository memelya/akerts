(()=>{
const $=id=>document.getElementById(id),form=$('queryForm'),input=$('query'),source=$('source'),provider=$('provider'),feed=$('conversation');
const clone=value=>JSON.parse(JSON.stringify(value));
const node=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const fmt=(value,metric)=>value===null?'Нет данных':new Intl.NumberFormat('ru-RU',{maximumFractionDigits:metric==='csi'?2:0}).format(value);
const surveyLabel=id=>id===null?'Все выбранные опросы':'#'+id;
const month=value=>new Intl.DateTimeFormat('ru-RU',{day:value.length===10?'numeric':undefined,month:'short',year:'numeric',timeZone:'UTC'}).format(new Date(value+(value.length===7?'-01':'')+'T12:00:00Z'));
const palette=['#197b54','#4264b5','#895ba6','#b07835','#13798b','#b34c64','#4f7e24','#815935','#5d62a3','#b05a29','#33748d','#8c466e','#657b2b','#a34738','#4e6578','#796843'];
let turns=[],activeTurn=null,busy=false,serial=0;
const favoritesKey='genui-favorites-v1';
let favorites=[];try{favorites=JSON.parse(localStorage.getItem(favoritesKey)||'[]');if(!Array.isArray(favorites))favorites=[];}catch{}
const favoritesPage=node('section','conversation');favoritesPage.hidden=true;$('main').append(favoritesPage);
const favoriteNav=node('a','nav-item','Избранное');favoriteNav.href='#favorites';document.querySelector('.rail').insertBefore(favoriteNav,document.querySelector('.history'));
function saveFavorites(){try{localStorage.setItem(favoritesKey,JSON.stringify(favorites));return true;}catch{alert('Не удалось сохранить избранное: хранилище браузера недоступно или заполнено.');return false;}}
function showFavorites(){const showing=location.hash==='#favorites';for(const child of $('main').children)child.hidden=showing;favoritesPage.hidden=!showing;if(!showing){refreshStatus();syncContext();return;}destroyCharts(favoritesPage);favoritesPage.replaceChildren(node('h1','','Избранное'),node('p','','Сохранённые снимки графиков. Хранятся в этом браузере на текущем адресе и сохраняются после F5.'));
 if(!favorites.length)favoritesPage.append(node('p','','Выберите «В избранное» под нужными графиками в диалоге.'));
 for(const item of favorites){const host=node('article','chat-message answer');favoritesPage.append(host);renderTurn({...clone(item),element:host,favorite:true});}
}
const logPage=node('section','conversation');logPage.hidden=true;$('main').append(logPage);
const logNav=node('a','nav-item','Лог GigaCode');logNav.href='#agent-log';document.querySelector('.rail').insertBefore(logNav,document.querySelector('.history'));
async function showAgentLog(){
 const showing=location.hash==='#agent-log';logPage.hidden=!showing;if(!showing)return;
 for(const child of $('main').children)child.hidden=child!==logPage;
 logPage.replaceChildren(node('h1','','Лог GigaCode'),node('p','','Последние 200 обращений. История хранится локально и сохраняется после перезапуска.'));
 const refresh=node('button','suggestion','Обновить лог');refresh.onclick=showAgentLog;logPage.append(refresh);
 try{const response=await fetch('/api/genui/log');if(!response.ok)throw new Error('Не удалось загрузить лог');const rows=await response.json();if(location.hash!=='#agent-log')return;
 if(!rows.length)logPage.append(node('p','','Обращений пока нет. Выберите GigaCode и отправьте запрос в диалоге.'));
 for(const entry of rows.slice().reverse()){
 const card=node('article','chat-message answer');card.append(node('div','message-label',new Date(entry.time).toLocaleString('ru-RU')+' · '+entry.durationMs+' мс · '+(entry.mode==='local-rule'?'Встроенный обработчик':'GigaCode CLI')+' · '+(entry.status==='ok'?'Успешно':'Ошибка')));
 card.append(node('h3','','Пользователь'),node('p','message-text',entry.query));
 card.append(node('h3','','Ответ агента'));const reply=node('pre','',entry.response||entry.error||(entry.mode==='local-rule'?'Запрос разобран встроенным обработчиком, CLI не вызывалась.':''));reply.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere';card.append(reply);
 for(const [label,value] of [['Параметры графика',entry.spec],['Контекст предыдущего графика',entry.previous],['Полный запрос к агенту',entry.prompt]])if(value){const details=node('details','');details.append(node('summary','',label));const pre=node('pre','',typeof value==='string'?value:JSON.stringify(value,null,2));pre.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere';details.append(pre);card.append(details);}
 if(entry.error&&entry.response)card.append(node('p','message-text',entry.error));logPage.append(card);
 }
 }catch(error){logPage.append(node('p','',error.message));}
}
function showPage(){showFavorites();logPage.hidden=location.hash!=='#agent-log';showAgentLog();}
window.addEventListener('hashchange',showPage);
async function exportPng(data){
 const canvas=document.createElement('canvas');canvas.width=1600;canvas.height=900;const c=canvas.getContext('2d');c.fillStyle='#ffffff';c.fillRect(0,0,1600,900);c.fillStyle='#183e32';c.font='bold 28px sans-serif';c.fillText('GEN UI · '+data.periodLabel,70,50);c.font='18px sans-serif';
 const colors=data.visual?.theme==='presentation'?['#6d28d9','#0891b2','#ea580c','#be185d','#15803d','#1d4ed8']:palette;const blocks=data.blocks,left=90,right=1490,top=Math.max(220,130+Math.ceil(data.blocks.length/3)*25),bottom=780;
 blocks.forEach((b,i)=>{c.fillStyle=colors[i%colors.length];c.fillText(b.label+' · '+surveyLabel(b.id),70+(i%3)*500,90+Math.floor(i/3)*25);});
 const quantities=blocks.filter(b=>b.metric!=='csi').flatMap(b=>b.values).filter(v=>v!==null),max=Math.max(1,...quantities);
 c.strokeStyle='#d8e1db';c.fillStyle='#48594f';for(let i=0;i<=5;i++){let y=bottom-(bottom-top)*i/5;c.beginPath();c.moveTo(left,y);c.lineTo(right,y);c.stroke();c.fillText(Math.round(max*i/5).toLocaleString('ru-RU'),5,y);}
 if(blocks.some(b=>b.metric==='csi'))for(let i=1;i<=5;i++)c.fillText('CSI '+i,right+12,bottom-(bottom-top)*(i-1)/4);
 const x=i=>left+(right-left)*i/Math.max(1,data.months.length-1);
 blocks.forEach((b,j)=>{c.strokeStyle=colors[j%colors.length];c.fillStyle=c.strokeStyle;c.lineWidth=3;c.beginPath();let open=false;b.values.forEach((v,i)=>{if(v===null){open=false;return;}const y=bottom-(bottom-top)*(b.metric==='csi'?(v-1)/4:v/max);if(data.visual?.type==='bars'&&b.metric!=='csi'){const bw=Math.min(40,(right-left)/Math.max(1,data.months.length)/Math.max(1,blocks.length));c.fillRect(x(i)+(j-(blocks.length-1)/2)*bw-bw/2,y,bw*.85,bottom-y);open=false;return;}if(open)c.lineTo(x(i),y);else c.moveTo(x(i),y);open=true;});c.stroke();b.values.forEach((v,i)=>{if(v===null)return;const y=bottom-(bottom-top)*(b.metric==='csi'?(v-1)/4:v/max);c.beginPath();c.arc(x(i),y,4,0,Math.PI*2);c.fill();});});
 c.fillStyle='#48594f';c.font='16px sans-serif';data.months.forEach((m,i)=>{if(i%Math.max(1,Math.ceil(data.months.length/12))===0){c.save();c.translate(x(i),bottom+25);c.rotate(-0.35);c.fillText(m,0,0);c.restore();}});c.fillText('Источник: '+data.source+' · Пропуски не заменяются нулями',70,880);
 canvas.toBlob(blob=>{if(!blob){alert('Не удалось создать PNG');return;}const url=URL.createObjectURL(blob),a=node('a');a.href=url;a.download='genui-chart.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);},'image/png');
}

const scrollTo=element=>element.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});
function destroyCharts(parent){parent.querySelectorAll('.v2-chart').forEach(chart=>chart.destroy?.());}
function setContext(turn,update=false){activeTurn=turn;$('updateExisting').checked=update;syncContext();}
function syncContext(){
 $('contextBar').hidden=!activeTurn;
 $('contextLabel').textContent=activeTurn?'График №'+activeTurn.number+' · '+(activeTurn.data.spec.ids.length?'опросы '+activeTurn.data.spec.ids.join(', '):'Все опросы'):'';
 input.placeholder=activeTurn?'Продолжите: «Добавь ответы» или задайте новый вопрос':'Покажи опрос 193 за 3 месяца';
 $('submitLabel').textContent=$('updateExisting').checked&&activeTurn?'Обновить график':'Отправить';
}
function addMessage(kind,text){const article=node('article','chat-message message-'+kind),head=node('div','message-label',kind==='user'?'Вы':provider.value==='gigacode'?'GigaCode':'GEN UI · локальный разбор');article.append(head);if(text!==undefined)article.append(node('p','message-text',text));feed.append(article);return article;}
function updateHistory(){
 $('history').replaceChildren();for(const turn of [...turns].reverse()){const button=node('button','','№'+turn.number+' · '+turn.query);button.type='button';button.onclick=()=>scrollTo(turn.element);$('history').append(button);}
 if(!turns.length)$('history').append(node('p','muted','Результаты появятся здесь'));
}
function download(data){const quote=v=>'"'+String(v??'').replaceAll('"','""')+'"',rows=[['Опрос','Месяц','Показатель','Значение'],...data.table.map(r=>[r.id,r.month,r.metric,r.value])];const url=URL.createObjectURL(new Blob(['\uFEFF'+rows.map(r=>r.map(quote).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'})),a=node('a');a.href=url;a.download='genui-monitoring.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
async function exportVisualPng(host,data){
 const svgs=[...host.querySelectorAll('.charts svg')];if(!svgs.length)return exportPng(data);
 const canvas=document.createElement('canvas');canvas.width=1600;canvas.height=140+svgs.length*650;const c=canvas.getContext('2d');c.fillStyle='#fff';c.fillRect(0,0,canvas.width,canvas.height);c.fillStyle='#183e32';c.font='bold 26px sans-serif';c.fillText('GEN UI · '+data.periodLabel,48,48);
 for(let i=0;i<svgs.length;i++){const original=svgs[i],copy=original.cloneNode(true),sources=[original,...original.querySelectorAll('*')],targets=[copy,...copy.querySelectorAll('*')];sources.forEach((element,j)=>{const style=getComputedStyle(element);for(const key of ['fill','stroke','stroke-width','opacity','font-family','font-size','font-weight','paint-order'])targets[j].style.setProperty(key,style.getPropertyValue(key));});copy.setAttribute('xmlns','http://www.w3.org/2000/svg');const box=original.viewBox.baseVal;copy.setAttribute('width',box.width);copy.setAttribute('height',box.height);const url=URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(copy)],{type:'image/svg+xml;charset=utf-8'}));try{const img=new Image();await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=url;});const card=original.closest('.v2-chart');c.fillStyle='#183e32';c.font='bold 20px sans-serif';c.fillText(card.querySelector('h3').textContent,48,100+i*650);c.font='14px sans-serif';const labels=[...card.querySelectorAll('.v2-chart-series b')].map(n=>n.textContent);labels.forEach((label,j)=>c.fillText(label,48,130+i*650+j*22));const scale=Math.min(1500/box.width,450/box.height);c.drawImage(img,48,180+i*650,box.width*scale,box.height*scale);}finally{URL.revokeObjectURL(url);}}
 canvas.toBlob(blob=>{if(!blob)return;const url=URL.createObjectURL(blob),a=node('a');a.href=url;a.download='genui-chart.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);},'image/png');
}
function renderTurn(turn){
 const data=turn.data,host=turn.element;const visual=data.visual||{type:'line',theme:'default'};const colors=visual.theme==='presentation'?['#6d28d9','#0891b2','#ea580c','#be185d','#15803d','#1d4ed8']:palette;destroyCharts(host);host.replaceChildren();host.id='answer-'+turn.number;host.dataset.turnId=turn.number;
 const header=node('div','assistant-heading');header.append(node('span','message-label',(data.provider==='gigacode'?'GigaCode':'GEN UI · локальный разбор')+' · график №'+turn.number));
 const downloadButton=node('button','quiet','CSV ↓');downloadButton.type='button';downloadButton.onclick=()=>download(data);header.append(downloadButton);
 const png=node('button','quiet','PNG ↓');png.type='button';png.onclick=()=>exportVisualPng(host,data).catch(()=>alert('Не удалось сохранить PNG. Повторите попытку.'));header.append(png);
 const star=node('button','quiet',turn.favorite?'Удалить из избранного':'В избранное');star.type='button';star.onclick=()=>{
 const old=clone(favorites);
 if(turn.favorite){favorites=favorites.filter(f=>f.savedId!==turn.savedId);if(!saveFavorites())favorites=old;showFavorites();}
 else{favorites.push({savedId:Date.now()+'-'+Math.random(),number:turn.number,query:turn.query,data:clone(data),source:turn.source});if(saveFavorites()){star.textContent='Сохранено ✓';star.disabled=true;}else favorites=old;}
 };header.append(star);host.append(header);
 const title=data.spec.ids.length>1?'Сравнение опросов '+data.spec.ids.join(' и '):data.blocks[0].name;
 host.append(node('h2','answer-title',title),node('p','interpretation',(data.spec.ids.length?'Опросы: '+data.spec.ids.join(', '):'Все загруженные опросы')+' · '+[...new Set(data.blocks.map(b=>b.label))].join(', ')+' · '+data.periodLabel));
 host.append(node('p','source-receipt',data.source+' · период '+data.periodLabel+' · последние загруженные наблюдения: '+data.anchor+'.'));
 if(turn.revision)host.append(node('p','revision-note','Обновлено по сообщению: «'+turn.revision+'»'));
 const kpis=node('div','kpis');for(const total of data.totals){const card=node('article','kpi');card.append(node('span','',total.label+' · '+surveyLabel(total.id)),node('strong','',fmt(total.value,total.metric)),node('small','',total.note));kpis.append(card);}host.append(kpis);
 const charts=node('div','charts'),tableWrap=node('div','table-wrap');tableWrap.hidden=true;
 const controls=node('div','view-controls'),buttons=node('div');
 const chartButton=node('button','','Графики'),tableButton=node('button','','Таблица'),combineButton=node('button','','На одном графике');
 for(const button of [chartButton,tableButton,combineButton])button.type='button';
 chartButton.dataset.action='charts';tableButton.dataset.action='table';combineButton.dataset.action='combine';
 chartButton.setAttribute('aria-pressed','true');tableButton.setAttribute('aria-pressed','false');combineButton.setAttribute('aria-pressed',String(data.spec.layout==='combined'));
 chartButton.onclick=()=>{charts.hidden=false;tableWrap.hidden=true;chartButton.setAttribute('aria-pressed','true');tableButton.setAttribute('aria-pressed','false');};
 tableButton.onclick=()=>{charts.hidden=true;tableWrap.hidden=false;chartButton.setAttribute('aria-pressed','false');tableButton.setAttribute('aria-pressed','true');};
 combineButton.onclick=()=>{if(busy)return;data.spec.layout=data.spec.layout==='combined'?'separate':'combined';renderTurn(turn);if(activeTurn===turn)syncContext();};
 buttons.append(chartButton,tableButton,combineButton);controls.append(buttons,node('span','','Количество слева · CSI 1–5 справа'));host.append(controls,charts);
 const combined=data.spec.layout==='combined',groups=combined?[data.blocks]:data.spec.metrics.map(metric=>data.blocks.filter(b=>b.metric===metric));
 for(const blocks of groups){const key=b=>b.metric+':'+b.id,rows=data.months.map((m,i)=>({key:m,label:month(m),short:month(m),...Object.fromEntries(blocks.map(b=>[key(b),b.values[i]]))}));
 window.V2Chart(charts,{chartType:visual.type,title:combined?[...new Set(blocks.map(b=>b.label))].join(' · '):blocks[0].label,badge:combined?'Совмещённый график':'Динамика',context:data.periodLabel,help:'Линии можно отключать в легенде. Последний месяц может быть неполным.',modes:[{key:'month',label:data.spec.grain==='day'?'По дням':'По месяцам',rows}],series:blocks.map((b,i)=>({key:key(b),label:b.label+' · '+(b.id===null?'Все выбранные опросы':'#'+b.id+' · '+b.name),color:colors[i%colors.length],dash:b.metric==='csi'?'6 4':b.metric==='answers'?'3 3':null,total:b.values.at(-1)})),receipt:[['Источник',data.source],['Расчёт',(data.methods||['Количество суммируется по записям месяца. CSI не суммируется.']).join(' ')],['Шкалы','Количество — левая шкала. CSI — правая, от 1 до 5; когда остаётся только CSI, его шкала переносится влево.'],['Полнота',data.warnings.join(' ')]]});}
 const table=node('table'),thead=node('thead'),tr=node('tr');for(const h of ['Опрос','Месяц','Показатель','Значение']){const th=node('th','',h);th.scope='col';tr.append(th);}thead.append(tr);table.append(thead);const tbody=node('tbody');for(const row of data.table){const tr=node('tr');for(const value of [surveyLabel(row.id),month(row.month),row.metric,fmt(row.value,row.metric==='CSI'?'csi':'count')])tr.append(node('td','',value));tbody.append(tr);}table.append(tbody);tableWrap.append(table);host.append(tableWrap);
 const method=node('details','method');method.append(node('summary','','Источники и полнота данных'));for(const warning of [...(data.methods||[]),...data.warnings])method.append(node('p','',warning));method.append(node('p','','Ответ фиксирует данные на момент запроса. Новый запрос перечитывает CSV. Пропуски не заменяются нулями.'));host.append(method);
 const design=node('section','visual-design');design.append(node('h3','','Попробуйте другой взгляд на данные'),node('p','','Выберите вариант — график преобразится сразу. Значения и период сохраняются.'));
 const variants={bars:['Сравнить столбцами','Удобно сопоставить периоды; CSI остаётся линией.'],area:['Подчеркнуть динамику','Заливка выделит изменение первого количественного показателя.'],presentation:['Палитра для презентации','Контрастные фиолетовые, бирюзовые и янтарные акценты.'],panels:['Разнести по панелям','Отдельная шкала для каждого показателя раскроет небольшие изменения.']};
 const proposed=[...new Set(data.spec.visualSuggestions||[data.months.length>16?'area':'bars','presentation',data.blocks.length>1?'panels':'area'])].slice(0,3);
 const choices=node('div','visual-choices');
 for(const key of proposed){const button=node('button','visual-option');button.type='button';button.dataset.visual=key;button.append(node('strong','',variants[key][0]),node('span','',variants[key][1]));button.onclick=()=>{if(!data.originalLayout)data.originalLayout=data.spec.layout;data.visual={...visual};if(key==='presentation')data.visual.theme=visual.theme==='presentation'?'default':'presentation';else if(key==='panels')data.spec.layout='separate';else data.visual.type=key;renderTurn(turn);};choices.append(button);}
 const reset=node('button','quiet','Исходный вид');reset.type='button';reset.onclick=()=>{delete data.visual;if(data.originalLayout)data.spec.layout=data.originalLayout;renderTurn(turn);};design.append(choices,reset);host.append(design);
 if(turn.favorite)return;
 const chips=node('div','followups');chips.append(node('span','','Продолжить от этого графика'));
 for(const [label,query] of (data.spec.metrics.includes('unique_surveys')?[['За 2026 год','Покажи количество уникальных опросов за 2026 год'],['За 6 месяцев','Теперь за последние 6 месяцев']]:[['＋ Ответы','Добавь ответы'],['＋ CSI','Добавь CSI и объедини на одном графике'],['＋ Стоп-листы','Добавь отсечения по стоп-листам'],['＋ Политика контактов','Добавь отсечения по политике контактов'],['За 6 месяцев','Теперь за последние 6 месяцев']])){const button=node('button','suggestion',label);button.type='button';button.dataset.followup=query;button.onclick=()=>send(query,{turn,update:false,source:turn.source,provider:provider.value});chips.append(button);}
 const edit=node('button','edit-chart','Изменить этот график');edit.type='button';edit.dataset.action='edit';edit.onclick=()=>{if(busy)return;source.value=turn.source;updateSource();setContext(turn,true);input.focus();scrollTo($('composer'));};chips.append(edit);host.append(chips);
}
function setBusy(value){busy=value;for(const control of [$('submit'),source,provider,$('newSession'),$('updateExisting'),$('clearContext')])control.disabled=value;feed.querySelectorAll('.suggestion,.edit-chart,[data-action="combine"]').forEach(b=>b.disabled=value);}
async function send(query,options){
 if(busy)return;query=query.trim();if(!query){$('error').textContent='Напишите сообщение или выберите подсказку.';$('error').hidden=false;input.focus();return;}
 const context=options||{turn:activeTurn,update:$('updateExisting').checked,source:source.value,provider:provider.value};
 source.value=context.source;updateSource();provider.value=context.provider;provider.onchange();
 const request={query,source:context.source,provider:context.provider,previous:context.turn?clone(context.turn.data.spec):null};
 const target=context.update?context.turn:null;
 $('error').hidden=true;$('intro').hidden=true;$('examples').hidden=true;document.body.classList.add('chat-started');
 const user=addMessage('user',query);user.append(node('small','message-context','Мои CSV'));
 if(context.turn)user.append(node('small','message-context',(target?'Изменение':'Продолжение')+' графика №'+context.turn.number));
 const responseElement=addMessage('assistant');const loading=node('div','skeleton',request.provider==='gigacode'?'GigaCode обрабатывает запрос…':'Читаем данные и собираем график…');loading.setAttribute('role','status');responseElement.append(loading);
 input.value='';setBusy(true);scrollTo(user);
 try{const response=await fetch('/api/genui',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(request)});const data=await response.json();if(!response.ok)throw new Error(data.error||'Не удалось обработать сообщение.');
 if(target){target.data=clone(data);target.revision=query;renderTurn(target);responseElement.replaceChildren(node('div','message-label','GEN UI'),node('p','message-text','График №'+target.number+' обновлён. Остальные результаты сохранены.'));const link=node('a','jump-answer','Перейти к обновлённому графику ↑');link.href='#'+target.element.id;responseElement.append(link);setContext(target,false);}
 else{const turn={number:++serial,query,data:clone(data),source:request.source,element:responseElement};turn.element.classList.add('answer');turns.push(turn);renderTurn(turn);setContext(turn,false);}
 updateHistory();scrollTo(responseElement);
 }catch(e){responseElement.replaceChildren(node('div','message-label','Не удалось построить график'));const failure=node('p','error',e.message);failure.setAttribute('role','alert');responseElement.append(failure);const retry=node('button','quiet','Повторить запрос');retry.type='button';retry.onclick=()=>send(query,context);responseElement.append(retry);scrollTo(responseElement);
 }finally{setBusy(false);input.focus({preventScroll:true});refreshStatus();}
}
form.addEventListener('submit',e=>{e.preventDefault();send(input.value);});input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
document.querySelectorAll('[data-query]').forEach(b=>b.onclick=()=>send(b.dataset.query,{turn:null,update:false,source:source.value,provider:provider.value}));
function updateSource(){$('sourceBadge').textContent='Мои CSV';$('sourceHint').textContent='date/push-sms.csv и date/success-screen.csv перечитываются при каждом запросе.';}
source.onchange=()=>{setContext(null,false);updateSource();};
provider.onchange=()=>{$('providerBadge').textContent=provider.value==='gigacode'?'GigaCode CLI':'Локальный разбор';};
$('clearContext').onclick=()=>setContext(null,false);$('updateExisting').onchange=syncContext;
$('newSession').onclick=()=>{if(busy)return;destroyCharts(feed);feed.replaceChildren();turns=[];serial=0;setContext(null,false);updateHistory();$('intro').hidden=false;$('examples').hidden=false;$('error').hidden=true;document.body.classList.remove('chat-started');input.value='';input.focus();window.scrollTo({top:0,behavior:'instant'});};
let statusBusy=false,providerInitialized=false;
async function refreshStatus(){
 if(statusBusy)return;statusBusy=true;$('refreshData').disabled=true;
 try{const response=await fetch('/api/genui/status');if(!response.ok)throw new Error('status');const status=await response.json();
 $('cliStatus').textContent=status.configured?'CLI настроена; авторизация проверяется при запросе.':'CLI не настроена. Можно использовать локальный разбор.';
 if(!providerInitialized){providerInitialized=true;if(status.configured&&!busy&&!turns.length){provider.value='gigacode';provider.onchange();}}
 const data=status.data;if(!data)throw new Error('data');const hasData=data.surveys>0;
 $('dataHeading').textContent=data.error?'Проверьте CSV':hasData?'Данные подключены':'Добавьте свои выгрузки';
 const currentRows=data.files.reduce((sum,file)=>sum+(file.rows||0),0);
 $('dataSummary').textContent=data.error?'CSV не применены: '+data.error:hasData?'Опросов: '+data.surveys+' · месяцев с данными: '+data.months.length+'. '+(currentRows?'Можно задавать вопросы в диалоге.':'В текущих CSV нет строк. Показана ранее принятая локальная история.'):'Показателей пока нет. Справочники сохранены; опросы появятся после первой загрузки CSV.';
 $('intro').hidden=!hasData||feed.children.length>0;$('examples').hidden=!hasData||feed.children.length>0;
 $('dataInstructions').hidden=hasData&&!data.error;$('dataOnboarding').classList.toggle('has-data',hasData&&!data.error);
 $('dataFileList').replaceChildren();for(const file of data.files){const line=node('div','data-file');line.append(node('b','',file.file),node('span','',(file.rows||0)+' строк · '+file.modified));$('dataFileList').append(line);}
 document.querySelectorAll('[data-query]').forEach(b=>b.disabled=!hasData||Boolean(data.error));
 }catch{$('dataHeading').textContent='Не удалось проверить данные';$('dataSummary').textContent='Убедитесь, что локальный сервер запущен, и нажмите «Проверить данные».';}
 finally{statusBusy=false;$('refreshData').disabled=false;if(['#favorites','#agent-log'].includes(location.hash)){for(const child of $('main').children)child.hidden=child!==(location.hash==='#favorites'?favoritesPage:logPage);}}
}
$('refreshData').onclick=refreshStatus;refreshStatus();
updateSource();syncContext();showPage();
})();
