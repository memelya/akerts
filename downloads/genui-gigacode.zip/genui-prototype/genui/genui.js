(()=>{
const $=id=>document.getElementById(id),form=$('queryForm'),input=$('query'),source=$('source'),provider=$('provider'),error=$('error'),result=$('result');
let previous=null,current=null,busy=false,history=[];
const fmt=(value,metric)=>value===null?'Нет данных':new Intl.NumberFormat('ru-RU',{maximumFractionDigits:metric==='csi'?2:0}).format(value);
const month=value=>new Intl.DateTimeFormat('ru-RU',{month:'short',year:'numeric',timeZone:'UTC'}).format(new Date(value+'-01T12:00:00Z'));
const node=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
function clearCharts(){[...$('charts').children].forEach(c=>c.destroy?c.destroy():c.remove());}
function show(data){current=data;previous=data.spec;result.hidden=false;document.body.classList.add('has-result');
 $('resultTitle').textContent=data.spec.ids.length>1?'Сравнение опросов '+data.spec.ids.join(' и '):data.blocks[0].name;
 $('interpretation').textContent='Опросы: '+data.spec.ids.join(', ')+' · '+[...new Set(data.blocks.map(b=>b.label))].join(', ')+' · '+data.periodLabel;
 $('sourceReceipt').textContent=data.source+'. Обработка: '+(data.provider==='gigacode'?'GigaCode CLI':'локальный разбор')+'. Период отсчитывается от последнего месяца данных выбранных опросов: '+data.anchor+'.';
 $('kpis').replaceChildren();for(const total of data.totals){const card=node('article','kpi');card.append(node('span','',total.label+' · #'+total.id),node('strong','',fmt(total.value,total.metric)),node('small','',total.note));$('kpis').append(card);}
 clearCharts();const palette=['#197b54','#4264b5','#895ba6','#b07835','#13798b','#b34c64','#4f7e24','#815935','#5d62a3','#b05a29','#33748d','#8c466e','#657b2b','#a34738','#4e6578','#796843'];
 const combined=data.spec.layout==='combined',groups=combined?[data.blocks]:data.spec.metrics.map(metric=>data.blocks.filter(b=>b.metric===metric));
 $('combineView').setAttribute('aria-pressed',String(combined));
 for(const blocks of groups){const seriesKey=b=>b.metric+':'+b.id,rows=data.months.map((m,i)=>({key:m,label:month(m),short:month(m),...Object.fromEntries(blocks.map(b=>[seriesKey(b),b.values[i]]))}));
 window.V2Chart($('charts'),{title:combined?[...new Set(blocks.map(b=>b.label))].join(' · '):blocks[0].label,badge:combined?'Совмещённый график':'Динамика',context:data.periodLabel,help:'Количество — слева, CSI — справа от 1 до 5. Линии можно отключать в легенде. Последний месяц может быть неполным.',modes:[{key:'month',label:'По месяцам',rows}],series:blocks.map((b,i)=>({key:seriesKey(b),label:b.label+' · #'+b.id+' · '+b.name,color:palette[i%palette.length],dash:b.metric==='csi'?'6 4':b.metric==='answers'?'3 3':null,total:b.values.at(-1)})),receipt:[['Источник',data.source],['Расчёт','Количество суммируется по записям каждого месяца. CSI — средняя оценка месяца из действующего расчёта проекта. Месячные CSI не суммируются.'],['Шкалы','События, отправки и ответы — общая левая шкала количества. CSI — правая шкала от 1 до 5; при отключении всех количественных линий шкала CSI переходит влево. Нормирование не используется.'],['Период',data.periodLabel+'. Последние календарные месяцы относительно последнего месяца выбранных опросов.'],['Полнота',data.warnings.join(' ')]]});}
 $('dataRows').replaceChildren();for(const row of data.table){const tr=node('tr');for(const value of ['#'+row.id,month(row.month),row.metric,fmt(row.value,row.metric==='CSI'?'csi':'count')])tr.append(node('td','',value));$('dataRows').append(tr);}
 $('method').replaceChildren();for(const warning of data.warnings)$('method').append(node('p','',warning));
 $('method').append(node('p','','Итог количественного показателя суммирует только месяцы с наблюдениями. Для CSI на карточке показана оценка последнего месяца. CSI и количества используют разные шкалы.'));
 $('chartsView').click();
}
async function send(query){if(busy)return;query=query.trim();if(!query){error.textContent='Введите вопрос или выберите пример запроса.';error.hidden=false;input.focus();return;}
 busy=true;error.hidden=true;$('submit').disabled=true;source.disabled=true;provider.disabled=true;$('newSession').disabled=true;$('loading').hidden=false;result.setAttribute('aria-busy','true');
 try{const response=await fetch('/api/genui',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query,source:source.value,provider:provider.value,previous})});const data=await response.json();if(!response.ok)throw new Error(data.error||'Не удалось построить экран.');
 show(data);input.value='';input.placeholder='Уточните экран: например, «Добавь ответы»';
 history.unshift({query,data,source:source.value});history=history.slice(0,8);$('history').replaceChildren();for(const h of history){const b=node('button','',h.query);b.type='button';b.onclick=()=>{source.value=h.source;updateSource();show(h.data);};$('history').append(b);}
 result.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});
 }catch(e){error.textContent=e.message;error.hidden=false;}finally{busy=false;$('submit').disabled=false;source.disabled=false;provider.disabled=false;$('newSession').disabled=false;$('loading').hidden=true;result.removeAttribute('aria-busy');}
}
form.addEventListener('submit',e=>{e.preventDefault();send(input.value);});input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
document.querySelectorAll('[data-query]').forEach(b=>b.onclick=()=>{previous=null;send(b.dataset.query);});document.querySelectorAll('[data-followup]').forEach(b=>b.onclick=()=>send(b.dataset.followup));
function updateSource(){$('sourceHint').textContent=source.value==='demo'?'Архив предыдущей версии. Показатели примера не добавляются в ваши CSV.':'Ваши файлы date/push-sms.csv и date/success-screen.csv. Каждое построение перечитывает файлы.';}
source.onchange=()=>{previous=null;current=null;result.hidden=true;error.hidden=true;clearCharts();updateSource();};
$('newSession').onclick=()=>{previous=null;current=null;clearCharts();result.hidden=true;error.hidden=true;input.value='';input.placeholder='Покажи отправки по опросу 193 за последние 3 месяца';input.focus();};
$('chartsView').onclick=()=>{$('charts').hidden=false;$('tableWrap').hidden=true;$('chartsView').setAttribute('aria-pressed','true');$('tableView').setAttribute('aria-pressed','false');};
$('tableView').onclick=()=>{$('charts').hidden=true;$('tableWrap').hidden=false;$('chartsView').setAttribute('aria-pressed','false');$('tableView').setAttribute('aria-pressed','true');};
$('combineView').onclick=()=>{if(!current)return;current.spec.layout=current.spec.layout==='combined'?'separate':'combined';show(current);};
provider.onchange=()=>{$('providerBadge').textContent=provider.value==='gigacode'?'GigaCode CLI':'Локальный разбор';};
fetch('/api/genui/status').then(r=>r.json()).then(status=>{$('cliStatus').textContent=status.message;if(status.configured){provider.value='gigacode';provider.onchange();}}).catch(()=>{$('cliStatus').textContent='Не удалось проверить CLI. Обновите страницу.';});
$('download').onclick=()=>{if(!current)return;const q=v=>'"'+String(v??'').replaceAll('"','""')+'"';const rows=[['Опрос','Месяц','Показатель','Значение'],...current.table.map(r=>[r.id,r.month,r.metric,r.value])];const blob=new Blob(['\uFEFF'+rows.map(r=>r.map(q).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=node('a');a.href=url;a.download='genui-monitoring.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
})();
