(()=>{'use strict';
const el=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e;},nf=new Intl.NumberFormat('ru-RU',{maximumFractionDigits:0}),pf=new Intl.NumberFormat('ru-RU',{maximumFractionDigits:1});
window.MeetingPage={create({main}){
 const page=el('section','meeting-page');page.hidden=true;main.append(page);const link=el('a','nav-item','Встреча 05.11.2026');link.href='#meeting-20261105';document.querySelector('.rail').insertBefore(link,document.querySelector('.history'));let token=0,loaded=false,loading=false;const channels={},drafts=new Map();
 function dispose(){page.querySelectorAll('.v2-chart').forEach(c=>c.destroy?.());}
 function stop(){}
 function renderCard(source,index,revision){
  const card=el('article','meeting-chart');card.dataset.meetingChart=String(index+1);card.dataset.chartKind=source.kind||'monthly';if(source.month)card.dataset.csiMonth=source.month;card.append(el('h2','',String(index+1)+'. '+source.title));
  if(source.id){const label=el('label','meeting-channel','Канал опроса'),select=el('select');select.setAttribute('aria-label',source.kind==='daily-csi'?'Канал · '+source.title:'Канал опроса '+source.id);for(const [value,name]of [['auto','Определить по данным'],['communication','Пуш + СМС'],['success_screen','Экран успеха']]){const option=el('option','',name);option.value=value;select.append(option);}select.value=channels[String(source.id)]||'auto';select.onchange=()=>{channels[String(source.id)]=select.value;show(true);};label.append(select);card.append(label);}
  page.append(card);
  if(source.status!=='ok'){card.append(el('p',source.status==='clarification'?'meeting-message':'overview-empty',source.message));if(source.note)card.append(el('p','overview-source',source.note));return;}
  if(source.kind!=='daily-csi')card.append(el('p','overview-source',(source.channel==='communication'?'Пуш + СМС':'Экран успеха')+' · опросов в расчёте: '+source.memberCount+(source.note?' · '+source.note:'')));
  const editor=el('div'),totals=el('p','meeting-totals'),mount=el('div',source.kind==='daily-csi'?'daily-csi':source.kind==='events-breakdown'?'meeting-breakdown':'meeting-plot'),key=[revision,index,source.channel||source.data.channel].join(':');card.append(editor,totals,mount);let current;
  function draw(chart){
   const visibility=new Map([...mount.querySelectorAll('input[data-period-series]')].map(input=>[input.dataset.periodSeries,input.checked]));mount.querySelectorAll('.v2-chart').forEach(c=>c.destroy?.());mount.replaceChildren();card.dataset.edited=String(Boolean(chart.data.uiEdited));
   const data=structuredClone(chart.data);data.exportFilename='meeting-20261105-'+(index+1)+(data.uiEdited?'-edited':'')+'.png';
   if(source.kind==='daily-csi'){totals.hidden=true;window.DailyCSI.render(mount,data);return;}
   if(source.kind==='events-breakdown'){totals.hidden=true;window.MeetingBreakdown.render(mount,data);return;}
   totals.textContent='За 2026 год: '+data.totals.filter(t=>t.enabled).map(t=>t.label+' — '+(t.value===null?'нет наблюдений':nf.format(t.value)+(Number.isFinite(t.ratio?.total)?' ('+pf.format(t.ratio.total)+'%)':''))).join(' · ');
   data.chartColors={sends:'#ff8a35',answers:'#72b9e6',events:'#c3c8d0',stop:'#d5b278',contactPolicy:'#b59cbd',stopAndPolicy:'#79aa95'};for(const b of data.blocks)if(visibility.has(b.metric+':'+b.id))b.enabled=visibility.get(b.metric+':'+b.id);
   window.ChartAssistant.renderPreview(mount,data,{height:420,colors:data.chartColors,dashes:{answers:'8 5',events:'2 4',stop:'10 4',contactPolicy:'4 4',stopAndPolicy:'12 4 2 4'}});mount.querySelector(':scope > button').textContent='Скачать PNG';
  }
  current=window.MeetingEdits.attach(editor,source,{current:drafts.get(key)||source,onState:value=>drafts.set(key,value),onChange:value=>{current=value;draw(current);}});draw(current);
  if(source.data.warnings?.length)card.append(el('p','overview-source','Предупреждения источника: '+source.data.warnings.join(' ')));
 }
 async function show(force=false,resetEdits=false){
  if((loaded||loading)&&!force)return;if(resetEdits)drafts.clear();loading=true;const current=++token;dispose();page.replaceChildren(el('h1','','Встреча 05.11.2026'),el('p','','Проверяю date и рассчитываю графики…'));page.setAttribute('aria-busy','true');
  try{const data=await window.TrustUI.post('/api/meeting-20261105',{channels});if(current!==token)return;page.replaceChildren();const header=el('header','overview-heading'),text=el('div'),refresh=el('button','','Обновить из date');text.append(el('p','overview-eyebrow','Материалы встречи'),el('h1','',data.title),el('p','','Основные графики: январь–декабрь 2026 по месяцам · CSI: июль–ноябрь по дням'));refresh.onclick=()=>show(true,true);header.append(text,refresh);page.append(header,el('p','overview-source','Пересчитано: '+new Date(data.refreshedAt).toLocaleString('ru-RU')+' · версия данных '+(data.revision||'не создана')+' · ваши CSV'),el('p','overview-source','«Изменить значения» меняет только выбранный график. PNG сохраняет текущие значения. Правки действуют до обновления из date или перезагрузки страницы.'));
   if(data.held)page.append(el('p','error','Активна восстановленная версия данных. Примените текущие CSV в разделе «Качество данных», чтобы использовать их.'));
   data.charts.forEach((chart,i)=>renderCard(chart,i,data.revision));loaded=true;
  }catch(error){if(current!==token)return;page.append(el('p','error',error.message));const retry=el('button','','Повторить загрузку');retry.onclick=()=>show(true);page.append(retry);}finally{if(current===token){loading=false;page.removeAttribute('aria-busy');}}
 }
 link.onclick=()=>{if(location.hash===link.hash)show();};return {page,show,stop};
}};
})();
