(()=>{
const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;};
async function post(url,body){const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const payload=await response.json();if(!response.ok)throw Object.assign(new Error(payload.error||'Не удалось выполнить действие.'),payload);return payload;}
const number=v=>v===null||v===undefined?'Нет данных':new Intl.NumberFormat('ru-RU',{maximumFractionDigits:6}).format(v);
function navigation(host){const nav=node('nav');nav.setAttribute('aria-label','Разделы данных');for(const [label,hash] of [['К диалогу','#'],['Качество данных','#trust'],['Словарь показателей','#metrics']]){const link=node('a',label);link.href=hash;link.style.marginRight='16px';nav.append(link);}host.prepend(nav);}
function report(host,value){
 if(!value){host.append(node('p','Загрузок пока нет. CSV будут проверены до принятия данных.'));return;}
 const changes=value.changes||{},cards=node('div',undefined,'trust-cards');
 for(const [label,key] of [['Новых строк','added'],['Исправленных строк','updated'],['Удалённых строк','removed'],['Без изменения','unchanged'],['Привязок продуктов изменено','productLinksChanged']])cards.append(node('p',label+': '+number(changes[key])));host.append(cards);
 host.append(node('p',`Строк в истории: ${number(value.recordCount)} · уникальных ID: ${number(value.surveyIds)} · дневных строк: ${number(value.dailyRows)} · месячных: ${number(value.monthlyRows)}`));
 if(value.from)host.append(node('p','Период источников: '+value.from+' — '+value.to));
 if(value.withoutProduct!==undefined)host.append(node('p','Опросов без продукта: '+value.withoutProduct));
 for(const issue of value.issues||[])host.append(node('p',issue,'trust-warning'));
 if(value.gaps?.length){const details=node('details');details.append(node('summary','Дни без строк внутри интервала · '+value.gapCount));for(const gap of value.gaps)details.append(node('p',`#${gap.id} · ${gap.channel==='communication'?'Пуш+СМС':'Экран успеха'} · ${gap.from} — ${gap.to} · ${gap.unobservedDays} дн.`));host.append(details);}
}
function definition(host,item){host.append(node('h3',item.label+' · '+item.unit),node('p','Пуш+СМС: '+(item.communication||'Неприменимо')),node('p','Экран успеха: '+(item.success_screen||'Неприменимо')),node('p',item.note));}
window.TrustUI={post,create({main,onChange}){
 const page=node('section',undefined,'trust-page'),metrics=node('section',undefined,'trust-page');page.hidden=metrics.hidden=true;main.append(page,metrics);
 let serial=0;
 async function show(){const ticket=++serial;page.replaceChildren(node('h1','Качество и история данных'),node('p','При обновлении CSV данные проверяются автоматически. Предпросмотр позволяет увидеть изменения до ручного применения. Доступно восстановление последних десяти версий.'));navigation(page);const loading=node('p','Читаем локальную историю…');page.append(loading);
  try{const response=await fetch('/api/data/trust'),data=await response.json();if(ticket!==serial)return;if(data.error)throw new Error(data.error);loading.remove();
  page.append(node('p','Активная версия: '+(data.revision||'ещё не создана')));
  if(data.restoredHold)page.append(node('p','Восстановленная версия закреплена. Файлы на диске не изменены. Чтобы применить текущие CSV, выполните предпросмотр и применение ниже.','trust-warning'));
  const current=node('article',undefined,'trust-card');current.append(node('h2','Последняя принятая загрузка'));report(current,data.report);page.append(current);
  const actions=node('article',undefined,'trust-card');actions.append(node('h2','Проверить текущие CSV'),node('p','Дополнение сохраняет ранее принятые записи. Полная замена удаляет из истории строки, которых нет в текущих файлах. Справочник продуктов в обоих режимах заменяется целиком.'));
  const mode=node('select');mode.setAttribute('aria-label','Режим загрузки');mode.add(new Option('Дополнять историю','merge'));mode.add(new Option('Полная замена выгрузки','replace'));mode.value=data.mode;
  const preview=node('button','Предпросмотр загрузки'),output=node('div');preview.type='button';actions.append(mode,preview,output);page.append(actions);
  preview.onclick=async()=>{preview.disabled=true;output.replaceChildren(node('p','Проверяем CSV…'));try{const plan=await post('/api/data/preview',{mode:mode.value});output.replaceChildren(node('h3',plan.mode==='replace'?'Полная замена: проверьте удаления':'Дополнение: проверьте изменения'));report(output,plan.report);output.append(node('p','Предпросмотр ещё не изменил данные. После применения выбранный режим будет использоваться для последующих обновлений CSV.'));
    const apply=node('button','Применить эту загрузку');apply.type='button';apply.onclick=async()=>{apply.disabled=true;try{await post('/api/data/apply',{token:plan.token});onChange();show();}catch(error){output.append(node('p',error.message,'error'));apply.disabled=false;}};output.append(apply);
   }catch(error){output.replaceChildren(node('p',error.message,'error'),node('p','Последняя корректная версия сохранена.'));}finally{preview.disabled=false;}};
  const history=node('article',undefined,'trust-card');history.append(node('h2','Версии данных'));
  for(const version of data.versions){const row=node('div',undefined,'trust-version');row.append(node('strong',new Date(version.created).toLocaleString('ru-RU')+' · '+(version.reason==='restore'?'восстановление':version.mode==='replace'?'полная замена':'дополнение')),node('p',version.revision+' · '+number(version.report?.recordCount)+' строк'));
   if(version.revision!==data.revision){const restore=node('button','Выбрать для восстановления');restore.type='button';const review=node('div');restore.onclick=()=>{review.replaceChildren(node('p','Будет восстановлена версия '+version.revision+'. CSV на диске останутся прежними. Текущая версия останется в истории, пока не выйдет из десяти последних загрузок.'));report(review,version.report);const confirm=node('button','Восстановить эту версию');confirm.type='button';confirm.onclick=async()=>{confirm.disabled=true;try{await post('/api/data/restore',{revision:version.revision});onChange();show();}catch(error){review.append(node('p',error.message,'error'));confirm.disabled=false;}};review.append(confirm);};row.append(restore,review);}else row.append(node('p','Активная версия'));history.append(row);
  }if(!data.versions.length)history.append(node('p','История появится после первой загрузки.'));page.append(history);
  if(data.errors?.length){const failures=node('details',undefined,'trust-card');failures.append(node('summary','Ошибки загрузки · '+data.errors.length));for(const error of data.errors.slice().reverse())failures.append(node('p',new Date(error.time).toLocaleString('ru-RU')+' · '+error.message));page.append(failures);}
  }catch(error){loading.textContent=error.message;}
 }
 async function showMetrics(){metrics.replaceChildren(node('h1','Словарь показателей'));navigation(metrics);try{const response=await fetch('/api/metrics'),data=await response.json();metrics.append(node('p','Версия определений: '+data.version),node('p',data.missing));for(const item of data.metrics){const card=node('article',undefined,'trust-card');definition(card,item);metrics.append(card);}}catch(error){metrics.append(node('p',error.message,'error'));}}
 return {page,metrics,show,showMetrics};
},attachEvidence(host,data){
 const details=node('details',undefined,'method metric-evidence');details.append(node('summary','Проверить число по исходным строкам'));
 const controls=node('div',undefined,'evidence-controls'),series=node('select'),period=node('select');series.setAttribute('aria-label','Показатель для сверки');period.setAttribute('aria-label','Период для сверки');data.blocks.forEach((b,i)=>series.add(new Option(b.label+' · '+(b.id===null?'все выбранные опросы':'#'+b.id),String(i))));data.months.forEach(m=>period.add(new Option(m,m)));period.value=data.months.findLast((m,i)=>data.blocks.some(b=>b.values[i]!==null))||data.months.at(-1);
 const button=node('button','Сверить значение'),output=node('div');button.type='button';controls.append(series,period,button);details.append(node('p','Сверка использует зафиксированную версию загрузки этого графика.'),controls,output);host.append(details);
 button.onclick=async()=>{button.disabled=true;output.replaceChildren(node('p','Сверяем исходные строки…'));try{const proof=await post('/api/genui/evidence',{analysisId:data.analysisId,series:Number(series.value),period:period.value});output.replaceChildren(node('h3',proof.reconciled?'Сверка совпала':'Нужна проверка источника'),node('p',proof.note),node('p','График: '+number(proof.plottedValue)+' · пересчёт: '+number(proof.recalculatedValue)),node('p','Версия данных: '+proof.revision+' · версия формул: '+proof.metricVersion));definition(output,proof.definition);
 if(proof.metric==='csi')output.append(node('p','Числитель: '+number(proof.proof.numerator)+' · знаменатель: '+number(proof.proof.denominator)+' · исключено строк: '+number(proof.proof.excludedRows)));
 if(proof.missing)output.append(node('p','За этот период нет исходных строк. Это отсутствие наблюдений, а не переданный ноль.'));
 output.append(node('p','Найдено строк: '+proof.rowCount+'. Показаны первые '+Math.min(proof.sampleLimit,proof.rowCount)+'. Пересчёт использует все строки.'));
 const wrap=node('div',undefined,'table-wrap'),table=node('table'),head=node('tr');for(const name of ['Файл','Дата','Опрос','Статус','Оценка','События','Отправки','Ответы'])head.append(node('th',name));table.append(head);for(const row of proof.rows){const tr=node('tr');for(const value of [row.file,row.date,row.id,row.status,row.csi,row.events,row.sends,row.answers])tr.append(node('td',value===null?'—':String(value)));table.append(tr);}wrap.append(table);output.append(wrap);
 if(proof.referenceRows?.length)for(const r of proof.referenceRows)output.append(node('p','#'+r.id+' · месячный план: '+number(r.monthlyPlan)));
 }catch(error){output.replaceChildren(node('p',error.message,'error'));}finally{button.disabled=false;}};
}};
})();
