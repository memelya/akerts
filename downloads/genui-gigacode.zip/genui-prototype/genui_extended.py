"""Calendar detail and reference-based selections for GEN UI."""
import calendar
import copy
import re
from genui_query import plan_query as base_plan, execute_query as base_execute

def plan_query(query, previous=None):
    text=query.lower().replace('ё','е')
    filters={}
    if re.search(r'\bтоп\b',text): filters['top']=True
    if 'триггерн' in text: filters['type']='Триггерный'
    if 'пуш' in text or 'смс' in text: filters['channel']='communication'
    if 'экран' in text: filters['channel']='success_screen'
    day=bool(re.search(r'по дням|дневн',text))
    names=['январ','феврал','март','апрел','ма','июн','июл','август','сентябр','октябр','ноябр','декабр']
    selected=None
    for n,name in enumerate(names,1):
        m=re.search(r'за\s+'+name+r'\w*\s+(20\d{2})',text)
        if m:
            selected=f'{m[1]}-{n:02d}'
            query=query[:m.start()]+'за '+m[1]+' год'+query[m.end():]
            break
    clean=re.sub(r'по дням|дневн\w*','',query,flags=re.I)
    old={k:v for k,v in (previous or {}).items() if k not in ('filters','grain','plan')}
    if old: old['metrics']=[m for m in old['metrics'] if m!='plan']
    if old and not old['ids']: old['ids']=[1]
    if filters: clean+=' опрос 1'
    if 'план' in text and not re.search(r'отправ|событ|csi|ответ',text): clean+=' ответы'
    spec=base_plan(clean,old or None)
    if filters: spec['ids']=[];spec['filters']=filters
    elif previous and previous.get('filters') and not re.search(r'опрос\w*\s+\d',text): spec['filters']=previous['filters'];spec['ids']=[]
    if selected: spec.update(startMonth=selected,endMonth=selected)
    if day or previous and previous.get('grain')=='day' and 'по месяцам' not in text: spec['grain']='day'
    if 'план' in text or previous and previous.get('plan'): spec['plan']=True
    return spec

def execute_query(state,spec,source):
    spec=dict(spec)
    spec['metrics']=[m for m in spec['metrics'] if m!='plan']
    if spec['metrics']==['unique_surveys'] and not spec.get('filters') and not spec.get('grain') and not spec.get('plan'): return base_execute(state,spec,source)
    chosen=[s for s in state['surveys'] if not spec.get('ids') or s['event']['id'] in spec['ids']]
    filters=spec.get('filters',{})
    chosen=[s for s in chosen if (not filters.get('top') or s['event'].get('isTop')) and (not filters.get('type') or filters['type'] in s['meta'].get('surveyType','')) and (not filters.get('channel') or filters['channel']==s['meta']['channel'])]
    if not chosen: raise ValueError('Нет загруженных данных по выбранным условиям.')
    core={k:v for k,v in spec.items() if k not in ('filters','grain','plan')}
    results=[]
    if filters and 'startMonth' not in core:
        last=max(m for s in chosen for m in s['meta']['availableMonths'])
        y,m=map(int,last.split('-'));n=y*12+m-core['monthsCount']
        core.update(startMonth=f'{n//12:04d}-{n%12+1:02d}',endMonth=last)
    for s in chosen:
        one=dict(core,ids=[s['event']['id']])
        results.append(base_execute(state,one,source))
    result=copy.deepcopy(results[0])
    result['blocks']=[copy.deepcopy(b) for r in results for b in r['blocks']]
    if filters:
        result['blocks']=[];result['totals']=[];result['table']=[]
        for metric in core['metrics']:
            blocks=[b for r in results for b in r['blocks'] if b['metric']==metric]
            if metric=='csi': raise ValueError('Для CSI укажите конкретный опрос; общий CSI требует взвешивания.')
            values=[sum(b['values'][j] for b in blocks if b['values'][j] is not None) if any(b['values'][j] is not None for b in blocks) else None for j in range(len(result['months']))]
            result['blocks'].append(dict(blocks[0],id=None,name='Выбранные опросы',values=values))
    if spec.get('grain')=='day':
        if not spec.get('startMonth') or spec.get('startMonth')!=spec.get('endMonth'): raise ValueError('Для дневного графика укажите месяц и год, например: за октябрь 2026 года.')
        month=spec['startMonth'];y,m=map(int,month.split('-'))
        dates=[f'{month}-{d:02d}' for d in range(1,calendar.monthrange(y,m)[1]+1)]
        ids={s['event']['id'] for s in chosen}
        rows=[r for r in state.get('rawRecords',[]) if r['grain']=='day' and r['id'] in ids and r['date'].startswith(month)]
        if not rows: raise ValueError('Нет дневных записей за выбранный месяц. Загрузите дневной CSV.')
        from dashboard_model import POLICY
        for b in result['blocks']:
            values=[]
            for date in dates:
                subset=[r for r in rows if r['date']==date and (b['id'] is None or r['id']==b['id'])]
                key=b['metric']; value=None
                if subset:
                    if key=='csi':
                        rated=[r for r in subset if r.get('csi') is not None and 1<=r['csi']<=5]
                        weight=sum(r['events'] for r in rated)
                        value=sum(r['events']*r['csi'] for r in rated)/weight if weight else None
                    elif key in ('stop','contactPolicy'): value=sum(r['events'] for r in subset if r['status'] in ([1002] if key=='stop' else POLICY))
                    elif key=='unique_surveys': value=len({r['id'] for r in subset})
                    else: value=sum(r[key] for r in subset)
                values.append(value)
            b['values']=values
        result['months']=dates
        result['periodLabel']=dates[0]+' — '+dates[-1]
    if spec.get('plan'):
        plans=[s['meta'].get('plan') for s in chosen]
        known=[p for p in plans if p is not None]
        if len(known)!=len(plans): result['warnings'].append('Для части опросов план неизвестен; линия содержит только известные планы.')
        value=sum(known) if known else None
        if spec.get('grain')=='day' and value is not None:
            value=value/len(result['months'])
            result['warnings'].append('Дневной план распределён равномерно по календарным дням месяца.')
        result['blocks'].append(dict(id=None,name='План ответов',metric='plan',label='План ответов',values=[value]*len(result['months'])))
        spec['metrics']=list(dict.fromkeys(spec['metrics']+['plan']))
    result['totals']=[];result['table']=[]
    for b in result['blocks']:
        known=[v for v in b['values'] if v is not None]
        result['totals'].append(dict(b,value=b['values'][-1] if b['metric']=='csi' else sum(known) if known else None,note='За выбранный период'))
        result['table'].extend(dict(id=b['id'],name=b['name'],month=d,metric=b['label'],value=v) for d,v in zip(result['months'],b['values']))
    result['spec']=spec
    return result
