"""Prototype query planner. No model calls or arbitrary code execution.

Phase two can replace plan_query with a DeepSeek adapter returning the same
validated specification. Calculations and rendering remain deterministic.
"""
import re
from dashboard_model import POLICY

METRICS = {'sends': 'Отправки', 'answers': 'Ответы', 'events': 'События', 'csi': 'CSI',
           'stop': 'Отсечения по стоп-листам', 'contactPolicy': 'Отсечения по политике контактов',
           'unique_surveys': 'Уникальные опросы'}


def validate_spec(spec):
    if not isinstance(spec, dict):
        raise ValueError('Модель должна вернуть объект параметров графика.')
    if set(spec)-{'ids', 'metrics', 'monthsCount', 'layout', 'startMonth', 'endMonth'}:
        raise ValueError('В ответе модели есть неподдерживаемые параметры.')
    ids, metrics, count = spec.get('ids'), spec.get('metrics'), spec.get('monthsCount')
    aggregate = metrics == ['unique_surveys']
    if not isinstance(ids, list) or not (0 if aggregate else 1) <= len(ids) <= 4 or any(type(i) is not int or not 1 <= i <= 9999999 for i in ids):
        raise ValueError('Укажите от 1 до 4 корректных ID опросов.')
    if not isinstance(metrics, list) or not 1 <= len(metrics) <= 6 or any(not isinstance(m, str) or m not in METRICS for m in metrics):
        raise ValueError('Доступны отправки, ответы, события, CSI, стоп-листы, политика контактов и уникальные опросы.')
    if 'unique_surveys' in metrics and not aggregate:
        raise ValueError('Количество уникальных опросов запрашивайте отдельным графиком.')
    if type(count) is not int or not 1 <= count <= 24:
        raise ValueError('Выберите период от 1 до 24 месяцев.')
    layout = spec.get('layout', 'combined' if len(metrics)>1 else 'separate')
    if layout not in ('combined', 'separate'):
        raise ValueError('Режим графика: combined или separate.')
    result = {'ids':list(dict.fromkeys(ids)), 'metrics':list(dict.fromkeys(metrics)), 'monthsCount':count, 'layout':layout}
    for key in ('startMonth', 'endMonth'):
        if key in spec:
            value = spec[key]
            if not isinstance(value, str) or not re.fullmatch(r'(?:19|20|21)\d{2}-(?:0[1-9]|1[0-2])', value):
                raise ValueError('Период должен содержать месяцы в формате YYYY-MM (1900–2199).')
            result[key] = value
    if 'endMonth' in result and ('startMonth' not in result or result['endMonth'] < result['startMonth']):
        raise ValueError('Конец периода должен быть не раньше начала.')
    return result


def plan_query(query, previous=None):
    if not isinstance(query, str) or not query.strip() or len(query) > 1200:
        raise ValueError('Введите запрос длиной до 1200 символов.')
    text = query.lower().replace('ё', 'е')
    if re.search(r'почему|причин|предска|прогноз', text):
        raise ValueError('В прототипе доступны показатели и сравнения. Попробуйте: «Отправки по опросу 193 за последние 3 месяца». Объяснение причин появится на этапе подключения модели.')
    if re.search(r'по дням|по неделям', text):
        raise ValueError('В прототипе доступна группировка по месяцам. Укажите период в месяцах.')
    previous = validate_spec(previous) if previous else {}
    year_match = re.search(r'(?:за\s+|с\s*начала\s+|с\s+)((?:19|20|21)\d{2})(?:\s*год\w*)?', text)
    id_text = re.sub(r'\d+\s*месяц\w*', '', text)
    if year_match:
        id_text = re.sub(r'(?<!\d)'+year_match[1]+r'(?!\d)', '', id_text)
    ids = [int(x) for x in re.findall(r'(?<!\d)(\d{1,7})(?!\d)', id_text)]
    ids = list(dict.fromkeys(ids))
    followup = bool(re.search(r'добав|сравн|еще|теперь|остав|убер', text))
    if followup and re.search(r'добав|сравн', text):
        ids = list(dict.fromkeys(previous.get('ids', []) + ids))
    unique = bool(re.search(r'уникальн\w*\s+опрос|опрос\w*\s+уникальн', text))
    ids = ids or ([] if unique else previous.get('ids', []))
    if (not ids and not unique and previous.get('metrics') != ['unique_surveys']) or len(ids) > 4:
        raise ValueError('Укажите от 1 до 4 номеров опросов. Например: «Сравни отправки опросов 193 и 1007».')
    metrics = ['unique_surveys'] if unique else [key for key, pattern in [('sends', r'отправ|коммуникац'), ('answers', r'ответ|отклик'), ('events', r'событ'), ('csi', r'csi|оценк'), ('stop', r'стоп[\s-]*лист'), ('contactPolicy', r'политик\w*\s+контакт')] if re.search(pattern, text)]
    if 'отклик' in text:
        raise ValueError('Для прототипа уточните показатель: «отправки» или «ответы». Расчёт отклика добавим отдельно.')
    if re.search(r'убер|убра|исключ', text) and previous:
        metrics = [m for m in previous['metrics'] if m not in metrics]
        if not metrics:
            raise ValueError('На графике должен остаться хотя бы один показатель.')
    elif re.search(r'добав', text) and not unique:
        metrics = list(dict.fromkeys(previous.get('metrics', []) + metrics))
    metrics = metrics or previous.get('metrics', ['sends'])
    match = re.search(r'(?:последн\w*|за)\s+(\d{1,2})\s*месяц', text)
    count = int(match[1]) if match else previous.get('monthsCount', 3)
    if re.search(r'весь период|все месяцы', text):
        count = 24
    if not isinstance(count, int) or not 1 <= count <= 24:
        raise ValueError('Выберите период от 1 до 24 месяцев.')
    layout = previous.get('layout', 'combined' if len(metrics)>1 else 'separate')
    if re.search(r'на одном|один график|объедин|совмест|вместе', text):
        layout = 'combined'
    elif re.search(r'отдельн|раздельн|разным график', text):
        layout = 'separate'
    elif len(metrics)>1 and ('layout' not in previous or not followup or re.search(r'добав', text)):
        layout = 'combined'
    result = {'ids': ids, 'metrics': metrics, 'monthsCount': count, 'layout':layout}
    if year_match:
        result['startMonth'] = year_match[1]+'-01'
        if not re.search(r'с\s*(?:начала\s+)?'+year_match[1], text):
            result['endMonth'] = year_match[1]+'-12'
    elif not match and not re.search(r'весь период|все месяцы', text):
        result.update({k: previous[k] for k in ('startMonth', 'endMonth') if k in previous})
    return validate_spec(result)


def execute_query(state, spec, source):
    spec = validate_spec(spec)
    ids, metrics = spec['ids'], spec['metrics']
    if any(not isinstance(i, int) or isinstance(i, bool) for i in ids) or any(k not in METRICS for k in metrics):
        raise ValueError('Некорректные параметры запроса.')
    by_id = {s['event']['id']: s for s in state['surveys']}
    missing = [i for i in ids if i not in by_id]
    if missing:
        raise ValueError('Нет данных по опросам '+', '.join(map(str, missing))+'. Добавьте их строки в date/push-sms.csv или date/success-screen.csv и повторите запрос.')
    selected = ids or list(by_id)
    if not selected:
        raise ValueError('Нет загруженных данных для построения графика.')
    last = max(m for i in selected for m in by_id[i]['meta']['availableMonths'])
    year, month = map(int, last.split('-'))
    end = year*12+month-1
    start = end-spec['monthsCount']+1
    if 'startMonth' in spec:
        y, m = map(int, spec['startMonth'].split('-'))
        start = y*12+m-1
        y, m = map(int, spec.get('endMonth', last).split('-'))
        end = y*12+m-1
    if end < start:
        raise ValueError('В загруженных данных ещё нет месяцев выбранного периода.')
    if end-start >= 120:
        raise ValueError('Выберите период не длиннее 120 месяцев.')
    months = ['%04d-%02d' % (n//12, n%12+1) for n in range(start, end+1)]
    blocks, totals, table, warnings = [], [], [], []
    methods = ['Пропущенные месяцы не заменяются нулями. CSI — средняя по допустимым оценкам 1–5; оценка 0 сохраняется, но не входит в CSI.']
    if 'stop' in metrics:
        methods.append('Стоп-листы: число событий со status_det = 1002.')
    if 'contactPolicy' in metrics:
        methods.append('Политика контактов: число событий со status_det из списка '+', '.join(map(str, POLICY))+'.')
    if metrics == ['unique_surveys']:
        methods.append('Уникальные опросы: число различных ID с наблюдениями в каждом месяце, независимо от объёма событий. Справочник без наблюдений не учитывается. Итог — различные ID за весь период, а не сумма месяцев.')
        values = [sum(m in by_id[i]['meta']['availableMonths'] for i in selected) or None for m in months]
        blocks.append({'id':None, 'name':'Уникальные опросы', 'metric':'unique_surveys', 'label':METRICS['unique_surveys'], 'values':values})
        totals.append({'id':None, 'name':'Уникальные опросы', 'metric':'unique_surveys', 'label':METRICS['unique_surveys'], 'value':sum(any(m in by_id[i]['meta']['availableMonths'] for m in months) for i in selected) if any(v is not None for v in values) else None, 'note':'Различных ID за выбранный период'})
        table.extend({'id':None, 'name':'Все выбранные опросы', 'month':m, 'metric':METRICS['unique_surveys'], 'value':v} for m,v in zip(months,values))
    for ident in ([] if metrics == ['unique_surveys'] else ids):
        survey = by_id[ident]
        event, meta = survey['event'], survey['meta']
        for metric in metrics:
            values = []
            for m in months:
                index = event['months'].index(m) if m in event['months'] else None
                value = None
                if index is not None and m in meta['availableMonths']:
                    if metric in ('stop', 'contactPolicy'):
                        codes = [1002] if metric == 'stop' else POLICY
                        statuses = [s for s in event['statuses'] if s['code'] in codes]
                        if meta['channel'] != 'success_screen' and statuses:
                            value = sum(s['values'][index] for s in statuses)
                    else:
                        field = {'sends':'sendTotals','answers':'responseTotals','events':'totals','csi':'csiValues'}[metric]
                        value = event.get(field, [None]*len(event['months']))[index]
                values.append(value)
                table.append({'id':ident, 'name':meta['name'], 'month':m, 'metric':METRICS[metric], 'value':value})
            known = [v for v in values if v is not None]
            value = values[-1] if metric == 'csi' else sum(known) if known else None
            totals.append({'id':ident, 'name':meta['name'], 'metric':metric, 'label':METRICS[metric], 'value':value, 'note':'Последний месяц · средняя оценка' if metric=='csi' else '%s из %s месяцев с данными' % (len(known),len(months))})
            blocks.append({'id':ident, 'name':meta['name'], 'metric':metric, 'label':METRICS[metric], 'values':values})
            if metric in ('stop', 'contactPolicy') and not known:
                warnings.append('#%s: нет подходящих status_det для показателя «%s». Для экранов успеха эти отсечения не применяются; без строк статусов значение не подтверждено.' % (ident, METRICS[metric]))
        if meta.get('missingDates'):
            warnings.append('#%s: дневная выборка неполная; в месячном итоге только переданные даты.' % ident)
    warnings.append('Последний месяц (%s) может быть неполным. Отсутствующие месяцы показаны как «Нет данных».' % last)
    return {'spec':spec, 'source':source, 'months':months, 'blocks':blocks, 'totals':totals, 'table':table, 'warnings':warnings, 'methods':methods, 'periodLabel':months[0]+' — '+months[-1], 'anchor':last}
