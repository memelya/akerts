"""Prototype query planner. No model calls or arbitrary code execution.

Phase two can replace plan_query with a DeepSeek adapter returning the same
validated specification. Calculations and rendering remain deterministic.
"""
import re

METRICS = {'sends': 'Отправки', 'answers': 'Ответы', 'events': 'События', 'csi': 'CSI'}


def validate_spec(spec):
    if not isinstance(spec, dict):
        raise ValueError('Модель должна вернуть объект параметров графика.')
    if set(spec)-{'ids', 'metrics', 'monthsCount', 'layout'}:
        raise ValueError('В ответе модели есть неподдерживаемые параметры.')
    ids, metrics, count = spec.get('ids'), spec.get('metrics'), spec.get('monthsCount')
    if not isinstance(ids, list) or not 1 <= len(ids) <= 4 or any(type(i) is not int or not 1 <= i <= 9999999 for i in ids):
        raise ValueError('Укажите от 1 до 4 корректных ID опросов.')
    if not isinstance(metrics, list) or not 1 <= len(metrics) <= 4 or any(not isinstance(m, str) or m not in METRICS for m in metrics):
        raise ValueError('Доступны отправки, ответы, события и CSI.')
    if type(count) is not int or not 1 <= count <= 24:
        raise ValueError('Выберите период от 1 до 24 месяцев.')
    layout = spec.get('layout', 'combined' if len(metrics)>1 else 'separate')
    if layout not in ('combined', 'separate'):
        raise ValueError('Режим графика: combined или separate.')
    return {'ids':list(dict.fromkeys(ids)), 'metrics':list(dict.fromkeys(metrics)), 'monthsCount':count, 'layout':layout}


def plan_query(query, previous=None):
    if not isinstance(query, str) or not query.strip() or len(query) > 1200:
        raise ValueError('Введите запрос длиной до 1200 символов.')
    text = query.lower().replace('ё', 'е')
    if re.search(r'почему|причин|предска|прогноз', text):
        raise ValueError('В прототипе доступны показатели и сравнения. Попробуйте: «Отправки по опросу 193 за последние 3 месяца». Объяснение причин появится на этапе подключения модели.')
    if re.search(r'по дням|по неделям', text):
        raise ValueError('В прототипе доступна группировка по месяцам. Укажите период в месяцах.')
    previous = validate_spec(previous) if previous else {}
    ids = [int(x) for x in re.findall(r'(?<!\d)(\d{2,7})(?!\d)', re.sub(r'\d+\s*месяц\w*', '', text))]
    ids = list(dict.fromkeys(ids))
    followup = bool(re.search(r'добав|сравн|еще|теперь|остав|убер', text))
    if followup and re.search(r'добав|сравн', text):
        ids = list(dict.fromkeys(previous.get('ids', []) + ids))
    ids = ids or previous.get('ids', [])
    if not ids or len(ids) > 4:
        raise ValueError('Укажите от 1 до 4 номеров опросов. Например: «Сравни отправки опросов 193 и 1007».')
    metrics = [key for key, pattern in [('sends', r'отправ|коммуникац'), ('answers', r'ответ|отклик'), ('events', r'событ'), ('csi', r'csi|оценк')] if re.search(pattern, text)]
    if 'отклик' in text:
        raise ValueError('Для прототипа уточните показатель: «отправки» или «ответы». Расчёт отклика добавим отдельно.')
    if re.search(r'добав', text):
        metrics = list(dict.fromkeys(previous.get('metrics', []) + metrics))
    metrics = metrics or previous.get('metrics', ['sends'])
    match = re.search(r'(?:последн\w*|за)\s+(\d{1,2})\s*месяц', text)
    count = int(match[1]) if match else previous.get('monthsCount', 3)
    if re.search(r'весь период|все месяцы', text):
        count = 24
    if not isinstance(count, int) or not 1 <= count <= 24:
        raise ValueError('Выберите период от 1 до 24 месяцев.')
    layout = previous.get('layout', 'combined' if len(metrics)>1 else 'separate')
    if re.search(r'на одном|один график|объедин|совмест|вместе', text):
        layout = 'combined'
    elif re.search(r'отдельн|раздельн|разным график', text):
        layout = 'separate'
    elif len(metrics)>1 and 'layout' not in previous:
        layout = 'combined'
    return validate_spec({'ids': ids, 'metrics': metrics, 'monthsCount': count, 'layout':layout})


def execute_query(state, spec, source):
    spec = validate_spec(spec)
    ids, metrics = spec['ids'], spec['metrics']
    if any(not isinstance(i, int) or isinstance(i, bool) for i in ids) or any(k not in METRICS for k in metrics):
        raise ValueError('Некорректные параметры запроса.')
    by_id = {s['event']['id']: s for s in state['surveys']}
    missing = [i for i in ids if i not in by_id]
    if missing:
        raise ValueError('Нет данных по опросам '+', '.join(map(str, missing))+'. Загрузите CSV или выберите архивный пример.')
    last = max(m for i in ids for m in by_id[i]['meta']['availableMonths'])
    year, month = map(int, last.split('-'))
    end = year*12+month-1
    months = ['%04d-%02d' % (n//12, n%12+1) for n in range(end-spec['monthsCount']+1, end+1)]
    blocks, totals, table, warnings = [], [], [], []
    for ident in ids:
        survey = by_id[ident]
        event, meta = survey['event'], survey['meta']
        for metric in metrics:
            values = []
            for m in months:
                index = event['months'].index(m) if m in event['months'] else None
                field = {'sends':'sendTotals','answers':'responseTotals','events':'totals','csi':'csiValues'}[metric]
                value = event.get(field, [None]*len(event['months']))[index] if index is not None and m in meta['availableMonths'] else None
                values.append(value)
                table.append({'id':ident, 'name':meta['name'], 'month':m, 'metric':METRICS[metric], 'value':value})
            known = [v for v in values if v is not None]
            value = values[-1] if metric == 'csi' else sum(known) if known else None
            totals.append({'id':ident, 'name':meta['name'], 'metric':metric, 'label':METRICS[metric], 'value':value, 'note':'Последний месяц · средняя оценка' if metric=='csi' else '%s из %s месяцев с данными' % (len(known),len(months))})
            blocks.append({'id':ident, 'name':meta['name'], 'metric':metric, 'label':METRICS[metric], 'values':values})
        if meta.get('missingDates'):
            warnings.append('#%s: дневная выборка неполная; в месячном итоге только переданные даты.' % ident)
    warnings.append('Последний месяц (%s) может быть неполным. Отсутствующие месяцы показаны как «Нет данных».' % last)
    return {'spec':spec, 'source':source, 'months':months, 'blocks':blocks, 'totals':totals, 'table':table, 'warnings':warnings, 'periodLabel':months[0]+' — '+months[-1], 'anchor':last}
