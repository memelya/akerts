"""Fixed meeting charts from a single revision; no model calls."""
import datetime as dt
from collections import defaultdict
from metric_registry import calculate,LABELS
from metric_ratios import ratio,METHOD

GROUP='Свободная группа 1'
TITLES=[
 'График отправок и ответов по опросу 1007',
 'График отправок и ответов по опросу 3155',
 'График отправок коммуникаций по каналу пуш+СМС и ответов',
 'График отправок по пуш+СМС · Свободная группа 1',
 'График отправок по пуш+СМС · все группы, кроме Свободной группы 1',
]

def meeting(engine,request):
    choices=request.get('channels',{})
    if not isinstance(choices,dict) or set(choices)-{'1007','3155'} or any(v not in ('auto','communication','success_screen') for v in choices.values()):raise ValueError('Неизвестный канал графика встречи.')
    with engine.lock:
        _,status=engine.refresh()
        if status.get('error'):raise ValueError('CSV не приняты: '+status['error'])
        revision=engine.document.get('revision');doc=engine.document
        cached=getattr(engine,'_meeting_months',None)
        if not cached or cached['revision']!=revision:
            rows=engine.store.monthly_records(revision,None,'2026-01','2026-12-31') if revision else []
            grouped=defaultdict(list)
            for row in rows:grouped[row['channel'],row['id'],row['date'][:7]].append(row)
            cells={key:{metric:calculate(values,metric) for metric in ('sends','answers')} for key,values in grouped.items()}
            cached={'revision':revision,'cells':cells,'keys':{(k[0],k[1]) for k in cells}};engine._meeting_months=cached
        cells=cached['cells'];state={'surveys':[s for s in engine.state['surveys'] if (s['meta']['channel'],s['event']['id']) in cached['keys']]}

        charts=[]
        for i,title in enumerate(TITLES):
            spec={'ids':[],'metrics':['sends','answers'] if i<3 else ['sends'],'monthsCount':12,'startMonth':'2026-01','endMonth':'2026-12','grain':'month','layout':'combined'}
            selected=state['surveys'];note=''
            if i<2:
                ident=(1007,3155)[i];spec['ids']=[ident];selected=[s for s in selected if s['event']['id']==ident]
                available=sorted({s['meta']['channel'] for s in selected});choice=choices.get(str(ident),'auto')
                if choice=='auto' and len(available)>1:
                    charts.append({'title':title,'status':'clarification','id':ident,'channels':available,'message':'За 2026 год опрос встречается в обоих каналах. Выберите канал; значения не объединены.'});continue
                channel=available[0] if choice=='auto' and available else choice
                if channel!='auto':spec['filters']={'channel':channel};selected=[s for s in selected if s['meta']['channel']==channel]
            else:
                spec['filters']={'channel':'communication'};selected=[s for s in selected if s['meta']['channel']=='communication']
                if i in (3,4):
                    def same(s):return ' '.join((s['meta'].get('triggerGroup') or 'без группы').split()).casefold()==GROUP.casefold()
                    selected=[s for s in selected if same(s)==(i==3)]
                    note='Отбор по справочнику: '+('группа «Свободная группа 1».' if i==3 else 'все группы, кроме «Свободная группа 1»; «без группы» включена.')
            if not selected:
                charts.append({'title':title,'status':'empty','message':'Нет наблюдений за 2026 год по выбранным условиям. Проверьте CSV'+(' и справочник групп.' if i>=3 else '.'),'note':note});continue
            months=[f'2026-{m:02d}' for m in range(1,13)];blocks=[];totals=[];table=[]
            series={}
            for metric in ('sends','answers'):
                values=[]
                for month in months:
                    known=[cells[s['meta']['channel'],s['event']['id'],month][metric] for s in selected if (s['meta']['channel'],s['event']['id'],month) in cells]
                    values.append(sum(known) if known else None)
                series[metric]=values
            denominator=series['sends'];base=sum(v for v in denominator if v is not None) if any(v is not None for v in denominator) else None
            for metric in spec['metrics']:
                values=series[metric];value=sum(v for v in values if v is not None) if any(v is not None for v in values) else None
                block={'id':spec['ids'][0] if spec['ids'] else None,'name':selected[0]['meta']['name'] if spec['ids'] else 'Все выбранные опросы','metric':metric,'label':LABELS[metric],'values':values,'sendRatio':{'baseMetric':'sends','baseValues':denominator,'values':[ratio(v,d) for v,d in zip(values,denominator)],'totalBase':base,'total':ratio(value,base),'method':METHOD}}
                blocks.append(block);totals.append(dict(block,value=value,note='За 2026 год'))
                table.extend({'id':block['id'],'name':block['name'],'month':m,'metric':block['label'],'value':v,'sendRatio':ratio(v,d),'ratioBase':d} for m,v,d in zip(months,values,denominator))
            data={'spec':spec,'months':months,'periodLabel':'2026-01 — 2026-12','source':'Ваши CSV · Встреча 05.11.2026','blocks':blocks,'totals':totals,'table':table,'warnings':[note] if note else [],'methods':['Количество суммируется по строкам месяца. Для экранов успеха отправки учитывают только SENDED.',METHOD],'meetingTitle':title,'dataRevision':revision}
            charts.append({'title':title,'status':'ok','id':(1007,3155)[i] if i<2 else None,'channel':selected[0]['meta']['channel'] if i<2 else 'communication','memberCount':len(selected),'note':note,'data':data})
        return {'title':'Встреча 05.11.2026','period':'2026-01 — 2026-12','revision':revision,'refreshedAt':dt.datetime.now(dt.timezone.utc).isoformat(),'held':bool(doc.get('heldFingerprint')),'charts':charts}
