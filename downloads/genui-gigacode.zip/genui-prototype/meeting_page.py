"""Fixed meeting charts from a single revision; no model calls."""
import datetime as dt
from collections import defaultdict
from metric_registry import calculate,LABELS
from metric_ratios import ratio

METRICS=("sends","answers","events","stop","contactPolicy","stopAndPolicy")
MEETING_LABELS=LABELS|{"events":"Загруженные события","stopAndPolicy":"Стоп-листы + политика контактов"}
METHOD="События — сумма events по всем статусам выбранного отбора. Ответы / отправки × 100 — отклик; отправки, стоп-листы, политика контактов и их сумма / события × 100 — доля событий. Для событий — 100% собственной базы. При нулевой или неизвестной базе процент не вычисляется. Пропуски не равны нулю. Отношения объёмов не являются когортной конверсией."

GROUP='Свободная группа 1'
TITLES=[
 'График отправок и ответов по опросу 1007',
 'График отправок и ответов по опросу 3155',
 'График отправок коммуникаций по каналу пуш+СМС и ответов',
 'График отправок по пуш+СМС · Свободная группа 1',
 'График отправок по пуш+СМС · все группы, кроме Свободной группы 1',
]

def meeting(engine,request):
    choices=request.get('channels',{})
    if not isinstance(choices,dict) or set(choices)-{'1007','3155'} or any(v not in ('auto','communication','success_screen') for v in choices.values()):raise ValueError('Неизвестный канал графика встречи.')
    with engine.lock:
        _,status=engine.refresh()
        if status.get('error'):raise ValueError('CSV не приняты: '+status['error'])
        revision=engine.document.get('revision');doc=engine.document
        cached=getattr(engine,'_meeting_months',None)
        if not cached or cached['revision']!=revision:
            rows=engine.store.monthly_records(revision,None,'2026-01','2026-12-31') if revision else []
            grouped=defaultdict(list)
            for row in rows:grouped[row['channel'],row['id'],row['date'][:7]].append(row)
            cells={key:{metric:calculate(values,metric) for metric in ('sends','answers','events','stop','contactPolicy')} for key,values in grouped.items()}
            cached={'revision':revision,'cells':cells,'keys':{(k[0],k[1]) for k in cells}};engine._meeting_months=cached
        cells=cached['cells'];state={'surveys':[s for s in engine.state['surveys'] if (s['meta']['channel'],s['event']['id']) in cached['keys']]}

        charts=[]
        for i,title in enumerate(TITLES):
            spec={'ids':[],'metrics':['sends','answers'] if i<3 else ['sends'],'monthsCount':12,'startMonth':'2026-01','endMonth':'2026-12','grain':'month','layout':'combined'}
            selected=state['surveys'];note=''
            if i<2:
                ident=(1007,3155)[i];spec['ids']=[ident];selected=[s for s in selected if s['event']['id']==ident]
                available=sorted({s['meta']['channel'] for s in selected});choice=choices.get(str(ident),'auto')
                if choice=='auto' and len(available)>1:
                    charts.append({'title':title,'status':'clarification','id':ident,'channels':available,'message':'За 2026 год опрос встречается в обоих каналах. Выберите канал; значения не объединены.'});continue
                channel=available[0] if choice=='auto' and available else choice
                if channel!='auto':spec['filters']={'channel':channel};selected=[s for s in selected if s['meta']['channel']==channel]
            else:
                spec['filters']={'channel':'communication'};selected=[s for s in selected if s['meta']['channel']=='communication']
                if i in (3,4):
                    def same(s):return ' '.join((s['meta'].get('triggerGroup') or 'без группы').split()).casefold()==GROUP.casefold()
                    selected=[s for s in selected if same(s)==(i==3)]
                    note='Отбор по справочнику: '+('группа «Свободная группа 1».' if i==3 else 'все группы, кроме «Свободная группа 1»; «без группы» включена.')
            if not selected:
                charts.append({'title':title,'status':'empty','message':'Нет наблюдений за 2026 год по выбранным условиям. Проверьте CSV'+(' и справочник групп.' if i>=3 else '.'),'note':note});continue
            default_metrics=spec['metrics']+['events'];spec['metrics']=default_metrics+['stop','contactPolicy','stopAndPolicy']
            months=[f'2026-{m:02d}' for m in range(1,13)];blocks=[];totals=[];table=[]
            series={}
            for metric in ('sends','answers','events','stop','contactPolicy'):
                values=[]
                for month in months:
                    known=[cells[s['meta']['channel'],s['event']['id'],month][metric] for s in selected if (s['meta']['channel'],s['event']['id'],month) in cells]
                    values.append(sum(known) if known and all(v is not None for v in known) else None)
                series[metric]=values
            series['stopAndPolicy']=[a+b if a is not None and b is not None else None for a,b in zip(series['stop'],series['contactPolicy'])]
            for metric in spec['metrics']:
                denominator=series['sends' if metric=='answers' else 'events'];base=sum(v for v in denominator if v is not None) if any(v is not None for v in denominator) else None
                values=series[metric];value=sum(v for v in values if v is not None) if any(v is not None for v in values) else None
                # A year share cannot use partial cutoff observations against a full-year denominator.
                complete=all(v is not None for v,d in zip(values,denominator) if d is not None)
                info={'baseMetric':'sends' if metric=='answers' else 'events','baseValues':denominator,'values':[ratio(v,d) for v,d in zip(values,denominator)],'totalBase':base,'total':ratio(value,base) if complete else None,'method':METHOD}
                available=metric in default_metrics or any(v is not None for v in values)
                block={'id':spec['ids'][0] if spec['ids'] else None,'name':selected[0]['meta']['name'] if spec['ids'] else 'Все выбранные опросы','metric':metric,'label':MEETING_LABELS[metric],'values':values,'ratio':info,'enabled':metric in default_metrics,'available':available,'reason':'Не применимо к экранам успеха' if selected[0]['meta']['channel']=='success_screen' else 'В выбранной выгрузке нет полного набора нужных статусов'}
                blocks.append(block);totals.append(dict(block,value=value,note='За 2026 год'))
                table.extend({'id':block['id'],'name':block['name'],'month':m,'metric':block['label'],'value':v,'sendRatio':ratio(v,d),'ratioBase':d,'ratioBaseMetric':info['baseMetric']} for m,v,d in zip(months,values,denominator))
            data={'spec':spec,'months':months,'periodLabel':'2026-01 — 2026-12','source':'Ваши CSV · Встреча 05.11.2026','blocks':blocks,'totals':totals,'table':table,'warnings':([note] if note else [])+(['Часть отсечений неизвестна: в месячных строках отдельных опросов нет нужных статусов. Сумма стоп-листов и политики контактов известна только при наличии обеих составляющих.'] if any(v is None and d is not None for metric in ('stop','contactPolicy') for v,d in zip(series[metric],series['events'])) else []),'methods':['Количество суммируется по строкам месяца. Для экранов успеха отправки учитывают только SENDED.',METHOD],'meetingPercentages':True,'meetingTitle':title,'dataRevision':revision}
            charts.append({'title':title,'status':'ok','id':(1007,3155)[i] if i<2 else None,'channel':selected[0]['meta']['channel'] if i<2 else 'communication','memberCount':len(selected),'note':note,'data':data})
        from daily_csi import meeting_charts
        charts.extend(meeting_charts(engine,revision,choices.get('1007','auto')))
        return {'title':'Встреча 05.11.2026','period':'2026-01 — 2026-12','revision':revision,'refreshedAt':dt.datetime.now(dt.timezone.utc).isoformat(),'held':bool(doc.get('heldFingerprint')),'charts':charts}
