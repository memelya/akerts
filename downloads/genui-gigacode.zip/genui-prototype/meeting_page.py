"""Fixed meeting charts from a single revision; no model calls."""
import datetime as dt
from genui_extended import execute_query

GROUP='Свободная группа 1'
TITLES=[
 'График отправок и ответов по опросу 1007',
 'График отправок и ответов по опросу 3155',
 'График отправок коммуникаций по каналу пуш+СМС и ответов',
 'График отправок по пуш+СМС · Свободная группа 1',
 'График отправок по пуш+СМС · все группы, кроме Свободной группы 1',
]

def meeting(engine,request):
    choices=request.get('channels',{})
    if not isinstance(choices,dict) or set(choices)-{'1007','3155'} or any(v not in ('auto','communication','success_screen') for v in choices.values()):raise ValueError('Неизвестный канал графика встречи.')
    with engine.lock:
        _,status=engine.refresh()
        if status.get('error'):raise ValueError('CSV не приняты: '+status['error'])
        revision=engine.document.get('revision');doc=engine.document
        rows=engine.store.monthly_records(revision,None,'2026-01','2026-12-31') if revision else []
        state=engine._build(rows,doc.get('products',{}),doc.get('reference'));state['rawRecords']=rows
        charts=[]
        for i,title in enumerate(TITLES):
            spec={'ids':[],'metrics':['sends','answers'] if i<3 else ['sends'],'monthsCount':12,'startMonth':'2026-01','endMonth':'2026-12','grain':'month','layout':'combined'}
            selected=state['surveys'];note=''
            if i<2:
                ident=(1007,3155)[i];spec['ids']=[ident];selected=[s for s in selected if s['event']['id']==ident]
                available=sorted({s['meta']['channel'] for s in selected});choice=choices.get(str(ident),'auto')
                if choice=='auto' and len(available)>1:
                    charts.append({'title':title,'status':'clarification','id':ident,'channels':available,'message':'За 2026 год опрос встречается в обоих каналах. Выберите канал; значения не объединены.'});continue
                channel=available[0] if choice=='auto' and available else choice
                if channel!='auto':spec['filters']={'channel':channel};selected=[s for s in selected if s['meta']['channel']==channel]
            else:
                spec['filters']={'channel':'communication'};selected=[s for s in selected if s['meta']['channel']=='communication']
                if i in (3,4):
                    def same(s):return ' '.join((s['meta'].get('triggerGroup') or 'без группы').split()).casefold()==GROUP.casefold()
                    selected=[s for s in selected if same(s)==(i==3)]
                    note='Отбор по справочнику: '+('группа «Свободная группа 1».' if i==3 else 'все группы, кроме «Свободная группа 1»; «без группы» включена.')
            if not selected:
                charts.append({'title':title,'status':'empty','message':'Нет наблюдений за 2026 год по выбранным условиям. Проверьте CSV'+(' и справочник групп.' if i>=3 else '.'),'note':note});continue
            scoped=dict(state,surveys=selected)
            data=execute_query(scoped,spec,'Ваши CSV · Встреча 05.11.2026',include_details=False)
            data['meetingTitle']=title;data['dataRevision']=revision
            if note:data['warnings'].append(note)
            charts.append({'title':title,'status':'ok','id':(1007,3155)[i] if i<2 else None,'channel':selected[0]['meta']['channel'] if i<2 else 'communication','memberCount':len(selected),'note':note,'data':data})
        return {'title':'Встреча 05.11.2026','period':'2026-01 — 2026-12','revision':revision,'refreshedAt':dt.datetime.now(dt.timezone.utc).isoformat(),'held':bool(doc.get('heldFingerprint')),'charts':charts}
