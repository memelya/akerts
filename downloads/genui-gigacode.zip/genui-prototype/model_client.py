"""Bounded JSON calls to configured CLI. No shell or model-provided execution."""
import json,os,re,subprocess,tempfile,time
from datetime import datetime,timezone
from pathlib import Path
from gigachat_bridge import load_config,LOCK,LOG_LOCK

class Cancelled(ValueError):pass

class ModelTimeout(ValueError):
    def __init__(self,stage,seconds):
        self.stage=stage;self.seconds=seconds
        super().__init__('GigaCode не завершила '+('исправление пояснений' if stage=='creative-metadata-repair' else 'генерацию интерфейса' if stage.startswith('creative-') and stage not in ('creative-plan','creative-plan-repair') else 'ответ модели')+' за '+str(seconds)+' с. Процесс остановлен. Это превышение времени ожидания; причина авторизации не установлена.')

def parse_json(value,path=''):
    value=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',value).strip()
    match=re.fullmatch(r'```(?:json)?\s*([\s\S]*?)\s*```',value)
    if match:value=match[1]
    def invalid(_):raise ValueError('JSON не должен содержать NaN или Infinity.')
    for depth in range(3):
        try:result=json.loads(value,parse_constant=invalid)
        except (ValueError,TypeError):raise ValueError('Модель должна вернуть один JSON-объект без служебных сообщений.') from None
        if depth==0:
            try:
                for key in path.split('.') if path else []:result=result[key]
            except (KeyError,TypeError):raise ValueError('В ответе CLI отсутствует настроенное поле responsePath.') from None
        if not isinstance(result,str):return result
        value=result
    raise ValueError('Слишком много вложенных JSON-оболочек.')

def append_log(root,entry):
    with LOG_LOCK:
        try:
            file=Path(root)/'.local-data/gigacode-log.json';rows=json.loads(file.read_text(encoding='utf-8')) if file.exists() else []
            file.parent.mkdir(parents=True,exist_ok=True);temporary=file.with_suffix('.tmp');temporary.write_text(json.dumps((rows+[entry])[-200:],ensure_ascii=False),encoding='utf-8');temporary.replace(file)
        except (OSError,ValueError):pass

def call_json(root,instructions,payload,stage,query,session,cancel,timeout_seconds=None):
    entry={'time':datetime.now(timezone.utc).isoformat(),'query':query,'mode':'cli','stage':stage,'session':session,'invoked':False,'status':'ok'};started=time.monotonic();acquired=False
    try:
        if cancel.is_set():raise Cancelled('Анализ остановлен пользователем.')
        config=load_config(root);prompt=instructions+'\nAGENT_CONTEXT_JSON\n'+json.dumps(payload,ensure_ascii=False,separators=(',',':'),allow_nan=False)
        if len(prompt)>25000:raise ValueError('Контекст анализа слишком велик для однократного вызова CLI. Уточните продукт или сузьте период.')
        budget=config['timeoutSeconds'] if timeout_seconds is None else timeout_seconds
        if type(budget) is not int or not 1<=budget<=300:raise ValueError('Время ожидания: от 1 до 300 секунд.')
        entry['timeoutSeconds']=budget;entry['prompt']=prompt
        if not LOCK.acquire(blocking=False):raise ValueError('CLI уже обрабатывает другой запрос. Дождитесь завершения.')
        acquired=True
        with tempfile.TemporaryDirectory(prefix='genui-agent-') as directory:
            prompt_file=Path(directory)/'prompt.txt';prompt_file.write_text(prompt,encoding='utf-8')
            command=[arg.replace('{prompt}',prompt).replace('{prompt_file}',str(prompt_file)) for arg in config['command']]
            if config['input']=='argument' and sum(len(a) for a in command)>28000:raise ValueError('Контекст не помещается в аргумент Windows. Используйте настроенный input: file или stdin.')
            with tempfile.TemporaryFile() as output,tempfile.TemporaryFile() as errors:
                process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=output,stderr=errors,cwd=directory,shell=False,env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONUTF8='1',NO_COLOR='1'),creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
                entry['invoked']=True;begin=time.monotonic()
                try:
                    try:process.communicate(input=prompt.encode('utf-8') if config['input']=='stdin' else b'',timeout=.25)
                    except subprocess.TimeoutExpired:
                        while True:
                            if cancel.is_set():raise Cancelled('Анализ остановлен пользователем.')
                            if time.monotonic()-begin>budget:raise ModelTimeout(stage,budget)
                            try:process.communicate(timeout=.25);break
                            except subprocess.TimeoutExpired:pass
                    if cancel.is_set():raise Cancelled('Анализ остановлен пользователем.')
                    if process.returncode:raise ValueError('GigaCode завершилась с ошибкой. Проверьте сеть и авторизацию в консоли.')
                    if output.tell()>262144:raise ValueError('Ответ модели слишком большой. Нужна только спецификация интерфейса.')
                    output.seek(0);response=output.read().decode('utf-8-sig');entry['response']=response
                    return parse_json(response,config['responsePath'])
                finally:
                    if process.poll() is None:
                        process.terminate()
                        try:process.communicate(timeout=2)
                        except subprocess.TimeoutExpired:process.kill();process.communicate()
    except (ValueError,OSError,UnicodeError) as error:
        if isinstance(error,ModelTimeout):entry['errorCode']='timeout'
        entry.update(status='cancelled' if isinstance(error,Cancelled) else 'error',error=str(error) if not isinstance(error,OSError) else 'Не удалось запустить настроенную CLI.')
        if isinstance(error,OSError):raise ValueError('Не удалось запустить настроенную CLI. Проверьте полный путь и зависимости.') from None
        raise
    finally:
        if acquired:LOCK.release()
        entry['durationMs']=round((time.monotonic()-started)*1000);append_log(root,entry)
